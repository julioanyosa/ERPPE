﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Halley.CapaLogica.Almacen;
using Halley.Entidad.Ventas;
using Halley.Configuracion;
using Halley.Utilitario;
using Halley.CapaLogica.Empresa;
using Halley.CapaLogica.Ventas;

namespace Halley.Presentacion.Ventas.Administracion
{
    public partial class MantenimientoPrecios : UITemplateAccess
    {
        string ProductoID, TipoTransaccion;
        CL_Producto ObjCL_Producto = new CL_Producto();
        CL_Comprobante ObjCL_Comprobante = new CL_Comprobante();
        DataTable DtComprobante = new DataTable();
        DataTable DtserieGuias = new DataTable();
        public MantenimientoPrecios()
        {
            InitializeComponent();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                ErrProvider.Clear();
                Cursor = Cursors.WaitCursor;
                if (c1cboCia.SelectedIndex != -1 & ProductoID != "" & TxtNuevoPrecio.Text != "." & TxtNuevoPrecio.Text != "."& TxtNuevoPrecio.Text != "")
                {
                    if (Convert.ToDecimal(TxtNuevoPrecio.Text) > 0)
                    {
                        //obtener nuevo precio
                        E_ListaPrecio ObjE_ListaPrecio = new E_ListaPrecio();
                        ObjE_ListaPrecio.EmpresaID = c1cboCia.SelectedValue.ToString();
                        ObjE_ListaPrecio.SedeID = AppSettings.SedeID;
                        ObjE_ListaPrecio.ProductoID = ProductoID;
                        ObjE_ListaPrecio.PrecioUnitario = Convert.ToDecimal(TxtNuevoPrecio.Text);
                        ObjE_ListaPrecio.UsuarioID = AppSettings.UserID;
                        ObjCL_Producto.UpdatePrecio(ObjE_ListaPrecio, AppSettings.SedeID);
                        MessageBox.Show("Se actualizo correctamente el precio", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimpiarPrecio();
                    }
                    else
                        ErrProvider.SetError(TxtNuevoPrecio, "precio debe ser diferente de cero.");
                }
                else
                {
                    if (c1cboCia.SelectedIndex == -1) ErrProvider.SetError(c1cboCia, "Seleccione una empresa.");
                    if (TxtNuevoPrecio.Text == "." | TxtNuevoPrecio.Text == "")
                        ErrProvider.SetError(TxtNuevoPrecio, "Ingrese un precio valido");
                    else if (TxtNuevoPrecio.Text.Length > 0 && Convert.ToDecimal(TxtNuevoPrecio.Text) == 0)
                        ErrProvider.SetError(TxtNuevoPrecio, "precio debe ser diferente de cero.");
                }
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor = Cursors.Default;
            }

        }

        private void MantenimientoPrecios_Load(object sender, EventArgs e)
        {
            //obtener todas las sedes
            DataTable Dtsedes = new CL_Empresas().GetSedes();
            DtComprobante = new CL_Comprobante().getTipoComprobante();
            c1Combo.FillC1Combo(this.c1cboCia, new CL_Empresas().GetEmpresas(), "NomEmpresa", "EmpresaID");
            c1Combo.FillC1Combo1(cbComprobante, DtComprobante, "NomTipoComprobante", "TipoComprobanteID");
            c1Combo.FillC1Combo1(cbComprobante2, DtComprobante.Copy(), "NomTipoComprobante", "TipoComprobanteID");
            ocultarToolStrip();
            Validar();
            PnlSerie.Visible = false;
        }

        private void Validar()
        {
            //traer la series y als guias
            DtserieGuias = ObjCL_Comprobante.GetSerieComprobantes(c1cboCia.SelectedValue.ToString() + AppSettings.SedeID);//las series
            BtnNuevaSerie.Visible = true;
            BtnCancelarSerie.Visible = false;
            BtnEditarSerie.Visible = true;
            BtnGuardarSerie.Visible = false;
            TxtNumero.ReadOnly = false;
            TxtNumero.Text = "";
            TxtNumero.ReadOnly = true;
            PnlSerie.Visible=false;
        }

        private void TxtCodigoVenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            ErrProvider.Clear();
            if (e.KeyChar == (char)(Keys.Enter) & TxtCodigoVenta.Text != "" & c1cboCia.SelectedIndex != -1)
            {
                DataTable DtProductos = new DataTable();
                DtProductos = ObjCL_Producto.GetProductosPrecioUpdate(c1cboCia.SelectedValue.ToString() + AppSettings.SedeID, TxtCodigoVenta.Text, "C");
                if (DtProductos.Rows.Count > 0)
                {
                    TxtCodigoVenta.Text = DtProductos.Rows[0]["ProductoIDVentas"].ToString();
                    ProductoID = DtProductos.Rows[0]["ProductoID"].ToString();
                    TxtCodigo.Text = DtProductos.Rows[0]["ProductoID"].ToString();
                    TxtProducto.Text = DtProductos.Rows[0]["Alias"].ToString();
                    LblUM.Text = DtProductos.Rows[0]["UnidadMedidaID"].ToString();
                    LblPrecioAnterior.Text = DtProductos.Rows[0]["PrecioUnitario"].ToString();
                }
                else
                {
                    LimpiarPrecio();
                }
            }
        }

        private void TxtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            ErrProvider.Clear();
            if (e.KeyChar == (char)(Keys.Enter) & TxtCodigo.Text != "")
            {
                DataTable DtProductos = new DataTable();
                DtProductos = ObjCL_Producto.GetProductosPrecioUpdate(AppSettings.EmpresaID + AppSettings.SedeID, TxtCodigo.Text, "I");
                if (DtProductos.Rows.Count > 0)
                {
                    TxtCodigoVenta.Text = DtProductos.Rows[0]["ProductoIDVentas"].ToString();
                    ProductoID = DtProductos.Rows[0]["ProductoID"].ToString();
                    TxtCodigo.Text = DtProductos.Rows[0]["ProductoID"].ToString();
                    TxtProducto.Text = DtProductos.Rows[0]["Alias"].ToString();
                    LblUM.Text = DtProductos.Rows[0]["UnidadMedidaID"].ToString();
                    LblPrecioAnterior.Text = DtProductos.Rows[0]["PrecioUnitario"].ToString();
                }
                else
                {
                    TxtCodigoVenta.Text = "";
                    TxtCodigo.Text = "";
                    TxtProducto.Text = "";
                    LblUM.Text = "";
                    LblPrecioAnterior.Text = "";
                }
            }
        }

        private void TxtProducto_KeyPress(object sender, KeyPressEventArgs e)
        {
            ErrProvider.Clear();
            if (e.KeyChar == (char)(Keys.Enter) & TxtProducto.Text != "" & c1cboCia.SelectedIndex != -1)
            {
                DataTable DtProductos = new DataTable();
                DtProductos = ObjCL_Producto.GetProductosPrecioUpdate(c1cboCia.SelectedValue.ToString() + AppSettings.SedeID, TxtProducto.Text, "A");
                if (DtProductos.Rows.Count > 0)
                {
                    TxtCodigoVenta.Text = DtProductos.Rows[0]["ProductoIDVentas"].ToString();
                    ProductoID = DtProductos.Rows[0]["ProductoID"].ToString();
                    TxtCodigo.Text = DtProductos.Rows[0]["ProductoID"].ToString();
                    TxtProducto.Text = DtProductos.Rows[0]["Alias"].ToString();
                    LblUM.Text = DtProductos.Rows[0]["UnidadMedidaID"].ToString();
                    LblPrecioAnterior.Text = DtProductos.Rows[0]["PrecioUnitario"].ToString();
                }
                else
                {
                    LimpiarPrecio();
                }
            }
        }

        private void LimpiarPrecio()
        {
            TxtCodigoVenta.Text = "";
            TxtCodigo.Text = "";
            TxtProducto.Text = "";
            LblUM.Text = "";
            LblPrecioAnterior.Text = "";
            if (c1cboCia.SelectedIndex == -1) { ErrProvider.SetError(c1cboCia, "Debe seleccionar una empresa"); }
        }

        private void BtnAnular_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                if (c1cboCia.SelectedIndex != -1 & cbComprobante.SelectedValue != null && TxtComprobante.Text != "")
                {
                    if (MessageBox.Show("¿Seguro que desea anular el Comprobante Nro: " + TxtComprobante.Text + "?. Si se anula este comprobante no aparecera en el reporte de ventas del día.", "Aviso", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                    {
                        ObjCL_Comprobante.AnularComprobante(c1cboCia.SelectedValue.ToString() + TxtComprobante.Text, Convert.ToInt32(cbComprobante.SelectedValue), AppSettings.UserID, AppSettings.SedeID);
                        MessageBox.Show("Se anulo el comprobante", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Cursor = Cursors.Default;
                    }
                }
                else
                {
                    if (cbComprobante.SelectedIndex == -1) ErrProvider.SetError(cbComprobante, "Seleccione un tipo de comprobante.");
                    if (TxtComprobante.Text == "") ErrProvider.SetError(TxtComprobante, "ingrese un comprobante.");
                    if (c1cboCia.SelectedIndex == -1) ErrProvider.SetError(c1cboCia, "Seleccione una empresa.");
                }
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor = Cursors.Default;
            }

        }

        private void BtnNuevaSerie_Click(object sender, EventArgs e)
        {
            BtnNuevaSerie.Visible = false;
            BtnCancelarSerie.Visible = true;
            BtnEditarSerie.Visible = false;
            BtnGuardarSerie.Visible = true;
            PnlSerie.Visible = true;
            TxtNumero.ReadOnly = false;
            TipoTransaccion = "G";
            cbComprobante2.SelectedIndex = -1;
        }

        private void BtnEditarSerie_Click(object sender, EventArgs e)
        {
            BtnNuevaSerie.Visible = false;
            BtnCancelarSerie.Visible = true;
            BtnEditarSerie.Visible = false;
            BtnGuardarSerie.Visible = true;
            TxtNumero.ReadOnly = false;
            PnlSerie.Visible = false;
            TipoTransaccion = "E";
        }

        private void BtnCancelarSerie_Click(object sender, EventArgs e)
        {
            BtnNuevaSerie.Visible = true;
            BtnCancelarSerie.Visible = false;
            BtnEditarSerie.Visible = true;
            BtnGuardarSerie.Visible = false;
            TxtNumero.ReadOnly = true;
            PnlSerie.Visible = false;
        }

        private void BtnGuardarSerie_Click(object sender, EventArgs e)
        {
            try
            {
                ErrProvider.Clear();
                Cursor = Cursors.WaitCursor;
                BtnNuevaSerie.Visible = true;
                BtnCancelarSerie.Visible = false;
                BtnEditarSerie.Visible = true;
                BtnGuardarSerie.Visible = false;
                TxtNumero.ReadOnly = true;

                if (cbComprobante2.SelectedValue != null & TxtSerie.Text != "" & TxtNumero.Text != "" & TipoTransaccion == "G")
                {
                    ObjCL_Comprobante.InsertSerieGuia(c1cboCia.SelectedValue.ToString() + AppSettings.SedeID, Convert.ToInt16(cbComprobante2.SelectedValue), TxtSerie.Text, Convert.ToInt32(TxtNumero.Text), AppSettings.UserID);
                    MessageBox.Show("Se agrego correctamente la serie.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Validar();
                    Cursor = Cursors.Default;
                }
                else if (cbComprobante2.SelectedValue != null & CboSerieGuias.SelectedIndex != -1 & TxtNumero.Text != "" & TipoTransaccion == "E")
                {
                    ObjCL_Comprobante.UpdateSerieComprobante(c1cboCia.SelectedValue.ToString() + AppSettings.SedeID, Convert.ToInt16(cbComprobante2.SelectedValue), CboSerieGuias.SelectedText, Convert.ToInt32(TxtNumero.Text), AppSettings.UserID);
                    MessageBox.Show("Se actualizo correctamente la serie.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Validar();
                    Cursor = Cursors.Default;
                }
                else
                {
                    if (c1cboCia.SelectedIndex == -1) ErrProvider.SetError(c1cboCia, "Seleccione una empresa.");
                    if(TipoTransaccion == "G")
                        if (TxtSerie.Text == "") ErrProvider.SetError(TxtSerie, "Ingrese una serie valida.");
                    else if (TipoTransaccion == "E")
                            if (CboSerieGuias.SelectedIndex == -1) ErrProvider.SetError(CboSerieGuias, "Seleccione una serie de la guia.");
                    if (TxtNumero.Text == "") ErrProvider.SetError(TxtNumero, "Ingrese un numero valido");
                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                BtnNuevaSerie.Visible = false;
                BtnCancelarSerie.Visible = true;
                BtnEditarSerie.Visible = true;
                BtnGuardarSerie.Visible = true;
                TxtNumero.ReadOnly = false;
                Cursor = Cursors.Default;
                ErrProvider.Clear();
            }
        }

        private void cbComprobante2_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbComprobante2.SelectedIndex != -1 & DtserieGuias.Rows.Count>0)
            {
                DataView Dv = new DataView(DtserieGuias);
                Dv.RowFilter = "TipoDocumento = '" + cbComprobante2.SelectedValue + "'";
                c1Combo.FillC1Combo(CboSerieGuias, Dv.ToTable(), "Serie", "Serie");
            }
        }

        private void c1cboCia_SelectedValueChanged(object sender, EventArgs e)
        {
            if (c1cboCia.SelectedIndex != -1)
            {
                //traer la series y als guias
                DtserieGuias = ObjCL_Comprobante.GetSerieComprobantes(c1cboCia.SelectedValue.ToString() + AppSettings.SedeID);//las series
            }
        }
    }
}
