﻿namespace Halley.Presentacion.Ventas.Administracion
{
    partial class MantenimientoPrecios
    {
        /// <summary> 
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar 
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MantenimientoPrecios));
            this.LblPrecioAnterior = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtNuevoPrecio = new C1.Win.C1Input.C1TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnActualizar = new C1.Win.C1Input.C1Button();
            this.BtnEditarSerie = new C1.Win.C1Input.C1Button();
            this.BtnNuevaSerie = new C1.Win.C1Input.C1Button();
            this.BtnGuardarSerie = new C1.Win.C1Input.C1Button();
            this.BtnCancelarSerie = new C1.Win.C1Input.C1Button();
            this.TxtNumero = new C1.Win.C1Input.C1TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CboSerieGuias = new C1.Win.C1List.C1Combo();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnAnular = new C1.Win.C1Input.C1Button();
            this.TxtComprobante = new C1.Win.C1Input.C1TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LblUM = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.TxtCodigoVenta = new C1.Win.C1Input.C1TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TxtCodigo = new C1.Win.C1Input.C1TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtProducto = new C1.Win.C1Input.C1TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbComprobante = new C1.Win.C1List.C1Combo();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.PnlSerie = new System.Windows.Forms.Panel();
            this.TxtSerie = new C1.Win.C1Input.C1TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbComprobante2 = new C1.Win.C1List.C1Combo();
            this.label4 = new System.Windows.Forms.Label();
            this.ErrProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.c1cboCia = new C1.Win.C1List.C1Combo();
            this.label14 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNuevoPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboSerieGuias)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtComprobante)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCodigoVenta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCodigo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProducto)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbComprobante)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.PnlSerie.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtSerie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbComprobante2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1cboCia)).BeginInit();
            this.SuspendLayout();
            // 
            // LblPrecioAnterior
            // 
            this.LblPrecioAnterior.BackColor = System.Drawing.Color.White;
            this.LblPrecioAnterior.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblPrecioAnterior.Location = new System.Drawing.Point(106, 128);
            this.LblPrecioAnterior.Name = "LblPrecioAnterior";
            this.LblPrecioAnterior.Size = new System.Drawing.Size(101, 21);
            this.LblPrecioAnterior.TabIndex = 386;
            this.LblPrecioAnterior.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 385;
            this.label2.Text = "Precio anterior :";
            // 
            // TxtNuevoPrecio
            // 
            this.TxtNuevoPrecio.Location = new System.Drawing.Point(106, 152);
            this.TxtNuevoPrecio.MaxLength = 300;
            this.TxtNuevoPrecio.Name = "TxtNuevoPrecio";
            this.TxtNuevoPrecio.Size = new System.Drawing.Size(101, 22);
            this.TxtNuevoPrecio.TabIndex = 395;
            this.TxtNuevoPrecio.Tag = null;
            this.TxtNuevoPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 394;
            this.label3.Text = "Nuevo precio :";
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.Image = global::Halley.Presentacion.Properties.Resources.save_16x16;
            this.BtnActualizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnActualizar.Location = new System.Drawing.Point(213, 152);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(82, 23);
            this.BtnActualizar.TabIndex = 396;
            this.BtnActualizar.Text = "Actualizar";
            this.BtnActualizar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // BtnEditarSerie
            // 
            this.BtnEditarSerie.Image = global::Halley.Presentacion.Properties.Resources.edit_16x16;
            this.BtnEditarSerie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEditarSerie.Location = new System.Drawing.Point(383, 48);
            this.BtnEditarSerie.Name = "BtnEditarSerie";
            this.BtnEditarSerie.Size = new System.Drawing.Size(82, 23);
            this.BtnEditarSerie.TabIndex = 408;
            this.BtnEditarSerie.Text = "Editar";
            this.BtnEditarSerie.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnEditarSerie.UseVisualStyleBackColor = true;
            this.BtnEditarSerie.Click += new System.EventHandler(this.BtnEditarSerie_Click);
            // 
            // BtnNuevaSerie
            // 
            this.BtnNuevaSerie.Image = global::Halley.Presentacion.Properties.Resources.newdocument_16x16;
            this.BtnNuevaSerie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnNuevaSerie.Location = new System.Drawing.Point(383, 19);
            this.BtnNuevaSerie.Name = "BtnNuevaSerie";
            this.BtnNuevaSerie.Size = new System.Drawing.Size(82, 23);
            this.BtnNuevaSerie.TabIndex = 407;
            this.BtnNuevaSerie.Text = "Nuevo";
            this.BtnNuevaSerie.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnNuevaSerie.UseVisualStyleBackColor = true;
            this.BtnNuevaSerie.Click += new System.EventHandler(this.BtnNuevaSerie_Click);
            // 
            // BtnGuardarSerie
            // 
            this.BtnGuardarSerie.Image = global::Halley.Presentacion.Properties.Resources.save_16x16;
            this.BtnGuardarSerie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnGuardarSerie.Location = new System.Drawing.Point(383, 106);
            this.BtnGuardarSerie.Name = "BtnGuardarSerie";
            this.BtnGuardarSerie.Size = new System.Drawing.Size(82, 23);
            this.BtnGuardarSerie.TabIndex = 405;
            this.BtnGuardarSerie.Text = "Guardar";
            this.BtnGuardarSerie.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnGuardarSerie.UseVisualStyleBackColor = true;
            this.BtnGuardarSerie.Click += new System.EventHandler(this.BtnGuardarSerie_Click);
            // 
            // BtnCancelarSerie
            // 
            this.BtnCancelarSerie.Image = global::Halley.Presentacion.Properties.Resources.cancel_16x16;
            this.BtnCancelarSerie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCancelarSerie.Location = new System.Drawing.Point(383, 77);
            this.BtnCancelarSerie.Name = "BtnCancelarSerie";
            this.BtnCancelarSerie.Size = new System.Drawing.Size(82, 23);
            this.BtnCancelarSerie.TabIndex = 406;
            this.BtnCancelarSerie.Text = "Cancelar";
            this.BtnCancelarSerie.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnCancelarSerie.UseVisualStyleBackColor = true;
            this.BtnCancelarSerie.Click += new System.EventHandler(this.BtnCancelarSerie_Click);
            // 
            // TxtNumero
            // 
            this.TxtNumero.BackColor = System.Drawing.Color.White;
            this.TxtNumero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNumero.EditMask = "0000000";
            this.TxtNumero.Location = new System.Drawing.Point(122, 80);
            this.TxtNumero.MaskInfo.EmptyAsNull = true;
            this.TxtNumero.MaskInfo.ErrorMessage = "Ingrese un numero valido de comprobante";
            this.TxtNumero.MaskInfo.Inherit = C1.Win.C1Input.MaskInfoInheritFlags.CaseSensitive;
            this.TxtNumero.MaskInfo.StoredEmptyChar = ' ';
            this.TxtNumero.MaxLength = 7;
            this.TxtNumero.Name = "TxtNumero";
            this.TxtNumero.Size = new System.Drawing.Size(87, 20);
            this.TxtNumero.TabIndex = 404;
            this.TxtNumero.Tag = null;
            this.TxtNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtNumero.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumero.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(65, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 13);
            this.label6.TabIndex = 403;
            this.label6.Text = "Numero:";
            // 
            // CboSerieGuias
            // 
            this.CboSerieGuias.AddItemSeparator = ';';
            this.CboSerieGuias.AutoCompletion = true;
            this.CboSerieGuias.AutoDropDown = true;
            this.CboSerieGuias.AutoSelect = true;
            this.CboSerieGuias.Caption = "";
            this.CboSerieGuias.CaptionHeight = 17;
            this.CboSerieGuias.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboSerieGuias.ColumnCaptionHeight = 17;
            this.CboSerieGuias.ColumnFooterHeight = 17;
            this.CboSerieGuias.ColumnHeaders = false;
            this.CboSerieGuias.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.CboSerieGuias.ContentHeight = 17;
            this.CboSerieGuias.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboSerieGuias.DisplayMember = "NomEmpresa";
            this.CboSerieGuias.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboSerieGuias.EditorFont = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboSerieGuias.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboSerieGuias.EditorHeight = 17;
            this.CboSerieGuias.Images.Add(((System.Drawing.Image)(resources.GetObject("CboSerieGuias.Images"))));
            this.CboSerieGuias.ItemHeight = 15;
            this.CboSerieGuias.Location = new System.Drawing.Point(122, 50);
            this.CboSerieGuias.MatchEntryTimeout = ((long)(2000));
            this.CboSerieGuias.MaxDropDownItems = ((short)(10));
            this.CboSerieGuias.MaxLength = 32767;
            this.CboSerieGuias.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboSerieGuias.Name = "CboSerieGuias";
            this.CboSerieGuias.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboSerieGuias.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboSerieGuias.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboSerieGuias.Size = new System.Drawing.Size(87, 23);
            this.CboSerieGuias.TabIndex = 400;
            this.CboSerieGuias.ValueMember = "EmpresaID";
            this.CboSerieGuias.PropBag = resources.GetString("CboSerieGuias.PropBag");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 399;
            this.label5.Text = "Serie:";
            // 
            // BtnAnular
            // 
            this.BtnAnular.Image = global::Halley.Presentacion.Properties.Resources.eliminar_16x16;
            this.BtnAnular.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnAnular.Location = new System.Drawing.Point(284, 46);
            this.BtnAnular.Name = "BtnAnular";
            this.BtnAnular.Size = new System.Drawing.Size(82, 23);
            this.BtnAnular.TabIndex = 413;
            this.BtnAnular.Text = "Anular";
            this.BtnAnular.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnAnular.UseVisualStyleBackColor = true;
            this.BtnAnular.Click += new System.EventHandler(this.BtnAnular_Click);
            // 
            // TxtComprobante
            // 
            this.TxtComprobante.BackColor = System.Drawing.Color.White;
            this.TxtComprobante.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtComprobante.EditMask = "000-0000000";
            this.TxtComprobante.Location = new System.Drawing.Point(121, 46);
            this.TxtComprobante.MaskInfo.EmptyAsNull = true;
            this.TxtComprobante.MaskInfo.ErrorMessage = "Ingrese un formato valido de comprobante.";
            this.TxtComprobante.MaskInfo.Inherit = C1.Win.C1Input.MaskInfoInheritFlags.CaseSensitive;
            this.TxtComprobante.MaskInfo.StoredEmptyChar = ' ';
            this.TxtComprobante.MaxLength = 11;
            this.TxtComprobante.Name = "TxtComprobante";
            this.TxtComprobante.Size = new System.Drawing.Size(148, 20);
            this.TxtComprobante.TabIndex = 412;
            this.TxtComprobante.Tag = null;
            this.TxtComprobante.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtComprobante.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(64, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 411;
            this.label11.Text = "Numero:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.LblUM);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.TxtCodigoVenta);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.TxtCodigo);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.TxtProducto);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.BtnActualizar);
            this.groupBox1.Controls.Add(this.TxtNuevoPrecio);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.LblPrecioAnterior);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(13, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(724, 187);
            this.groupBox1.TabIndex = 414;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MANTENIMIENTO DE PRECIO";
            // 
            // LblUM
            // 
            this.LblUM.BackColor = System.Drawing.Color.White;
            this.LblUM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblUM.Location = new System.Drawing.Point(106, 105);
            this.LblUM.Name = "LblUM";
            this.LblUM.Size = new System.Drawing.Size(101, 21);
            this.LblUM.TabIndex = 404;
            this.LblUM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(72, 109);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 13);
            this.label13.TabIndex = 403;
            this.label13.Text = "UM:";
            // 
            // TxtCodigoVenta
            // 
            this.TxtCodigoVenta.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtCodigoVenta.Location = new System.Drawing.Point(106, 28);
            this.TxtCodigoVenta.MaxLength = 200;
            this.TxtCodigoVenta.Name = "TxtCodigoVenta";
            this.TxtCodigoVenta.Size = new System.Drawing.Size(100, 22);
            this.TxtCodigoVenta.TabIndex = 402;
            this.TxtCodigoVenta.Tag = null;
            this.TxtCodigoVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtCodigoVenta_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 401;
            this.label9.Text = "Codigo venta:";
            // 
            // TxtCodigo
            // 
            this.TxtCodigo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtCodigo.Location = new System.Drawing.Point(106, 52);
            this.TxtCodigo.MaxLength = 200;
            this.TxtCodigo.Name = "TxtCodigo";
            this.TxtCodigo.Size = new System.Drawing.Size(100, 22);
            this.TxtCodigo.TabIndex = 400;
            this.TxtCodigo.Tag = null;
            this.TxtCodigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtCodigo_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 399;
            this.label7.Text = "Codigo:";
            // 
            // TxtProducto
            // 
            this.TxtProducto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtProducto.Location = new System.Drawing.Point(106, 80);
            this.TxtProducto.MaxLength = 200;
            this.TxtProducto.Name = "TxtProducto";
            this.TxtProducto.Size = new System.Drawing.Size(414, 22);
            this.TxtProducto.TabIndex = 398;
            this.TxtProducto.Tag = null;
            this.TxtProducto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtProducto_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(43, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 397;
            this.label10.Text = "Producto:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbComprobante);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.BtnAnular);
            this.groupBox2.Controls.Add(this.TxtComprobante);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Location = new System.Drawing.Point(13, 228);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(412, 89);
            this.groupBox2.TabIndex = 415;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ANULAR COMPROBANTE";
            // 
            // cbComprobante
            // 
            this.cbComprobante.AddItemSeparator = ';';
            this.cbComprobante.Caption = "";
            this.cbComprobante.CaptionHeight = 17;
            this.cbComprobante.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.cbComprobante.ColumnCaptionHeight = 17;
            this.cbComprobante.ColumnFooterHeight = 17;
            this.cbComprobante.ColumnHeaders = false;
            this.cbComprobante.ColumnWidth = 100;
            this.cbComprobante.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.cbComprobante.ContentHeight = 17;
            this.cbComprobante.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.cbComprobante.EditorBackColor = System.Drawing.SystemColors.Window;
            this.cbComprobante.EditorFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbComprobante.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.cbComprobante.EditorHeight = 17;
            this.cbComprobante.ExtendRightColumn = true;
            this.cbComprobante.Images.Add(((System.Drawing.Image)(resources.GetObject("cbComprobante.Images"))));
            this.cbComprobante.ItemHeight = 15;
            this.cbComprobante.Location = new System.Drawing.Point(121, 17);
            this.cbComprobante.MatchEntryTimeout = ((long)(2000));
            this.cbComprobante.MaxDropDownItems = ((short)(5));
            this.cbComprobante.MaxLength = 32767;
            this.cbComprobante.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.cbComprobante.Name = "cbComprobante";
            this.cbComprobante.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.cbComprobante.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.cbComprobante.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.cbComprobante.Size = new System.Drawing.Size(148, 23);
            this.cbComprobante.TabIndex = 414;
            this.cbComprobante.VisualStyle = C1.Win.C1List.VisualStyle.Office2007Blue;
            this.cbComprobante.PropBag = resources.GetString("cbComprobante.PropBag");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 415;
            this.label1.Text = "Comprobante :";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.PnlSerie);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.CboSerieGuias);
            this.groupBox3.Controls.Add(this.cbComprobante2);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.BtnEditarSerie);
            this.groupBox3.Controls.Add(this.BtnNuevaSerie);
            this.groupBox3.Controls.Add(this.BtnGuardarSerie);
            this.groupBox3.Controls.Add(this.BtnCancelarSerie);
            this.groupBox3.Controls.Add(this.TxtNumero);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(13, 323);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(471, 135);
            this.groupBox3.TabIndex = 416;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ACTUALIZAR NUMERO DE IMPRESION DE LA GUIA";
            // 
            // PnlSerie
            // 
            this.PnlSerie.Controls.Add(this.TxtSerie);
            this.PnlSerie.Controls.Add(this.label8);
            this.PnlSerie.Location = new System.Drawing.Point(61, 43);
            this.PnlSerie.Name = "PnlSerie";
            this.PnlSerie.Size = new System.Drawing.Size(150, 31);
            this.PnlSerie.TabIndex = 420;
            // 
            // TxtSerie
            // 
            this.TxtSerie.BackColor = System.Drawing.Color.White;
            this.TxtSerie.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtSerie.EditMask = "000";
            this.TxtSerie.Location = new System.Drawing.Point(60, 8);
            this.TxtSerie.MaskInfo.EmptyAsNull = true;
            this.TxtSerie.MaskInfo.ErrorMessage = "Ingrese un numero valido de serie";
            this.TxtSerie.MaskInfo.Inherit = C1.Win.C1Input.MaskInfoInheritFlags.CaseSensitive;
            this.TxtSerie.MaskInfo.StoredEmptyChar = ' ';
            this.TxtSerie.MaxLength = 3;
            this.TxtSerie.Name = "TxtSerie";
            this.TxtSerie.Size = new System.Drawing.Size(87, 20);
            this.TxtSerie.TabIndex = 419;
            this.TxtSerie.Tag = null;
            this.TxtSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtSerie.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtSerie.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 418;
            this.label8.Text = "Serie:";
            // 
            // cbComprobante2
            // 
            this.cbComprobante2.AddItemSeparator = ';';
            this.cbComprobante2.Caption = "";
            this.cbComprobante2.CaptionHeight = 17;
            this.cbComprobante2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.cbComprobante2.ColumnCaptionHeight = 17;
            this.cbComprobante2.ColumnFooterHeight = 17;
            this.cbComprobante2.ColumnHeaders = false;
            this.cbComprobante2.ColumnWidth = 100;
            this.cbComprobante2.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.cbComprobante2.ContentHeight = 17;
            this.cbComprobante2.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.cbComprobante2.EditorBackColor = System.Drawing.SystemColors.Window;
            this.cbComprobante2.EditorFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbComprobante2.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.cbComprobante2.EditorHeight = 17;
            this.cbComprobante2.ExtendRightColumn = true;
            this.cbComprobante2.Images.Add(((System.Drawing.Image)(resources.GetObject("cbComprobante2.Images"))));
            this.cbComprobante2.ItemHeight = 15;
            this.cbComprobante2.Location = new System.Drawing.Point(121, 21);
            this.cbComprobante2.MatchEntryTimeout = ((long)(2000));
            this.cbComprobante2.MaxDropDownItems = ((short)(5));
            this.cbComprobante2.MaxLength = 32767;
            this.cbComprobante2.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.cbComprobante2.Name = "cbComprobante2";
            this.cbComprobante2.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.cbComprobante2.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.cbComprobante2.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.cbComprobante2.Size = new System.Drawing.Size(148, 23);
            this.cbComprobante2.TabIndex = 416;
            this.cbComprobante2.VisualStyle = C1.Win.C1List.VisualStyle.Office2007Blue;
            this.cbComprobante2.SelectedValueChanged += new System.EventHandler(this.cbComprobante2_SelectedValueChanged);
            this.cbComprobante2.PropBag = resources.GetString("cbComprobante2.PropBag");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 417;
            this.label4.Text = "Comprobante :";
            // 
            // ErrProvider
            // 
            this.ErrProvider.ContainerControl = this;
            // 
            // c1cboCia
            // 
            this.c1cboCia.AddItemSeparator = ';';
            this.c1cboCia.AutoCompletion = true;
            this.c1cboCia.AutoDropDown = true;
            this.c1cboCia.Caption = "";
            this.c1cboCia.CaptionHeight = 17;
            this.c1cboCia.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.c1cboCia.ColumnCaptionHeight = 17;
            this.c1cboCia.ColumnFooterHeight = 17;
            this.c1cboCia.ColumnHeaders = false;
            this.c1cboCia.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.c1cboCia.ContentHeight = 17;
            this.c1cboCia.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.c1cboCia.DisplayMember = "NomEmpresa";
            this.c1cboCia.EditorBackColor = System.Drawing.SystemColors.Window;
            this.c1cboCia.EditorFont = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1cboCia.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.c1cboCia.EditorHeight = 17;
            this.c1cboCia.Images.Add(((System.Drawing.Image)(resources.GetObject("c1cboCia.Images"))));
            this.c1cboCia.ItemHeight = 15;
            this.c1cboCia.Location = new System.Drawing.Point(79, 6);
            this.c1cboCia.MatchEntryTimeout = ((long)(2000));
            this.c1cboCia.MaxDropDownItems = ((short)(10));
            this.c1cboCia.MaxLength = 32767;
            this.c1cboCia.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.c1cboCia.Name = "c1cboCia";
            this.c1cboCia.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.c1cboCia.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.c1cboCia.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.c1cboCia.Size = new System.Drawing.Size(160, 23);
            this.c1cboCia.TabIndex = 417;
            this.c1cboCia.ValueMember = "EmpresaID";
            this.c1cboCia.SelectedValueChanged += new System.EventHandler(this.c1cboCia_SelectedValueChanged);
            this.c1cboCia.PropBag = resources.GetString("c1cboCia.PropBag");
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(21, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 418;
            this.label14.Text = "Empresa:";
            // 
            // MantenimientoPrecios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.c1cboCia);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "MantenimientoPrecios";
            this.Load += new System.EventHandler(this.MantenimientoPrecios_Load);
            this.Controls.SetChildIndex(this.groupBox1, 0);
            this.Controls.SetChildIndex(this.groupBox2, 0);
            this.Controls.SetChildIndex(this.groupBox3, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.c1cboCia, 0);
            ((System.ComponentModel.ISupportInitialize)(this.TxtNuevoPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboSerieGuias)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtComprobante)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCodigoVenta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCodigo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProducto)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbComprobante)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.PnlSerie.ResumeLayout(false);
            this.PnlSerie.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtSerie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbComprobante2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1cboCia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPrecioAnterior;
        private System.Windows.Forms.Label label2;
        private C1.Win.C1Input.C1TextBox TxtNuevoPrecio;
        private System.Windows.Forms.Label label3;
        private C1.Win.C1Input.C1Button BtnActualizar;
        private C1.Win.C1Input.C1Button BtnEditarSerie;
        private C1.Win.C1Input.C1Button BtnNuevaSerie;
        private C1.Win.C1Input.C1Button BtnGuardarSerie;
        private C1.Win.C1Input.C1Button BtnCancelarSerie;
        private C1.Win.C1Input.C1TextBox TxtNumero;
        private System.Windows.Forms.Label label6;
        private C1.Win.C1List.C1Combo CboSerieGuias;
        private System.Windows.Forms.Label label5;
        private C1.Win.C1Input.C1Button BtnAnular;
        private C1.Win.C1Input.C1TextBox TxtComprobante;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ErrorProvider ErrProvider;
        private System.Windows.Forms.Label LblUM;
        private System.Windows.Forms.Label label13;
        private C1.Win.C1Input.C1TextBox TxtCodigoVenta;
        private System.Windows.Forms.Label label9;
        private C1.Win.C1Input.C1TextBox TxtCodigo;
        private System.Windows.Forms.Label label7;
        private C1.Win.C1Input.C1TextBox TxtProducto;
        private System.Windows.Forms.Label label10;
        private C1.Win.C1List.C1Combo cbComprobante;
        private System.Windows.Forms.Label label1;
        private C1.Win.C1List.C1Combo cbComprobante2;
        private System.Windows.Forms.Label label4;
        private C1.Win.C1List.C1Combo c1cboCia;
        private System.Windows.Forms.Label label14;
        private C1.Win.C1Input.C1TextBox TxtSerie;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel PnlSerie;
    }
}
