﻿namespace Halley.Presentacion.Almacen
{
    partial class FrmGuiaTransporte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGuiaTransporte));
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.miniToolStrip = new System.Windows.Forms.ToolStrip();
            this.BtnImprimir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnVistaPrevia = new System.Windows.Forms.ToolStripButton();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.LstProducto = new System.Windows.Forms.ListBox();
            this.LstUM = new System.Windows.Forms.ListBox();
            this.LstCantidad = new System.Windows.Forms.ListBox();
            this.LstPeso = new System.Windows.Forms.ListBox();
            this.LstCostoMinimo = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.LblDireccion = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.LblEstado = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.TxtGuia = new System.Windows.Forms.ToolStripTextBox();
            this.BtnConsultar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnAnular = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.CboTipoGuia = new System.Windows.Forms.ToolStripComboBox();
            this.TxtConfVehicular = new C1.Win.C1Input.C1TextBox();
            this.TxtMarca = new C1.Win.C1Input.C1TextBox();
            this.TxtPlaca = new C1.Win.C1Input.C1TextBox();
            this.TxtNroConstInscripcion = new C1.Win.C1Input.C1TextBox();
            this.TxtNroLicTransaportista = new C1.Win.C1Input.C1TextBox();
            this.TxtCarrosa = new C1.Win.C1Input.C1TextBox();
            this.TxtDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtNroDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtIntDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtZonaDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDisDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtProvDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDepDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDestinatario = new C1.Win.C1Input.C1TextBox();
            this.TxtRUCRemitente = new C1.Win.C1Input.C1TextBox();
            this.TxtDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtNroDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtIntDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtZonaDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtProvDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtDepDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtRuc = new C1.Win.C1Input.C1TextBox();
            this.TxtDisDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtNumGuiatransporte = new C1.Win.C1Input.C1TextBox();
            this.TxtNombreChofer = new C1.Win.C1Input.C1TextBox();
            this.TxtRazonSocialSub = new C1.Win.C1Input.C1TextBox();
            this.TxtFechaEmision = new C1.Win.C1Input.C1TextBox();
            this.TxtFechaInicioTraslado = new C1.Win.C1Input.C1TextBox();
            this.TxtEmpresa = new C1.Win.C1Input.C1TextBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape14 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape12 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape13 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape11 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape16 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape12 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape7 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape10 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape9 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape8 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape6 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape5 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape4 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape3 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.TscContenedor = new System.Windows.Forms.ToolStripContainer();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TxtObservaciones = new C1.Win.C1Input.C1TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.TxtCliente = new C1.Win.C1Input.C1TextBox();
            this.TxtApellidosEP = new C1.Win.C1Input.C1TextBox();
            this.txtRUCSub = new C1.Win.C1Input.C1TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.TxtNumDocEP = new C1.Win.C1Input.C1TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.TxtNumDocDestinatario = new C1.Win.C1Input.C1TextBox();
            this.TxtRemitente = new C1.Win.C1Input.C1TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.TxtDireccionDestinatario = new C1.Win.C1Input.C1TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.TxtRUCDestinatario = new C1.Win.C1Input.C1TextBox();
            this.TxtNumDocRemitente = new C1.Win.C1Input.C1TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.TxtRUCEP = new C1.Win.C1Input.C1TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.TxtDireccionRemitente = new C1.Win.C1Input.C1TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConfVehicular)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMarca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPlaca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroConstInscripcion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroLicTransaportista)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCarrosa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCRemitente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRuc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumGuiatransporte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreChofer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRazonSocialSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaEmision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaInicioTraslado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmpresa)).BeginInit();
            this.TscContenedor.ContentPanel.SuspendLayout();
            this.TscContenedor.TopToolStripPanel.SuspendLayout();
            this.TscContenedor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtObservaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtApellidosEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRUCSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumDocEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumDocDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRemitente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumDocRemitente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionRemitente)).BeginInit();
            this.SuspendLayout();
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.CanOverflow = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.miniToolStrip.Location = new System.Drawing.Point(428, 3);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(431, 25);
            this.miniToolStrip.TabIndex = 343;
            // 
            // BtnImprimir
            // 
            this.BtnImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnImprimir.Image = global::Halley.Presentacion.Properties.Resources.print_16x16;
            this.BtnImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnImprimir.Name = "BtnImprimir";
            this.BtnImprimir.Size = new System.Drawing.Size(23, 22);
            this.BtnImprimir.Text = "Imprimir";
            this.BtnImprimir.Click += new System.EventHandler(this.BtnImprimir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // BtnVistaPrevia
            // 
            this.BtnVistaPrevia.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnVistaPrevia.Image = global::Halley.Presentacion.Properties.Resources.printView_16x16;
            this.BtnVistaPrevia.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnVistaPrevia.Name = "BtnVistaPrevia";
            this.BtnVistaPrevia.Size = new System.Drawing.Size(23, 22);
            this.BtnVistaPrevia.Text = "Seleccione Impresora";
            this.BtnVistaPrevia.Click += new System.EventHandler(this.BtnVistaPrevia_Click);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.AutoScroll = true;
            this.ContentPanel.Size = new System.Drawing.Size(814, 611);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(496, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "GUIA DE REMISION -TRANSPORTISTA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(167, 315);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "DESCRIPCION";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(422, 311);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "UNIDAD DE\r\nMEDIDA";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(505, 316);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "CANTIDAD";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(597, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 12);
            this.label5.TabIndex = 5;
            this.label5.Text = "PESO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(674, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "COSTO MINIMO\r\nDEL TRASLADO";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(157, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 12);
            this.label7.TabIndex = 7;
            this.label7.Text = "DOMICILIO DE PARTIDA";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(533, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 12);
            this.label8.TabIndex = 8;
            this.label8.Text = "DOMICILIO DE LLEGADA";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(177, 218);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "REMITENTE";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(562, 219);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 12);
            this.label10.TabIndex = 10;
            this.label10.Text = "DESTINATARIO";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(39, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 12);
            this.label11.TabIndex = 11;
            this.label11.Text = "FECHA DE EMISIÓN:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(181, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 12);
            this.label12.TabIndex = 12;
            this.label12.Text = "FECHA INICIO TRASLADO:";
            // 
            // LstProducto
            // 
            this.LstProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LstProducto.FormattingEnabled = true;
            this.LstProducto.Location = new System.Drawing.Point(12, 337);
            this.LstProducto.Name = "LstProducto";
            this.LstProducto.Size = new System.Drawing.Size(400, 134);
            this.LstProducto.TabIndex = 13;
            // 
            // LstUM
            // 
            this.LstUM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LstUM.FormattingEnabled = true;
            this.LstUM.Location = new System.Drawing.Point(413, 337);
            this.LstUM.Name = "LstUM";
            this.LstUM.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstUM.Size = new System.Drawing.Size(74, 134);
            this.LstUM.TabIndex = 15;
            // 
            // LstCantidad
            // 
            this.LstCantidad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LstCantidad.FormattingEnabled = true;
            this.LstCantidad.Location = new System.Drawing.Point(488, 337);
            this.LstCantidad.Name = "LstCantidad";
            this.LstCantidad.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstCantidad.Size = new System.Drawing.Size(79, 134);
            this.LstCantidad.TabIndex = 16;
            // 
            // LstPeso
            // 
            this.LstPeso.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LstPeso.FormattingEnabled = true;
            this.LstPeso.Location = new System.Drawing.Point(567, 337);
            this.LstPeso.Name = "LstPeso";
            this.LstPeso.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstPeso.Size = new System.Drawing.Size(81, 134);
            this.LstPeso.TabIndex = 17;
            // 
            // LstCostoMinimo
            // 
            this.LstCostoMinimo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LstCostoMinimo.FormattingEnabled = true;
            this.LstCostoMinimo.Location = new System.Drawing.Point(649, 337);
            this.LstCostoMinimo.Name = "LstCostoMinimo";
            this.LstCostoMinimo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstCostoMinimo.Size = new System.Drawing.Size(102, 134);
            this.LstCostoMinimo.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(577, 603);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 12);
            this.label13.TabIndex = 19;
            this.label13.Text = "Conformidad del cliente";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(547, 615);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 12);
            this.label14.TabIndex = 20;
            this.label14.Text = "Sr(a)(ta):";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(53, 473);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(190, 24);
            this.label15.TabIndex = 21;
            this.label15.Text = "DATOS DE IDENTIFICACION DE LA UNIDAD\r\nDE TRANSPORTE Y DEL CONDUCTOR";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(359, 473);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 24);
            this.label16.TabIndex = 22;
            this.label16.Text = "DATOS DE LA EMPRESA\r\nSUBCONTRATADA";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(26, 537);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 12);
            this.label17.TabIndex = 68;
            this.label17.Text = "Configuración Vehicular:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(27, 512);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 12);
            this.label19.TabIndex = 70;
            this.label19.Text = "Marca:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(27, 525);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 12);
            this.label18.TabIndex = 71;
            this.label18.Text = "Placa:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(26, 550);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(130, 12);
            this.label21.TabIndex = 74;
            this.label21.Text = "Nro Constancia de inscripcion:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(26, 564);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(115, 12);
            this.label20.TabIndex = 75;
            this.label20.Text = "Nro Licencia Transportista:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(135, 525);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 12);
            this.label22.TabIndex = 301;
            this.label22.Text = "Carrosa:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(12, 167);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 12);
            this.label23.TabIndex = 303;
            this.label23.Text = "Nro:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(124, 167);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(37, 12);
            this.label24.TabIndex = 306;
            this.label24.Text = "Interior:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(252, 167);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 308;
            this.label25.Text = "Zona:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(13, 187);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(30, 12);
            this.label28.TabIndex = 310;
            this.label28.Text = "Distri:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(128, 186);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 12);
            this.label27.TabIndex = 312;
            this.label27.Text = "Prov:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(255, 185);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(28, 12);
            this.label26.TabIndex = 314;
            this.label26.Text = "Dpto:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(14, 239);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(36, 12);
            this.label29.TabIndex = 316;
            this.label29.Text = "Sr.(es):";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(14, 258);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(35, 12);
            this.label30.TabIndex = 318;
            this.label30.Text = "R.U.C:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(391, 167);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(23, 12);
            this.label36.TabIndex = 320;
            this.label36.Text = "Nro:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(497, 165);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(37, 12);
            this.label35.TabIndex = 323;
            this.label35.Text = "Interior:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(632, 165);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 12);
            this.label34.TabIndex = 325;
            this.label34.Text = "Zona:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(391, 187);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(30, 12);
            this.label33.TabIndex = 327;
            this.label33.Text = "Distri:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(506, 185);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(28, 12);
            this.label32.TabIndex = 328;
            this.label32.Text = "Prov:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(634, 185);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(28, 12);
            this.label31.TabIndex = 330;
            this.label31.Text = "Dpto:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(500, 17);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 25);
            this.label37.TabIndex = 332;
            this.label37.Text = "R.U.C.";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(27, 501);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(62, 12);
            this.label38.TabIndex = 336;
            this.label38.Text = "Transportista:";
            // 
            // LblDireccion
            // 
            this.LblDireccion.AutoSize = true;
            this.LblDireccion.Location = new System.Drawing.Point(181, 16);
            this.LblDireccion.Name = "LblDireccion";
            this.LblDireccion.Size = new System.Drawing.Size(103, 13);
            this.LblDireccion.TabIndex = 342;
            this.LblDireccion.Text = "Aqui va la dirección:";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LblEstado,
            this.toolStripSeparator2,
            this.toolStripLabel1,
            this.TxtGuia,
            this.BtnConsultar,
            this.BtnImprimir,
            this.toolStripSeparator1,
            this.BtnVistaPrevia,
            this.toolStripSeparator3,
            this.BtnAnular,
            this.toolStripSeparator4,
            this.toolStripLabel2,
            this.CboTipoGuia});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(753, 25);
            this.toolStrip1.TabIndex = 343;
            this.toolStrip1.Text = "TsImpresion";
            // 
            // LblEstado
            // 
            this.LblEstado.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEstado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblEstado.Name = "LblEstado";
            this.LblEstado.Size = new System.Drawing.Size(59, 22);
            this.LblEstado.Text = "LblEstado";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(198, 22);
            this.toolStripLabel1.Text = "Ingrese Numero de guía a consultar:";
            // 
            // TxtGuia
            // 
            this.TxtGuia.MaxLength = 12;
            this.TxtGuia.Name = "TxtGuia";
            this.TxtGuia.Size = new System.Drawing.Size(100, 25);
            // 
            // BtnConsultar
            // 
            this.BtnConsultar.Image = global::Halley.Presentacion.Properties.Resources.Consultar_16x16;
            this.BtnConsultar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnConsultar.Name = "BtnConsultar";
            this.BtnConsultar.Size = new System.Drawing.Size(78, 22);
            this.BtnConsultar.Text = "Consultar";
            this.BtnConsultar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnConsultar.Click += new System.EventHandler(this.BtnConsultar_Click_1);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // BtnAnular
            // 
            this.BtnAnular.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAnular.Image = global::Halley.Presentacion.Properties.Resources.Cancelar_16x16;
            this.BtnAnular.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAnular.Name = "BtnAnular";
            this.BtnAnular.Size = new System.Drawing.Size(23, 22);
            this.BtnAnular.Text = "Anular Guia";
            this.BtnAnular.Click += new System.EventHandler(this.BtnAnular_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(55, 22);
            this.toolStripLabel2.Text = "Formato:";
            // 
            // CboTipoGuia
            // 
            this.CboTipoGuia.Items.AddRange(new object[] {
            "Industria",
            "Comercial",
            "Granja",
            "Palavi"});
            this.CboTipoGuia.Name = "CboTipoGuia";
            this.CboTipoGuia.Size = new System.Drawing.Size(121, 25);
            // 
            // TxtConfVehicular
            // 
            this.TxtConfVehicular.BackColor = System.Drawing.Color.LightBlue;
            this.TxtConfVehicular.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtConfVehicular.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtConfVehicular.Location = new System.Drawing.Point(132, 538);
            this.TxtConfVehicular.MaxLength = 20;
            this.TxtConfVehicular.Name = "TxtConfVehicular";
            this.TxtConfVehicular.Size = new System.Drawing.Size(128, 11);
            this.TxtConfVehicular.TabIndex = 69;
            this.TxtConfVehicular.Tag = null;
            this.TxtConfVehicular.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtConfVehicular.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtMarca
            // 
            this.TxtMarca.BackColor = System.Drawing.Color.LightBlue;
            this.TxtMarca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMarca.Location = new System.Drawing.Point(62, 513);
            this.TxtMarca.MaxLength = 50;
            this.TxtMarca.Name = "TxtMarca";
            this.TxtMarca.Size = new System.Drawing.Size(79, 11);
            this.TxtMarca.TabIndex = 72;
            this.TxtMarca.Tag = null;
            this.TxtMarca.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtMarca.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtPlaca
            // 
            this.TxtPlaca.BackColor = System.Drawing.Color.LightBlue;
            this.TxtPlaca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPlaca.Location = new System.Drawing.Point(58, 525);
            this.TxtPlaca.MaxLength = 10;
            this.TxtPlaca.Name = "TxtPlaca";
            this.TxtPlaca.Size = new System.Drawing.Size(70, 11);
            this.TxtPlaca.TabIndex = 73;
            this.TxtPlaca.Tag = null;
            this.TxtPlaca.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtPlaca.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroConstInscripcion
            // 
            this.TxtNroConstInscripcion.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNroConstInscripcion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroConstInscripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroConstInscripcion.Location = new System.Drawing.Point(156, 550);
            this.TxtNroConstInscripcion.MaxLength = 15;
            this.TxtNroConstInscripcion.Name = "TxtNroConstInscripcion";
            this.TxtNroConstInscripcion.Size = new System.Drawing.Size(128, 11);
            this.TxtNroConstInscripcion.TabIndex = 76;
            this.TxtNroConstInscripcion.Tag = null;
            this.TxtNroConstInscripcion.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroConstInscripcion.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroLicTransaportista
            // 
            this.TxtNroLicTransaportista.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNroLicTransaportista.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroLicTransaportista.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroLicTransaportista.Location = new System.Drawing.Point(146, 563);
            this.TxtNroLicTransaportista.MaxLength = 15;
            this.TxtNroLicTransaportista.Name = "TxtNroLicTransaportista";
            this.TxtNroLicTransaportista.Size = new System.Drawing.Size(128, 11);
            this.TxtNroLicTransaportista.TabIndex = 77;
            this.TxtNroLicTransaportista.Tag = null;
            this.TxtNroLicTransaportista.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroLicTransaportista.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtCarrosa
            // 
            this.TxtCarrosa.BackColor = System.Drawing.Color.LightBlue;
            this.TxtCarrosa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtCarrosa.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCarrosa.Location = new System.Drawing.Point(177, 525);
            this.TxtCarrosa.MaxLength = 10;
            this.TxtCarrosa.Name = "TxtCarrosa";
            this.TxtCarrosa.Size = new System.Drawing.Size(79, 11);
            this.TxtCarrosa.TabIndex = 302;
            this.TxtCarrosa.Tag = null;
            this.TxtCarrosa.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtCarrosa.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDomicilioPartida
            // 
            this.TxtDomicilioPartida.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDomicilioPartida.Location = new System.Drawing.Point(14, 147);
            this.TxtDomicilioPartida.MaxLength = 20;
            this.TxtDomicilioPartida.Name = "TxtDomicilioPartida";
            this.TxtDomicilioPartida.Size = new System.Drawing.Size(363, 11);
            this.TxtDomicilioPartida.TabIndex = 304;
            this.TxtDomicilioPartida.Tag = null;
            this.TxtDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroDomicilioPartida
            // 
            this.TxtNroDomicilioPartida.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNroDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroDomicilioPartida.Location = new System.Drawing.Point(34, 167);
            this.TxtNroDomicilioPartida.MaxLength = 50;
            this.TxtNroDomicilioPartida.Name = "TxtNroDomicilioPartida";
            this.TxtNroDomicilioPartida.Size = new System.Drawing.Size(79, 11);
            this.TxtNroDomicilioPartida.TabIndex = 305;
            this.TxtNroDomicilioPartida.Tag = null;
            this.TxtNroDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtIntDomicilioPartida
            // 
            this.TxtIntDomicilioPartida.BackColor = System.Drawing.Color.LightBlue;
            this.TxtIntDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtIntDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIntDomicilioPartida.Location = new System.Drawing.Point(162, 167);
            this.TxtIntDomicilioPartida.MaxLength = 50;
            this.TxtIntDomicilioPartida.Name = "TxtIntDomicilioPartida";
            this.TxtIntDomicilioPartida.Size = new System.Drawing.Size(79, 11);
            this.TxtIntDomicilioPartida.TabIndex = 307;
            this.TxtIntDomicilioPartida.Tag = null;
            this.TxtIntDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtIntDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtZonaDomicilioPartida
            // 
            this.TxtZonaDomicilioPartida.BackColor = System.Drawing.Color.LightBlue;
            this.TxtZonaDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtZonaDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtZonaDomicilioPartida.Location = new System.Drawing.Point(283, 168);
            this.TxtZonaDomicilioPartida.MaxLength = 50;
            this.TxtZonaDomicilioPartida.Name = "TxtZonaDomicilioPartida";
            this.TxtZonaDomicilioPartida.Size = new System.Drawing.Size(79, 11);
            this.TxtZonaDomicilioPartida.TabIndex = 309;
            this.TxtZonaDomicilioPartida.Tag = null;
            this.TxtZonaDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtZonaDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDisDomicilioPartida
            // 
            this.TxtDisDomicilioPartida.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDisDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDisDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDisDomicilioPartida.Location = new System.Drawing.Point(41, 187);
            this.TxtDisDomicilioPartida.MaxLength = 50;
            this.TxtDisDomicilioPartida.Name = "TxtDisDomicilioPartida";
            this.TxtDisDomicilioPartida.Size = new System.Drawing.Size(85, 11);
            this.TxtDisDomicilioPartida.TabIndex = 311;
            this.TxtDisDomicilioPartida.Tag = null;
            this.TxtDisDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDisDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtProvDomicilioPartida
            // 
            this.TxtProvDomicilioPartida.BackColor = System.Drawing.Color.LightBlue;
            this.TxtProvDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtProvDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProvDomicilioPartida.Location = new System.Drawing.Point(158, 186);
            this.TxtProvDomicilioPartida.MaxLength = 50;
            this.TxtProvDomicilioPartida.Name = "TxtProvDomicilioPartida";
            this.TxtProvDomicilioPartida.Size = new System.Drawing.Size(96, 11);
            this.TxtProvDomicilioPartida.TabIndex = 313;
            this.TxtProvDomicilioPartida.Tag = null;
            this.TxtProvDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtProvDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDepDomicilioPartida
            // 
            this.TxtDepDomicilioPartida.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDepDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDepDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDepDomicilioPartida.Location = new System.Drawing.Point(282, 185);
            this.TxtDepDomicilioPartida.MaxLength = 50;
            this.TxtDepDomicilioPartida.Name = "TxtDepDomicilioPartida";
            this.TxtDepDomicilioPartida.Size = new System.Drawing.Size(95, 11);
            this.TxtDepDomicilioPartida.TabIndex = 315;
            this.TxtDepDomicilioPartida.Tag = null;
            this.TxtDepDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDepDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDestinatario
            // 
            this.TxtDestinatario.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDestinatario.Location = new System.Drawing.Point(440, 240);
            this.TxtDestinatario.MaxLength = 50;
            this.TxtDestinatario.Name = "TxtDestinatario";
            this.TxtDestinatario.Size = new System.Drawing.Size(309, 11);
            this.TxtDestinatario.TabIndex = 317;
            this.TxtDestinatario.Tag = null;
            this.TxtDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRUCRemitente
            // 
            this.TxtRUCRemitente.BackColor = System.Drawing.Color.LightBlue;
            this.TxtRUCRemitente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRUCRemitente.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRUCRemitente.Location = new System.Drawing.Point(52, 259);
            this.TxtRUCRemitente.MaxLength = 50;
            this.TxtRUCRemitente.Name = "TxtRUCRemitente";
            this.TxtRUCRemitente.Size = new System.Drawing.Size(154, 11);
            this.TxtRUCRemitente.TabIndex = 319;
            this.TxtRUCRemitente.Tag = null;
            this.TxtRUCRemitente.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRUCRemitente.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDomicilioLlegada
            // 
            this.TxtDomicilioLlegada.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDomicilioLlegada.Location = new System.Drawing.Point(392, 148);
            this.TxtDomicilioLlegada.MaxLength = 20;
            this.TxtDomicilioLlegada.Name = "TxtDomicilioLlegada";
            this.TxtDomicilioLlegada.Size = new System.Drawing.Size(353, 11);
            this.TxtDomicilioLlegada.TabIndex = 321;
            this.TxtDomicilioLlegada.Tag = null;
            this.TxtDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroDomicilioLlegada
            // 
            this.TxtNroDomicilioLlegada.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNroDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroDomicilioLlegada.Location = new System.Drawing.Point(414, 167);
            this.TxtNroDomicilioLlegada.MaxLength = 50;
            this.TxtNroDomicilioLlegada.Name = "TxtNroDomicilioLlegada";
            this.TxtNroDomicilioLlegada.Size = new System.Drawing.Size(79, 11);
            this.TxtNroDomicilioLlegada.TabIndex = 322;
            this.TxtNroDomicilioLlegada.Tag = null;
            this.TxtNroDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtIntDomicilioLlegada
            // 
            this.TxtIntDomicilioLlegada.BackColor = System.Drawing.Color.LightBlue;
            this.TxtIntDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtIntDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIntDomicilioLlegada.Location = new System.Drawing.Point(534, 165);
            this.TxtIntDomicilioLlegada.MaxLength = 50;
            this.TxtIntDomicilioLlegada.Name = "TxtIntDomicilioLlegada";
            this.TxtIntDomicilioLlegada.Size = new System.Drawing.Size(79, 11);
            this.TxtIntDomicilioLlegada.TabIndex = 324;
            this.TxtIntDomicilioLlegada.Tag = null;
            this.TxtIntDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtIntDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtZonaDomicilioLlegada
            // 
            this.TxtZonaDomicilioLlegada.BackColor = System.Drawing.Color.LightBlue;
            this.TxtZonaDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtZonaDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtZonaDomicilioLlegada.Location = new System.Drawing.Point(664, 165);
            this.TxtZonaDomicilioLlegada.MaxLength = 50;
            this.TxtZonaDomicilioLlegada.Name = "TxtZonaDomicilioLlegada";
            this.TxtZonaDomicilioLlegada.Size = new System.Drawing.Size(79, 11);
            this.TxtZonaDomicilioLlegada.TabIndex = 326;
            this.TxtZonaDomicilioLlegada.Tag = null;
            this.TxtZonaDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtZonaDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtProvDomicilioLlegada
            // 
            this.TxtProvDomicilioLlegada.BackColor = System.Drawing.Color.LightBlue;
            this.TxtProvDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtProvDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProvDomicilioLlegada.Location = new System.Drawing.Point(534, 185);
            this.TxtProvDomicilioLlegada.MaxLength = 50;
            this.TxtProvDomicilioLlegada.Name = "TxtProvDomicilioLlegada";
            this.TxtProvDomicilioLlegada.Size = new System.Drawing.Size(96, 11);
            this.TxtProvDomicilioLlegada.TabIndex = 329;
            this.TxtProvDomicilioLlegada.Tag = null;
            this.TxtProvDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtProvDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDepDomicilioLlegada
            // 
            this.TxtDepDomicilioLlegada.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDepDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDepDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDepDomicilioLlegada.Location = new System.Drawing.Point(667, 185);
            this.TxtDepDomicilioLlegada.MaxLength = 50;
            this.TxtDepDomicilioLlegada.Name = "TxtDepDomicilioLlegada";
            this.TxtDepDomicilioLlegada.Size = new System.Drawing.Size(78, 11);
            this.TxtDepDomicilioLlegada.TabIndex = 331;
            this.TxtDepDomicilioLlegada.Tag = null;
            this.TxtDepDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDepDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRuc
            // 
            this.TxtRuc.BackColor = System.Drawing.Color.LightBlue;
            this.TxtRuc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRuc.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRuc.Location = new System.Drawing.Point(569, 16);
            this.TxtRuc.MaxLength = 50;
            this.TxtRuc.Name = "TxtRuc";
            this.TxtRuc.Size = new System.Drawing.Size(167, 26);
            this.TxtRuc.TabIndex = 333;
            this.TxtRuc.Tag = null;
            this.TxtRuc.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRuc.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDisDomicilioLlegada
            // 
            this.TxtDisDomicilioLlegada.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDisDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDisDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDisDomicilioLlegada.Location = new System.Drawing.Point(418, 186);
            this.TxtDisDomicilioLlegada.MaxLength = 50;
            this.TxtDisDomicilioLlegada.Name = "TxtDisDomicilioLlegada";
            this.TxtDisDomicilioLlegada.Size = new System.Drawing.Size(85, 11);
            this.TxtDisDomicilioLlegada.TabIndex = 334;
            this.TxtDisDomicilioLlegada.Tag = null;
            this.TxtDisDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDisDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNumGuiatransporte
            // 
            this.TxtNumGuiatransporte.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNumGuiatransporte.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNumGuiatransporte.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumGuiatransporte.Location = new System.Drawing.Point(540, 84);
            this.TxtNumGuiatransporte.MaxLength = 50;
            this.TxtNumGuiatransporte.Name = "TxtNumGuiatransporte";
            this.TxtNumGuiatransporte.Size = new System.Drawing.Size(141, 26);
            this.TxtNumGuiatransporte.TabIndex = 335;
            this.TxtNumGuiatransporte.Tag = null;
            this.TxtNumGuiatransporte.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumGuiatransporte.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNombreChofer
            // 
            this.TxtNombreChofer.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNombreChofer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNombreChofer.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNombreChofer.Location = new System.Drawing.Point(90, 502);
            this.TxtNombreChofer.MaxLength = 15;
            this.TxtNombreChofer.Name = "TxtNombreChofer";
            this.TxtNombreChofer.Size = new System.Drawing.Size(194, 11);
            this.TxtNombreChofer.TabIndex = 337;
            this.TxtNombreChofer.Tag = null;
            this.TxtNombreChofer.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNombreChofer.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRazonSocialSub
            // 
            this.TxtRazonSocialSub.BackColor = System.Drawing.Color.LightBlue;
            this.TxtRazonSocialSub.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRazonSocialSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRazonSocialSub.Location = new System.Drawing.Point(308, 519);
            this.TxtRazonSocialSub.MaxLength = 100;
            this.TxtRazonSocialSub.Multiline = true;
            this.TxtRazonSocialSub.Name = "TxtRazonSocialSub";
            this.TxtRazonSocialSub.Size = new System.Drawing.Size(212, 37);
            this.TxtRazonSocialSub.TabIndex = 338;
            this.TxtRazonSocialSub.Tag = null;
            this.TxtRazonSocialSub.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtFechaEmision
            // 
            this.TxtFechaEmision.BackColor = System.Drawing.Color.LightBlue;
            this.TxtFechaEmision.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtFechaEmision.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFechaEmision.Location = new System.Drawing.Point(47, 104);
            this.TxtFechaEmision.MaxLength = 50;
            this.TxtFechaEmision.Name = "TxtFechaEmision";
            this.TxtFechaEmision.Size = new System.Drawing.Size(96, 11);
            this.TxtFechaEmision.TabIndex = 339;
            this.TxtFechaEmision.Tag = null;
            this.TxtFechaEmision.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFechaEmision.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtFechaInicioTraslado
            // 
            this.TxtFechaInicioTraslado.BackColor = System.Drawing.Color.LightBlue;
            this.TxtFechaInicioTraslado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtFechaInicioTraslado.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFechaInicioTraslado.Location = new System.Drawing.Point(204, 104);
            this.TxtFechaInicioTraslado.MaxLength = 50;
            this.TxtFechaInicioTraslado.Name = "TxtFechaInicioTraslado";
            this.TxtFechaInicioTraslado.Size = new System.Drawing.Size(74, 11);
            this.TxtFechaInicioTraslado.TabIndex = 340;
            this.TxtFechaInicioTraslado.Tag = null;
            this.TxtFechaInicioTraslado.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFechaInicioTraslado.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtEmpresa
            // 
            this.TxtEmpresa.BackColor = System.Drawing.Color.LightBlue;
            this.TxtEmpresa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtEmpresa.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEmpresa.Location = new System.Drawing.Point(17, 55);
            this.TxtEmpresa.MaxLength = 50;
            this.TxtEmpresa.Name = "TxtEmpresa";
            this.TxtEmpresa.Size = new System.Drawing.Size(257, 26);
            this.TxtEmpresa.TabIndex = 341;
            this.TxtEmpresa.Tag = null;
            this.TxtEmpresa.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtEmpresa.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape14,
            this.rectangleShape12,
            this.lineShape13,
            this.rectangleShape11,
            this.lineShape16,
            this.lineShape12,
            this.lineShape6,
            this.lineShape5,
            this.rectangleShape7,
            this.rectangleShape10,
            this.lineShape4,
            this.rectangleShape9,
            this.lineShape3,
            this.rectangleShape8,
            this.lineShape2,
            this.rectangleShape6,
            this.rectangleShape5,
            this.rectangleShape4,
            this.rectangleShape3,
            this.rectangleShape2,
            this.lineShape1,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(765, 634);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape14
            // 
            this.lineShape14.Name = "lineShape14";
            this.lineShape14.X1 = 553;
            this.lineShape14.X2 = 702;
            this.lineShape14.Y1 = 601;
            this.lineShape14.Y2 = 601;
            // 
            // rectangleShape12
            // 
            this.rectangleShape12.CornerRadius = 3;
            this.rectangleShape12.Location = new System.Drawing.Point(12, 582);
            this.rectangleShape12.Name = "rectangleShape12";
            this.rectangleShape12.Size = new System.Drawing.Size(507, 37);
            // 
            // lineShape13
            // 
            this.lineShape13.Name = "lineShape13";
            this.lineShape13.X1 = 533;
            this.lineShape13.X2 = 752;
            this.lineShape13.Y1 = 499;
            this.lineShape13.Y2 = 499;
            // 
            // rectangleShape11
            // 
            this.rectangleShape11.CornerRadius = 3;
            this.rectangleShape11.Location = new System.Drawing.Point(531, 474);
            this.rectangleShape11.Name = "rectangleShape11";
            this.rectangleShape11.Size = new System.Drawing.Size(220, 107);
            // 
            // lineShape16
            // 
            this.lineShape16.Name = "lineShape16";
            this.lineShape16.X1 = 302;
            this.lineShape16.X2 = 525;
            this.lineShape16.Y1 = 498;
            this.lineShape16.Y2 = 498;
            // 
            // lineShape12
            // 
            this.lineShape12.Name = "lineShape12";
            this.lineShape12.X1 = 12;
            this.lineShape12.X2 = 291;
            this.lineShape12.Y1 = 497;
            this.lineShape12.Y2 = 497;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 482;
            this.lineShape6.X2 = 746;
            this.lineShape6.Y1 = 78;
            this.lineShape6.Y2 = 78;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 483;
            this.lineShape5.X2 = 745;
            this.lineShape5.Y1 = 42;
            this.lineShape5.Y2 = 42;
            // 
            // rectangleShape7
            // 
            this.rectangleShape7.CornerRadius = 3;
            this.rectangleShape7.Location = new System.Drawing.Point(170, 83);
            this.rectangleShape7.Name = "rectangleShape7";
            this.rectangleShape7.Size = new System.Drawing.Size(132, 35);
            // 
            // rectangleShape10
            // 
            this.rectangleShape10.CornerRadius = 3;
            this.rectangleShape10.Location = new System.Drawing.Point(384, 216);
            this.rectangleShape10.Name = "rectangleShape10";
            this.rectangleShape10.Size = new System.Drawing.Size(365, 88);
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 386;
            this.lineShape4.X2 = 750;
            this.lineShape4.Y1 = 234;
            this.lineShape4.Y2 = 235;
            // 
            // rectangleShape9
            // 
            this.rectangleShape9.CornerRadius = 3;
            this.rectangleShape9.Location = new System.Drawing.Point(9, 216);
            this.rectangleShape9.Name = "rectangleShape9";
            this.rectangleShape9.Size = new System.Drawing.Size(371, 88);
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 9;
            this.lineShape3.X2 = 380;
            this.lineShape3.Y1 = 234;
            this.lineShape3.Y2 = 234;
            // 
            // rectangleShape8
            // 
            this.rectangleShape8.CornerRadius = 3;
            this.rectangleShape8.Location = new System.Drawing.Point(384, 121);
            this.rectangleShape8.Name = "rectangleShape8";
            this.rectangleShape8.Size = new System.Drawing.Size(364, 88);
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 385;
            this.lineShape2.X2 = 749;
            this.lineShape2.Y1 = 141;
            this.lineShape2.Y2 = 141;
            // 
            // rectangleShape6
            // 
            this.rectangleShape6.CornerRadius = 3;
            this.rectangleShape6.Location = new System.Drawing.Point(299, 472);
            this.rectangleShape6.Name = "rectangleShape6";
            this.rectangleShape6.Size = new System.Drawing.Size(227, 107);
            // 
            // rectangleShape5
            // 
            this.rectangleShape5.CornerRadius = 3;
            this.rectangleShape5.Location = new System.Drawing.Point(11, 472);
            this.rectangleShape5.Name = "rectangleShape5";
            this.rectangleShape5.Size = new System.Drawing.Size(282, 105);
            // 
            // rectangleShape4
            // 
            this.rectangleShape4.CornerRadius = 3;
            this.rectangleShape4.Location = new System.Drawing.Point(11, 310);
            this.rectangleShape4.Name = "rectangleShape4";
            this.rectangleShape4.Size = new System.Drawing.Size(741, 160);
            // 
            // rectangleShape3
            // 
            this.rectangleShape3.CornerRadius = 3;
            this.rectangleShape3.Location = new System.Drawing.Point(11, 83);
            this.rectangleShape3.Name = "rectangleShape3";
            this.rectangleShape3.Size = new System.Drawing.Size(145, 35);
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.CornerRadius = 3;
            this.rectangleShape2.Location = new System.Drawing.Point(482, 7);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(264, 109);
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 9;
            this.lineShape1.X2 = 379;
            this.lineShape1.Y1 = 142;
            this.lineShape1.Y2 = 142;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.CornerRadius = 3;
            this.rectangleShape1.Location = new System.Drawing.Point(9, 122);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(369, 88);
            // 
            // TscContenedor
            // 
            // 
            // TscContenedor.ContentPanel
            // 
            this.TscContenedor.ContentPanel.AutoScroll = true;
            this.TscContenedor.ContentPanel.Controls.Add(this.pictureBox1);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtObservaciones);
            this.TscContenedor.ContentPanel.Controls.Add(this.label51);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtCliente);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtApellidosEP);
            this.TscContenedor.ContentPanel.Controls.Add(this.txtRUCSub);
            this.TscContenedor.ContentPanel.Controls.Add(this.label50);
            this.TscContenedor.ContentPanel.Controls.Add(this.label49);
            this.TscContenedor.ContentPanel.Controls.Add(this.label48);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNumDocEP);
            this.TscContenedor.ContentPanel.Controls.Add(this.label47);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNumDocDestinatario);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtRemitente);
            this.TscContenedor.ContentPanel.Controls.Add(this.label43);
            this.TscContenedor.ContentPanel.Controls.Add(this.label46);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDireccionDestinatario);
            this.TscContenedor.ContentPanel.Controls.Add(this.label45);
            this.TscContenedor.ContentPanel.Controls.Add(this.label44);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtRUCDestinatario);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNumDocRemitente);
            this.TscContenedor.ContentPanel.Controls.Add(this.label42);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtRUCEP);
            this.TscContenedor.ContentPanel.Controls.Add(this.label41);
            this.TscContenedor.ContentPanel.Controls.Add(this.label40);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDireccionRemitente);
            this.TscContenedor.ContentPanel.Controls.Add(this.label39);
            this.TscContenedor.ContentPanel.Controls.Add(this.LblDireccion);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtEmpresa);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtFechaInicioTraslado);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtFechaEmision);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtRazonSocialSub);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNombreChofer);
            this.TscContenedor.ContentPanel.Controls.Add(this.label38);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNumGuiatransporte);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDisDomicilioLlegada);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtRuc);
            this.TscContenedor.ContentPanel.Controls.Add(this.label37);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDepDomicilioLlegada);
            this.TscContenedor.ContentPanel.Controls.Add(this.label31);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtProvDomicilioLlegada);
            this.TscContenedor.ContentPanel.Controls.Add(this.label32);
            this.TscContenedor.ContentPanel.Controls.Add(this.label33);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtZonaDomicilioLlegada);
            this.TscContenedor.ContentPanel.Controls.Add(this.label34);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtIntDomicilioLlegada);
            this.TscContenedor.ContentPanel.Controls.Add(this.label35);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNroDomicilioLlegada);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDomicilioLlegada);
            this.TscContenedor.ContentPanel.Controls.Add(this.label36);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtRUCRemitente);
            this.TscContenedor.ContentPanel.Controls.Add(this.label30);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDestinatario);
            this.TscContenedor.ContentPanel.Controls.Add(this.label29);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDepDomicilioPartida);
            this.TscContenedor.ContentPanel.Controls.Add(this.label26);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtProvDomicilioPartida);
            this.TscContenedor.ContentPanel.Controls.Add(this.label27);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDisDomicilioPartida);
            this.TscContenedor.ContentPanel.Controls.Add(this.label28);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtZonaDomicilioPartida);
            this.TscContenedor.ContentPanel.Controls.Add(this.label25);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtIntDomicilioPartida);
            this.TscContenedor.ContentPanel.Controls.Add(this.label24);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNroDomicilioPartida);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtDomicilioPartida);
            this.TscContenedor.ContentPanel.Controls.Add(this.label23);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtCarrosa);
            this.TscContenedor.ContentPanel.Controls.Add(this.label22);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNroLicTransaportista);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtNroConstInscripcion);
            this.TscContenedor.ContentPanel.Controls.Add(this.label20);
            this.TscContenedor.ContentPanel.Controls.Add(this.label21);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtPlaca);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtMarca);
            this.TscContenedor.ContentPanel.Controls.Add(this.label18);
            this.TscContenedor.ContentPanel.Controls.Add(this.label19);
            this.TscContenedor.ContentPanel.Controls.Add(this.TxtConfVehicular);
            this.TscContenedor.ContentPanel.Controls.Add(this.label17);
            this.TscContenedor.ContentPanel.Controls.Add(this.label16);
            this.TscContenedor.ContentPanel.Controls.Add(this.label15);
            this.TscContenedor.ContentPanel.Controls.Add(this.label14);
            this.TscContenedor.ContentPanel.Controls.Add(this.label13);
            this.TscContenedor.ContentPanel.Controls.Add(this.LstCostoMinimo);
            this.TscContenedor.ContentPanel.Controls.Add(this.LstPeso);
            this.TscContenedor.ContentPanel.Controls.Add(this.LstCantidad);
            this.TscContenedor.ContentPanel.Controls.Add(this.LstUM);
            this.TscContenedor.ContentPanel.Controls.Add(this.LstProducto);
            this.TscContenedor.ContentPanel.Controls.Add(this.label12);
            this.TscContenedor.ContentPanel.Controls.Add(this.label11);
            this.TscContenedor.ContentPanel.Controls.Add(this.label10);
            this.TscContenedor.ContentPanel.Controls.Add(this.label9);
            this.TscContenedor.ContentPanel.Controls.Add(this.label8);
            this.TscContenedor.ContentPanel.Controls.Add(this.label7);
            this.TscContenedor.ContentPanel.Controls.Add(this.label6);
            this.TscContenedor.ContentPanel.Controls.Add(this.label5);
            this.TscContenedor.ContentPanel.Controls.Add(this.label4);
            this.TscContenedor.ContentPanel.Controls.Add(this.label3);
            this.TscContenedor.ContentPanel.Controls.Add(this.label2);
            this.TscContenedor.ContentPanel.Controls.Add(this.label1);
            this.TscContenedor.ContentPanel.Controls.Add(this.shapeContainer1);
            this.TscContenedor.ContentPanel.Size = new System.Drawing.Size(765, 634);
            this.TscContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TscContenedor.Location = new System.Drawing.Point(0, 0);
            this.TscContenedor.Name = "TscContenedor";
            this.TscContenedor.Size = new System.Drawing.Size(765, 659);
            this.TscContenedor.TabIndex = 344;
            this.TscContenedor.Text = "toolStripContainer1";
            // 
            // TscContenedor.TopToolStripPanel
            // 
            this.TscContenedor.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Halley.Presentacion.Properties.Resources.HalleyLogo;
            this.pictureBox1.Location = new System.Drawing.Point(13, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 358;
            this.pictureBox1.TabStop = false;
            // 
            // TxtObservaciones
            // 
            this.TxtObservaciones.BackColor = System.Drawing.Color.LightBlue;
            this.TxtObservaciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtObservaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtObservaciones.Location = new System.Drawing.Point(106, 586);
            this.TxtObservaciones.MaxLength = 200;
            this.TxtObservaciones.Multiline = true;
            this.TxtObservaciones.Name = "TxtObservaciones";
            this.TxtObservaciones.Size = new System.Drawing.Size(408, 31);
            this.TxtObservaciones.TabIndex = 345;
            this.TxtObservaciones.Tag = null;
            this.TxtObservaciones.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(29, 588);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(71, 12);
            this.label51.TabIndex = 345;
            this.label51.Text = "Observaciones:";
            // 
            // TxtCliente
            // 
            this.TxtCliente.BackColor = System.Drawing.Color.LightBlue;
            this.TxtCliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCliente.Location = new System.Drawing.Point(591, 615);
            this.TxtCliente.MaxLength = 50;
            this.TxtCliente.Name = "TxtCliente";
            this.TxtCliente.Size = new System.Drawing.Size(154, 11);
            this.TxtCliente.TabIndex = 357;
            this.TxtCliente.Tag = null;
            this.TxtCliente.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtCliente.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtApellidosEP
            // 
            this.TxtApellidosEP.BackColor = System.Drawing.Color.LightBlue;
            this.TxtApellidosEP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtApellidosEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtApellidosEP.Location = new System.Drawing.Point(540, 551);
            this.TxtApellidosEP.MaxLength = 100;
            this.TxtApellidosEP.Multiline = true;
            this.TxtApellidosEP.Name = "TxtApellidosEP";
            this.TxtApellidosEP.Size = new System.Drawing.Size(201, 23);
            this.TxtApellidosEP.TabIndex = 349;
            this.TxtApellidosEP.Tag = null;
            this.TxtApellidosEP.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // txtRUCSub
            // 
            this.txtRUCSub.BackColor = System.Drawing.Color.LightBlue;
            this.txtRUCSub.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRUCSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRUCSub.Location = new System.Drawing.Point(353, 562);
            this.txtRUCSub.MaxLength = 20;
            this.txtRUCSub.Name = "txtRUCSub";
            this.txtRUCSub.Size = new System.Drawing.Size(154, 11);
            this.txtRUCSub.TabIndex = 348;
            this.txtRUCSub.Tag = null;
            this.txtRUCSub.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.txtRUCSub.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(311, 562);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(35, 12);
            this.label50.TabIndex = 347;
            this.label50.Text = "R.U.C:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(306, 504);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(62, 12);
            this.label49.TabIndex = 346;
            this.label49.Text = "Razon Social:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(540, 538);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(93, 12);
            this.label48.TabIndex = 348;
            this.label48.Text = "Apellidos y Nombres:";
            // 
            // TxtNumDocEP
            // 
            this.TxtNumDocEP.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNumDocEP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNumDocEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumDocEP.Location = new System.Drawing.Point(656, 521);
            this.TxtNumDocEP.MaxLength = 20;
            this.TxtNumDocEP.Name = "TxtNumDocEP";
            this.TxtNumDocEP.Size = new System.Drawing.Size(92, 11);
            this.TxtNumDocEP.TabIndex = 348;
            this.TxtNumDocEP.Tag = null;
            this.TxtNumDocEP.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumDocEP.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(540, 520);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(111, 12);
            this.label47.TabIndex = 347;
            this.label47.Text = "TIPO y Nro DOC.  IDENT:";
            // 
            // TxtNumDocDestinatario
            // 
            this.TxtNumDocDestinatario.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNumDocDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNumDocDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumDocDestinatario.Location = new System.Drawing.Point(563, 287);
            this.TxtNumDocDestinatario.MaxLength = 20;
            this.TxtNumDocDestinatario.Name = "TxtNumDocDestinatario";
            this.TxtNumDocDestinatario.Size = new System.Drawing.Size(154, 11);
            this.TxtNumDocDestinatario.TabIndex = 356;
            this.TxtNumDocDestinatario.Tag = null;
            this.TxtNumDocDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumDocDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRemitente
            // 
            this.TxtRemitente.BackColor = System.Drawing.Color.LightBlue;
            this.TxtRemitente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRemitente.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRemitente.Location = new System.Drawing.Point(52, 240);
            this.TxtRemitente.MaxLength = 50;
            this.TxtRemitente.Name = "TxtRemitente";
            this.TxtRemitente.Size = new System.Drawing.Size(325, 11);
            this.TxtRemitente.TabIndex = 350;
            this.TxtRemitente.Tag = null;
            this.TxtRemitente.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRemitente.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(399, 287);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(160, 12);
            this.label43.TabIndex = 355;
            this.label43.Text = "Tipo y Nro de documento de identidad:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(399, 239);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(36, 12);
            this.label46.TabIndex = 349;
            this.label46.Text = "Sr.(es):";
            // 
            // TxtDireccionDestinatario
            // 
            this.TxtDireccionDestinatario.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDireccionDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDireccionDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDireccionDestinatario.Location = new System.Drawing.Point(446, 272);
            this.TxtDireccionDestinatario.MaxLength = 50;
            this.TxtDireccionDestinatario.Name = "TxtDireccionDestinatario";
            this.TxtDireccionDestinatario.Size = new System.Drawing.Size(303, 11);
            this.TxtDireccionDestinatario.TabIndex = 354;
            this.TxtDireccionDestinatario.Tag = null;
            this.TxtDireccionDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDireccionDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(399, 256);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 12);
            this.label45.TabIndex = 351;
            this.label45.Text = "R.U.C:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(399, 273);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(47, 12);
            this.label44.TabIndex = 353;
            this.label44.Text = "Direccion:";
            // 
            // TxtRUCDestinatario
            // 
            this.TxtRUCDestinatario.BackColor = System.Drawing.Color.LightBlue;
            this.TxtRUCDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRUCDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRUCDestinatario.Location = new System.Drawing.Point(438, 256);
            this.TxtRUCDestinatario.MaxLength = 50;
            this.TxtRUCDestinatario.Name = "TxtRUCDestinatario";
            this.TxtRUCDestinatario.Size = new System.Drawing.Size(154, 11);
            this.TxtRUCDestinatario.TabIndex = 352;
            this.TxtRUCDestinatario.Tag = null;
            this.TxtRUCDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRUCDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNumDocRemitente
            // 
            this.TxtNumDocRemitente.BackColor = System.Drawing.Color.LightBlue;
            this.TxtNumDocRemitente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNumDocRemitente.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumDocRemitente.Location = new System.Drawing.Point(178, 287);
            this.TxtNumDocRemitente.MaxLength = 20;
            this.TxtNumDocRemitente.Name = "TxtNumDocRemitente";
            this.TxtNumDocRemitente.Size = new System.Drawing.Size(154, 11);
            this.TxtNumDocRemitente.TabIndex = 348;
            this.TxtNumDocRemitente.Tag = null;
            this.TxtNumDocRemitente.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumDocRemitente.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(14, 287);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(160, 12);
            this.label42.TabIndex = 347;
            this.label42.Text = "Tipo y Nro de documento de identidad:";
            // 
            // TxtRUCEP
            // 
            this.TxtRUCEP.BackColor = System.Drawing.Color.LightBlue;
            this.TxtRUCEP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRUCEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRUCEP.Location = new System.Drawing.Point(577, 504);
            this.TxtRUCEP.MaxLength = 20;
            this.TxtRUCEP.Name = "TxtRUCEP";
            this.TxtRUCEP.Size = new System.Drawing.Size(154, 11);
            this.TxtRUCEP.TabIndex = 346;
            this.TxtRUCEP.Tag = null;
            this.TxtRUCEP.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRUCEP.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(540, 504);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(35, 12);
            this.label41.TabIndex = 345;
            this.label41.Text = "R.U.C:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(598, 481);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(94, 12);
            this.label40.TabIndex = 345;
            this.label40.Text = "EMPRESA QUE PAGA";
            // 
            // TxtDireccionRemitente
            // 
            this.TxtDireccionRemitente.BackColor = System.Drawing.Color.LightBlue;
            this.TxtDireccionRemitente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDireccionRemitente.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDireccionRemitente.Location = new System.Drawing.Point(61, 272);
            this.TxtDireccionRemitente.MaxLength = 50;
            this.TxtDireccionRemitente.Name = "TxtDireccionRemitente";
            this.TxtDireccionRemitente.Size = new System.Drawing.Size(301, 11);
            this.TxtDireccionRemitente.TabIndex = 346;
            this.TxtDireccionRemitente.Tag = null;
            this.TxtDireccionRemitente.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDireccionRemitente.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(14, 273);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(47, 12);
            this.label39.TabIndex = 345;
            this.label39.Text = "Direccion:";
            // 
            // FrmGuiaTransporte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(765, 659);
            this.Controls.Add(this.TscContenedor);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmGuiaTransporte";
            this.Text = "Guia Transporte";
            this.Load += new System.EventHandler(this.FrmGuiaTransporte_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConfVehicular)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMarca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPlaca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroConstInscripcion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroLicTransaportista)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCarrosa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCRemitente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRuc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumGuiatransporte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreChofer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRazonSocialSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaEmision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaInicioTraslado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmpresa)).EndInit();
            this.TscContenedor.ContentPanel.ResumeLayout(false);
            this.TscContenedor.ContentPanel.PerformLayout();
            this.TscContenedor.TopToolStripPanel.ResumeLayout(false);
            this.TscContenedor.TopToolStripPanel.PerformLayout();
            this.TscContenedor.ResumeLayout(false);
            this.TscContenedor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtObservaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtApellidosEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRUCSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumDocEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumDocDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRemitente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumDocRemitente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionRemitente)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.ToolStrip miniToolStrip;
        private System.Windows.Forms.ToolStripButton BtnImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton BtnVistaPrevia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox LstProducto;
        private System.Windows.Forms.ListBox LstUM;
        private System.Windows.Forms.ListBox LstCantidad;
        private System.Windows.Forms.ListBox LstPeso;
        private System.Windows.Forms.ListBox LstCostoMinimo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label LblDireccion;
        private C1.Win.C1Input.C1TextBox TxtEmpresa;
        private C1.Win.C1Input.C1TextBox TxtFechaInicioTraslado;
        private C1.Win.C1Input.C1TextBox TxtFechaEmision;
        private C1.Win.C1Input.C1TextBox TxtRazonSocialSub;
        private C1.Win.C1Input.C1TextBox TxtNombreChofer;
        private C1.Win.C1Input.C1TextBox TxtNumGuiatransporte;
        private C1.Win.C1Input.C1TextBox TxtDisDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtRuc;
        private C1.Win.C1Input.C1TextBox TxtDepDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtProvDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtZonaDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtIntDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtNroDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtRUCRemitente;
        private C1.Win.C1Input.C1TextBox TxtDestinatario;
        private C1.Win.C1Input.C1TextBox TxtDepDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtProvDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtDisDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtZonaDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtIntDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtNroDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtCarrosa;
        private C1.Win.C1Input.C1TextBox TxtNroLicTransaportista;
        private C1.Win.C1Input.C1TextBox TxtNroConstInscripcion;
        private C1.Win.C1Input.C1TextBox TxtPlaca;
        private C1.Win.C1Input.C1TextBox TxtMarca;
        private C1.Win.C1Input.C1TextBox TxtConfVehicular;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape16;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape12;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape7;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape6;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape3;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox TxtGuia;
        private System.Windows.Forms.ToolStripButton BtnConsultar;
        private System.Windows.Forms.ToolStripContainer TscContenedor;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape13;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape11;
        private System.Windows.Forms.Label label48;
        private C1.Win.C1Input.C1TextBox TxtNumDocEP;
        private System.Windows.Forms.Label label47;
        private C1.Win.C1Input.C1TextBox TxtNumDocDestinatario;
        private C1.Win.C1Input.C1TextBox TxtRemitente;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label46;
        private C1.Win.C1Input.C1TextBox TxtDireccionDestinatario;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private C1.Win.C1Input.C1TextBox TxtRUCDestinatario;
        private C1.Win.C1Input.C1TextBox TxtNumDocRemitente;
        private System.Windows.Forms.Label label42;
        private C1.Win.C1Input.C1TextBox TxtRUCEP;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private C1.Win.C1Input.C1TextBox TxtDireccionRemitente;
        private System.Windows.Forms.Label label39;
        private C1.Win.C1Input.C1TextBox TxtApellidosEP;
        private C1.Win.C1Input.C1TextBox txtRUCSub;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape12;
        private System.Windows.Forms.Label label51;
        private C1.Win.C1Input.C1TextBox TxtCliente;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape14;
        private C1.Win.C1Input.C1TextBox TxtObservaciones;
        private System.Windows.Forms.ToolStripLabel LblEstado;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton BtnAnular;
        private System.Windows.Forms.ToolStripComboBox CboTipoGuia;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.PictureBox pictureBox1;


    }
}