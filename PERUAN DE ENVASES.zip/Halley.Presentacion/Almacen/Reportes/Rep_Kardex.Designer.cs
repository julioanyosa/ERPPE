﻿namespace Halley.Presentacion.Almacen.Reportes
{
    partial class Rep_Kardex
    {
        /// <summary> 
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar 
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rep_Kardex));
            C1.Win.C1TrueDBGrid.Style style1 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style2 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style3 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style4 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style5 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style6 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style7 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style8 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style9 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style10 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style11 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style12 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style13 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style14 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style15 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style16 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style17 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style18 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style19 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style20 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style21 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style22 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style23 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style24 = new C1.Win.C1TrueDBGrid.Style();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PnlPeriodo = new System.Windows.Forms.Panel();
            this.CboAnno = new C1.Win.C1List.C1Combo();
            this.label11 = new System.Windows.Forms.Label();
            this.CboPeriodo = new C1.Win.C1List.C1Combo();
            this.label10 = new System.Windows.Forms.Label();
            this.RbPeriodo = new System.Windows.Forms.RadioButton();
            this.RbRAngo = new System.Windows.Forms.RadioButton();
            this.dtpInicial = new System.Windows.Forms.DateTimePicker();
            this.dtpFinal = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CboSede = new C1.Win.C1List.C1Combo();
            this.label6 = new System.Windows.Forms.Label();
            this.c1cboCia = new C1.Win.C1List.C1Combo();
            this.label14 = new System.Windows.Forms.Label();
            this.cbProducto = new C1.Win.C1List.C1Combo();
            this.btnConsultar = new C1.Win.C1Input.C1Button();
            this.RbAgrupadoVentas = new System.Windows.Forms.RadioButton();
            this.RbNormal = new System.Windows.Forms.RadioButton();
            this.ckbMovimiento = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbMovimiento = new C1.Win.C1List.C1Combo();
            this.txtUltMovimiento = new C1.Win.C1Input.C1TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUM = new C1.Win.C1Input.C1TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtExistencia_actual = new C1.Win.C1Input.C1TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCodigo = new C1.Win.C1Input.C1TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tdbgKardex = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
            this.TcKardex = new System.Windows.Forms.TabControl();
            this.TpKardex1 = new System.Windows.Forms.TabPage();
            this.TpKardex2 = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.TddOperacionKardex = new C1.Win.C1TrueDBGrid.C1TrueDBDropdown();
            this.TddTipoDocumento = new C1.Win.C1TrueDBGrid.C1TrueDBDropdown();
            this.TddMovimiento = new C1.Win.C1TrueDBGrid.C1TrueDBDropdown();
            this.BtnEliminar = new C1.Win.C1Input.C1Button();
            this.BtnIngresar = new C1.Win.C1Input.C1Button();
            this.BtnActualizar = new C1.Win.C1Input.C1Button();
            this.BtnMostrar = new C1.Win.C1Input.C1Button();
            this.TdgKardexValorizado = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
            this.Tp3 = new System.Windows.Forms.TabPage();
            this.TdgKardexValorizadoReal = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.CrvKardex = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.PnlPeriodo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CboAnno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboPeriodo)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CboSede)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1cboCia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbProducto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbMovimiento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUltMovimiento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtExistencia_actual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCodigo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tdbgKardex)).BeginInit();
            this.TcKardex.SuspendLayout();
            this.TpKardex1.SuspendLayout();
            this.TpKardex2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TddOperacionKardex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TddTipoDocumento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TddMovimiento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TdgKardexValorizado)).BeginInit();
            this.Tp3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TdgKardexValorizadoReal)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.btnConsultar);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1372, 76);
            this.panel2.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.PnlPeriodo);
            this.groupBox2.Controls.Add(this.RbPeriodo);
            this.groupBox2.Controls.Add(this.RbRAngo);
            this.groupBox2.Controls.Add(this.dtpInicial);
            this.groupBox2.Controls.Add(this.dtpFinal);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(652, 1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(377, 70);
            this.groupBox2.TabIndex = 419;
            this.groupBox2.TabStop = false;
            // 
            // PnlPeriodo
            // 
            this.PnlPeriodo.Controls.Add(this.CboAnno);
            this.PnlPeriodo.Controls.Add(this.label11);
            this.PnlPeriodo.Controls.Add(this.CboPeriodo);
            this.PnlPeriodo.Controls.Add(this.label10);
            this.PnlPeriodo.Location = new System.Drawing.Point(120, 9);
            this.PnlPeriodo.Name = "PnlPeriodo";
            this.PnlPeriodo.Size = new System.Drawing.Size(235, 55);
            this.PnlPeriodo.TabIndex = 416;
            // 
            // CboAnno
            // 
            this.CboAnno.AddItemSeparator = ';';
            this.CboAnno.AutoCompletion = true;
            this.CboAnno.AutoSelect = true;
            this.CboAnno.Caption = "";
            this.CboAnno.CaptionHeight = 17;
            this.CboAnno.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboAnno.ColumnCaptionHeight = 17;
            this.CboAnno.ColumnFooterHeight = 17;
            this.CboAnno.ColumnWidth = 54;
            this.CboAnno.ContentHeight = 17;
            this.CboAnno.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboAnno.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboAnno.EditorFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboAnno.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboAnno.EditorHeight = 17;
            this.CboAnno.Images.Add(((System.Drawing.Image)(resources.GetObject("CboAnno.Images"))));
            this.CboAnno.ItemHeight = 15;
            this.CboAnno.Location = new System.Drawing.Point(62, 30);
            this.CboAnno.MatchEntryTimeout = ((long)(2000));
            this.CboAnno.MaxDropDownItems = ((short)(5));
            this.CboAnno.MaxLength = 32767;
            this.CboAnno.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboAnno.Name = "CboAnno";
            this.CboAnno.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboAnno.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboAnno.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboAnno.Size = new System.Drawing.Size(82, 23);
            this.CboAnno.TabIndex = 401;
            this.CboAnno.PropBag = resources.GetString("CboAnno.PropBag");
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 13);
            this.label11.TabIndex = 400;
            this.label11.Text = "Año:";
            // 
            // CboPeriodo
            // 
            this.CboPeriodo.AddItemSeparator = ';';
            this.CboPeriodo.AutoCompletion = true;
            this.CboPeriodo.AutoSelect = true;
            this.CboPeriodo.Caption = "";
            this.CboPeriodo.CaptionHeight = 17;
            this.CboPeriodo.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboPeriodo.ColumnCaptionHeight = 17;
            this.CboPeriodo.ColumnFooterHeight = 17;
            this.CboPeriodo.ContentHeight = 17;
            this.CboPeriodo.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboPeriodo.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboPeriodo.EditorFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboPeriodo.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboPeriodo.EditorHeight = 17;
            this.CboPeriodo.Images.Add(((System.Drawing.Image)(resources.GetObject("CboPeriodo.Images"))));
            this.CboPeriodo.ItemHeight = 15;
            this.CboPeriodo.Location = new System.Drawing.Point(62, 4);
            this.CboPeriodo.MatchEntryTimeout = ((long)(2000));
            this.CboPeriodo.MaxDropDownItems = ((short)(5));
            this.CboPeriodo.MaxLength = 32767;
            this.CboPeriodo.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboPeriodo.Name = "CboPeriodo";
            this.CboPeriodo.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboPeriodo.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboPeriodo.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboPeriodo.Size = new System.Drawing.Size(160, 23);
            this.CboPeriodo.TabIndex = 399;
            this.CboPeriodo.PropBag = resources.GetString("CboPeriodo.PropBag");
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 398;
            this.label10.Text = "Periodo:";
            // 
            // RbPeriodo
            // 
            this.RbPeriodo.AutoSize = true;
            this.RbPeriodo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbPeriodo.Location = new System.Drawing.Point(9, 39);
            this.RbPeriodo.Name = "RbPeriodo";
            this.RbPeriodo.Size = new System.Drawing.Size(87, 17);
            this.RbPeriodo.TabIndex = 415;
            this.RbPeriodo.Text = "Por Periodo";
            this.RbPeriodo.UseVisualStyleBackColor = true;
            this.RbPeriodo.CheckedChanged += new System.EventHandler(this.RbPeriodo_CheckedChanged);
            // 
            // RbRAngo
            // 
            this.RbRAngo.AutoSize = true;
            this.RbRAngo.Checked = true;
            this.RbRAngo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbRAngo.Location = new System.Drawing.Point(9, 16);
            this.RbRAngo.Name = "RbRAngo";
            this.RbRAngo.Size = new System.Drawing.Size(77, 17);
            this.RbRAngo.TabIndex = 414;
            this.RbRAngo.TabStop = true;
            this.RbRAngo.Text = "Por rango";
            this.RbRAngo.UseVisualStyleBackColor = true;
            this.RbRAngo.CheckedChanged += new System.EventHandler(this.RbPeriodo_CheckedChanged);
            // 
            // dtpInicial
            // 
            this.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInicial.Location = new System.Drawing.Point(234, 12);
            this.dtpInicial.Name = "dtpInicial";
            this.dtpInicial.Size = new System.Drawing.Size(86, 22);
            this.dtpInicial.TabIndex = 115;
            // 
            // dtpFinal
            // 
            this.dtpFinal.CalendarMonthBackground = System.Drawing.Color.Yellow;
            this.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFinal.Location = new System.Drawing.Point(234, 37);
            this.dtpFinal.Name = "dtpFinal";
            this.dtpFinal.Size = new System.Drawing.Size(86, 22);
            this.dtpFinal.TabIndex = 117;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(171, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 114;
            this.label5.Text = "F. Inicial :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(178, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 116;
            this.label4.Text = "F. Final :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.CboSede);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.c1cboCia);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.cbProducto);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(9, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(641, 70);
            this.groupBox1.TabIndex = 110;
            this.groupBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(335, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 400;
            this.label7.Text = "Sede:";
            // 
            // CboSede
            // 
            this.CboSede.AddItemSeparator = ';';
            this.CboSede.AutoCompletion = true;
            this.CboSede.AutoDropDown = true;
            this.CboSede.Caption = "Seleccione Sede";
            this.CboSede.CaptionHeight = 17;
            this.CboSede.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboSede.ColumnCaptionHeight = 17;
            this.CboSede.ColumnFooterHeight = 17;
            this.CboSede.ColumnHeaders = false;
            this.CboSede.ContentHeight = 17;
            this.CboSede.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboSede.DisplayMember = "NomEmpresa";
            this.CboSede.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboSede.EditorFont = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboSede.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboSede.EditorHeight = 17;
            this.CboSede.Images.Add(((System.Drawing.Image)(resources.GetObject("CboSede.Images"))));
            this.CboSede.ItemHeight = 15;
            this.CboSede.Location = new System.Drawing.Point(376, 12);
            this.CboSede.MatchEntryTimeout = ((long)(2000));
            this.CboSede.MaxDropDownItems = ((short)(10));
            this.CboSede.MaxLength = 32767;
            this.CboSede.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboSede.Name = "CboSede";
            this.CboSede.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboSede.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboSede.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboSede.Size = new System.Drawing.Size(259, 23);
            this.CboSede.TabIndex = 399;
            this.CboSede.ValueMember = "EmpresaID";
            this.CboSede.PropBag = resources.GetString("CboSede.PropBag");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 398;
            this.label6.Text = "Productos:";
            // 
            // c1cboCia
            // 
            this.c1cboCia.AddItemSeparator = ';';
            this.c1cboCia.AutoCompletion = true;
            this.c1cboCia.AutoDropDown = true;
            this.c1cboCia.Caption = "";
            this.c1cboCia.CaptionHeight = 17;
            this.c1cboCia.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.c1cboCia.ColumnCaptionHeight = 17;
            this.c1cboCia.ColumnFooterHeight = 17;
            this.c1cboCia.ColumnHeaders = false;
            this.c1cboCia.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.c1cboCia.ContentHeight = 17;
            this.c1cboCia.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.c1cboCia.DisplayMember = "NomEmpresa";
            this.c1cboCia.EditorBackColor = System.Drawing.SystemColors.Window;
            this.c1cboCia.EditorFont = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1cboCia.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.c1cboCia.EditorHeight = 17;
            this.c1cboCia.Images.Add(((System.Drawing.Image)(resources.GetObject("c1cboCia.Images"))));
            this.c1cboCia.ItemHeight = 15;
            this.c1cboCia.Location = new System.Drawing.Point(85, 10);
            this.c1cboCia.MatchEntryTimeout = ((long)(2000));
            this.c1cboCia.MaxDropDownItems = ((short)(10));
            this.c1cboCia.MaxLength = 32767;
            this.c1cboCia.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.c1cboCia.Name = "c1cboCia";
            this.c1cboCia.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.c1cboCia.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.c1cboCia.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.c1cboCia.Size = new System.Drawing.Size(188, 23);
            this.c1cboCia.TabIndex = 396;
            this.c1cboCia.ValueMember = "EmpresaID";
            this.c1cboCia.PropBag = resources.GetString("c1cboCia.PropBag");
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(26, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 397;
            this.label14.Text = "Empresa:";
            // 
            // cbProducto
            // 
            this.cbProducto.AddItemSeparator = ';';
            this.cbProducto.Caption = "";
            this.cbProducto.CaptionHeight = 17;
            this.cbProducto.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.cbProducto.ColumnCaptionHeight = 17;
            this.cbProducto.ColumnFooterHeight = 17;
            this.cbProducto.ContentHeight = 17;
            this.cbProducto.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.cbProducto.EditorBackColor = System.Drawing.SystemColors.Window;
            this.cbProducto.EditorFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbProducto.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.cbProducto.EditorHeight = 17;
            this.cbProducto.Images.Add(((System.Drawing.Image)(resources.GetObject("cbProducto.Images"))));
            this.cbProducto.ItemHeight = 15;
            this.cbProducto.Location = new System.Drawing.Point(85, 36);
            this.cbProducto.MatchEntryTimeout = ((long)(2000));
            this.cbProducto.MaxDropDownItems = ((short)(5));
            this.cbProducto.MaxLength = 32767;
            this.cbProducto.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.cbProducto.Name = "cbProducto";
            this.cbProducto.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.cbProducto.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.cbProducto.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.cbProducto.Size = new System.Drawing.Size(550, 23);
            this.cbProducto.TabIndex = 112;
            this.cbProducto.PropBag = resources.GetString("cbProducto.PropBag");
            // 
            // btnConsultar
            // 
            this.btnConsultar.Image = ((System.Drawing.Image)(resources.GetObject("btnConsultar.Image")));
            this.btnConsultar.Location = new System.Drawing.Point(1157, 9);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(90, 23);
            this.btnConsultar.TabIndex = 118;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnConsultar.UseVisualStyleBackColor = true;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // RbAgrupadoVentas
            // 
            this.RbAgrupadoVentas.AutoSize = true;
            this.RbAgrupadoVentas.Location = new System.Drawing.Point(1198, 6);
            this.RbAgrupadoVentas.Name = "RbAgrupadoVentas";
            this.RbAgrupadoVentas.Size = new System.Drawing.Size(113, 17);
            this.RbAgrupadoVentas.TabIndex = 421;
            this.RbAgrupadoVentas.Text = "Agrupado ventas";
            this.RbAgrupadoVentas.UseVisualStyleBackColor = true;
            // 
            // RbNormal
            // 
            this.RbNormal.AutoSize = true;
            this.RbNormal.Checked = true;
            this.RbNormal.Location = new System.Drawing.Point(1121, 6);
            this.RbNormal.Name = "RbNormal";
            this.RbNormal.Size = new System.Drawing.Size(62, 17);
            this.RbNormal.TabIndex = 420;
            this.RbNormal.TabStop = true;
            this.RbNormal.Text = "Normal";
            this.RbNormal.UseVisualStyleBackColor = true;
            // 
            // ckbMovimiento
            // 
            this.ckbMovimiento.AutoSize = true;
            this.ckbMovimiento.Location = new System.Drawing.Point(5, 10);
            this.ckbMovimiento.Name = "ckbMovimiento";
            this.ckbMovimiento.Size = new System.Drawing.Size(15, 14);
            this.ckbMovimiento.TabIndex = 120;
            this.ckbMovimiento.UseVisualStyleBackColor = true;
            this.ckbMovimiento.CheckedChanged += new System.EventHandler(this.ckbMovimiento_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 13);
            this.label9.TabIndex = 113;
            this.label9.Text = "T. Movimiento :";
            // 
            // cbMovimiento
            // 
            this.cbMovimiento.AddItemSeparator = ';';
            this.cbMovimiento.Caption = "";
            this.cbMovimiento.CaptionHeight = 17;
            this.cbMovimiento.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.cbMovimiento.ColumnCaptionHeight = 17;
            this.cbMovimiento.ColumnFooterHeight = 17;
            this.cbMovimiento.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.cbMovimiento.ContentHeight = 17;
            this.cbMovimiento.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.cbMovimiento.EditorBackColor = System.Drawing.SystemColors.Window;
            this.cbMovimiento.EditorFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMovimiento.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.cbMovimiento.EditorHeight = 17;
            this.cbMovimiento.Images.Add(((System.Drawing.Image)(resources.GetObject("cbMovimiento.Images"))));
            this.cbMovimiento.ItemHeight = 15;
            this.cbMovimiento.Location = new System.Drawing.Point(111, 6);
            this.cbMovimiento.MatchEntryTimeout = ((long)(2000));
            this.cbMovimiento.MaxDropDownItems = ((short)(5));
            this.cbMovimiento.MaxLength = 32767;
            this.cbMovimiento.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.cbMovimiento.Name = "cbMovimiento";
            this.cbMovimiento.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.cbMovimiento.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.cbMovimiento.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.cbMovimiento.Size = new System.Drawing.Size(231, 23);
            this.cbMovimiento.TabIndex = 114;
            this.cbMovimiento.VisualStyle = C1.Win.C1List.VisualStyle.Office2007Blue;
            this.cbMovimiento.PropBag = resources.GetString("cbMovimiento.PropBag");
            // 
            // txtUltMovimiento
            // 
            this.txtUltMovimiento.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUltMovimiento.Location = new System.Drawing.Point(845, 6);
            this.txtUltMovimiento.Name = "txtUltMovimiento";
            this.txtUltMovimiento.Size = new System.Drawing.Size(138, 22);
            this.txtUltMovimiento.TabIndex = 118;
            this.txtUltMovimiento.Tag = null;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(771, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 13);
            this.label8.TabIndex = 117;
            this.label8.Text = "F. Ult. Mov :";
            // 
            // txtUM
            // 
            this.txtUM.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUM.Location = new System.Drawing.Point(1036, 6);
            this.txtUM.Name = "txtUM";
            this.txtUM.Size = new System.Drawing.Size(52, 22);
            this.txtUM.TabIndex = 116;
            this.txtUM.Tag = null;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(997, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 115;
            this.label3.Text = "UM :";
            // 
            // txtExistencia_actual
            // 
            this.txtExistencia_actual.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExistencia_actual.Location = new System.Drawing.Point(639, 6);
            this.txtExistencia_actual.Name = "txtExistencia_actual";
            this.txtExistencia_actual.Size = new System.Drawing.Size(122, 22);
            this.txtExistencia_actual.TabIndex = 114;
            this.txtExistencia_actual.Tag = null;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(540, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 113;
            this.label2.Text = "Existencia actual :";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigo.Location = new System.Drawing.Point(411, 6);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(122, 22);
            this.txtCodigo.TabIndex = 112;
            this.txtCodigo.Tag = null;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(355, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 111;
            this.label1.Text = "Codigo :";
            // 
            // tdbgKardex
            // 
            this.tdbgKardex.AllowUpdate = false;
            this.tdbgKardex.AlternatingRows = true;
            this.tdbgKardex.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tdbgKardex.CaptionHeight = 17;
            this.tdbgKardex.CausesValidation = false;
            this.tdbgKardex.DirectionAfterEnter = C1.Win.C1TrueDBGrid.DirectionAfterEnterEnum.MoveUp;
            this.tdbgKardex.EmptyRows = true;
            this.tdbgKardex.FilterBar = true;
            this.tdbgKardex.FlatStyle = C1.Win.C1TrueDBGrid.FlatModeEnum.Standard;
            this.tdbgKardex.GroupByCaption = "Drag a column header here to group by that column";
            this.tdbgKardex.Images.Add(((System.Drawing.Image)(resources.GetObject("tdbgKardex.Images"))));
            this.tdbgKardex.Location = new System.Drawing.Point(3, 35);
            this.tdbgKardex.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightRow;
            this.tdbgKardex.Name = "tdbgKardex";
            this.tdbgKardex.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.tdbgKardex.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.tdbgKardex.PreviewInfo.ZoomFactor = 75D;
            this.tdbgKardex.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("tdbgKardex.PrintInfo.PageSettings")));
            this.tdbgKardex.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.tdbgKardex.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.None;
            this.tdbgKardex.RowHeight = 15;
            this.tdbgKardex.Size = new System.Drawing.Size(1327, 333);
            this.tdbgKardex.TabIndex = 92;
            this.tdbgKardex.Text = "Productos Genéricos";
            this.tdbgKardex.FormatText += new C1.Win.C1TrueDBGrid.FormatTextEventHandler(this.tdbgKardex_FormatText);
            this.tdbgKardex.PropBag = resources.GetString("tdbgKardex.PropBag");
            // 
            // TcKardex
            // 
            this.TcKardex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.TcKardex.Controls.Add(this.TpKardex1);
            this.TcKardex.Controls.Add(this.TpKardex2);
            this.TcKardex.Controls.Add(this.Tp3);
            this.TcKardex.Controls.Add(this.tabPage1);
            this.TcKardex.Location = new System.Drawing.Point(9, 82);
            this.TcKardex.Name = "TcKardex";
            this.TcKardex.SelectedIndex = 0;
            this.TcKardex.Size = new System.Drawing.Size(1344, 397);
            this.TcKardex.TabIndex = 7;
            // 
            // TpKardex1
            // 
            this.TpKardex1.Controls.Add(this.txtUM);
            this.TpKardex1.Controls.Add(this.label3);
            this.TpKardex1.Controls.Add(this.txtUltMovimiento);
            this.TpKardex1.Controls.Add(this.ckbMovimiento);
            this.TpKardex1.Controls.Add(this.label8);
            this.TpKardex1.Controls.Add(this.label9);
            this.TpKardex1.Controls.Add(this.tdbgKardex);
            this.TpKardex1.Controls.Add(this.cbMovimiento);
            this.TpKardex1.Controls.Add(this.txtCodigo);
            this.TpKardex1.Controls.Add(this.label1);
            this.TpKardex1.Controls.Add(this.txtExistencia_actual);
            this.TpKardex1.Controls.Add(this.label2);
            this.TpKardex1.Location = new System.Drawing.Point(4, 22);
            this.TpKardex1.Name = "TpKardex1";
            this.TpKardex1.Padding = new System.Windows.Forms.Padding(3);
            this.TpKardex1.Size = new System.Drawing.Size(1336, 371);
            this.TpKardex1.TabIndex = 0;
            this.TpKardex1.Text = "Con Almacenes";
            this.TpKardex1.UseVisualStyleBackColor = true;
            // 
            // TpKardex2
            // 
            this.TpKardex2.Controls.Add(this.label12);
            this.TpKardex2.Controls.Add(this.RbAgrupadoVentas);
            this.TpKardex2.Controls.Add(this.TddOperacionKardex);
            this.TpKardex2.Controls.Add(this.TddTipoDocumento);
            this.TpKardex2.Controls.Add(this.RbNormal);
            this.TpKardex2.Controls.Add(this.TddMovimiento);
            this.TpKardex2.Controls.Add(this.BtnEliminar);
            this.TpKardex2.Controls.Add(this.BtnIngresar);
            this.TpKardex2.Controls.Add(this.BtnActualizar);
            this.TpKardex2.Controls.Add(this.BtnMostrar);
            this.TpKardex2.Controls.Add(this.TdgKardexValorizado);
            this.TpKardex2.Location = new System.Drawing.Point(4, 22);
            this.TpKardex2.Name = "TpKardex2";
            this.TpKardex2.Padding = new System.Windows.Forms.Padding(3);
            this.TpKardex2.Size = new System.Drawing.Size(1336, 371);
            this.TpKardex2.TabIndex = 1;
            this.TpKardex2.Text = "Por Producto";
            this.TpKardex2.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1038, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 13);
            this.label12.TabIndex = 422;
            this.label12.Text = "Tipo Reporte:";
            // 
            // TddOperacionKardex
            // 
            this.TddOperacionKardex.AllowColMove = true;
            this.TddOperacionKardex.AllowColSelect = true;
            this.TddOperacionKardex.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows;
            this.TddOperacionKardex.AlternatingRows = false;
            this.TddOperacionKardex.CaptionHeight = 17;
            this.TddOperacionKardex.CaptionStyle = style1;
            this.TddOperacionKardex.ColumnCaptionHeight = 17;
            this.TddOperacionKardex.ColumnFooterHeight = 17;
            this.TddOperacionKardex.EvenRowStyle = style2;
            this.TddOperacionKardex.FetchRowStyles = false;
            this.TddOperacionKardex.FooterStyle = style3;
            this.TddOperacionKardex.HeadingStyle = style4;
            this.TddOperacionKardex.HighLightRowStyle = style5;
            this.TddOperacionKardex.Images.Add(((System.Drawing.Image)(resources.GetObject("TddOperacionKardex.Images"))));
            this.TddOperacionKardex.Location = new System.Drawing.Point(37, 99);
            this.TddOperacionKardex.Name = "TddOperacionKardex";
            this.TddOperacionKardex.OddRowStyle = style6;
            this.TddOperacionKardex.RecordSelectorStyle = style7;
            this.TddOperacionKardex.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.TddOperacionKardex.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.Single;
            this.TddOperacionKardex.RowHeight = 15;
            this.TddOperacionKardex.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.TddOperacionKardex.ScrollTips = false;
            this.TddOperacionKardex.Size = new System.Drawing.Size(340, 147);
            this.TddOperacionKardex.Style = style8;
            this.TddOperacionKardex.TabIndex = 125;
            this.TddOperacionKardex.TabStop = false;
            this.TddOperacionKardex.Text = "c1TrueDBDropdown1";
            this.TddOperacionKardex.Visible = false;
            this.TddOperacionKardex.PropBag = resources.GetString("TddOperacionKardex.PropBag");
            // 
            // TddTipoDocumento
            // 
            this.TddTipoDocumento.AllowColMove = true;
            this.TddTipoDocumento.AllowColSelect = true;
            this.TddTipoDocumento.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows;
            this.TddTipoDocumento.AlternatingRows = false;
            this.TddTipoDocumento.CaptionHeight = 17;
            this.TddTipoDocumento.CaptionStyle = style9;
            this.TddTipoDocumento.ColumnCaptionHeight = 17;
            this.TddTipoDocumento.ColumnFooterHeight = 17;
            this.TddTipoDocumento.EvenRowStyle = style10;
            this.TddTipoDocumento.FetchRowStyles = false;
            this.TddTipoDocumento.FooterStyle = style11;
            this.TddTipoDocumento.HeadingStyle = style12;
            this.TddTipoDocumento.HighLightRowStyle = style13;
            this.TddTipoDocumento.Images.Add(((System.Drawing.Image)(resources.GetObject("TddTipoDocumento.Images"))));
            this.TddTipoDocumento.Location = new System.Drawing.Point(438, 141);
            this.TddTipoDocumento.Name = "TddTipoDocumento";
            this.TddTipoDocumento.OddRowStyle = style14;
            this.TddTipoDocumento.RecordSelectorStyle = style15;
            this.TddTipoDocumento.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.TddTipoDocumento.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.Single;
            this.TddTipoDocumento.RowHeight = 15;
            this.TddTipoDocumento.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.TddTipoDocumento.ScrollTips = false;
            this.TddTipoDocumento.Size = new System.Drawing.Size(397, 163);
            this.TddTipoDocumento.Style = style16;
            this.TddTipoDocumento.TabIndex = 124;
            this.TddTipoDocumento.TabStop = false;
            this.TddTipoDocumento.Text = "c1TrueDBDropdown2";
            this.TddTipoDocumento.Visible = false;
            this.TddTipoDocumento.PropBag = resources.GetString("TddTipoDocumento.PropBag");
            // 
            // TddMovimiento
            // 
            this.TddMovimiento.AllowColMove = true;
            this.TddMovimiento.AllowColSelect = true;
            this.TddMovimiento.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows;
            this.TddMovimiento.AlternatingRows = false;
            this.TddMovimiento.CaptionHeight = 17;
            this.TddMovimiento.CaptionStyle = style17;
            this.TddMovimiento.ColumnCaptionHeight = 17;
            this.TddMovimiento.ColumnFooterHeight = 17;
            this.TddMovimiento.EvenRowStyle = style18;
            this.TddMovimiento.FetchRowStyles = false;
            this.TddMovimiento.FooterStyle = style19;
            this.TddMovimiento.HeadingStyle = style20;
            this.TddMovimiento.HighLightRowStyle = style21;
            this.TddMovimiento.Images.Add(((System.Drawing.Image)(resources.GetObject("TddMovimiento.Images"))));
            this.TddMovimiento.Location = new System.Drawing.Point(730, 103);
            this.TddMovimiento.Name = "TddMovimiento";
            this.TddMovimiento.OddRowStyle = style22;
            this.TddMovimiento.RecordSelectorStyle = style23;
            this.TddMovimiento.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.TddMovimiento.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.Single;
            this.TddMovimiento.RowHeight = 15;
            this.TddMovimiento.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.TddMovimiento.ScrollTips = false;
            this.TddMovimiento.Size = new System.Drawing.Size(338, 143);
            this.TddMovimiento.Style = style24;
            this.TddMovimiento.TabIndex = 123;
            this.TddMovimiento.TabStop = false;
            this.TddMovimiento.Text = "c1TrueDBDropdown1";
            this.TddMovimiento.Visible = false;
            this.TddMovimiento.RowChange += new System.EventHandler(this.TddMovimiento_RowChange);
            this.TddMovimiento.PropBag = resources.GetString("TddMovimiento.PropBag");
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Image = ((System.Drawing.Image)(resources.GetObject("BtnEliminar.Image")));
            this.BtnEliminar.Location = new System.Drawing.Point(6, 3);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(86, 23);
            this.BtnEliminar.TabIndex = 122;
            this.BtnEliminar.Text = "Eliminar";
            this.BtnEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // BtnIngresar
            // 
            this.BtnIngresar.Image = ((System.Drawing.Image)(resources.GetObject("BtnIngresar.Image")));
            this.BtnIngresar.Location = new System.Drawing.Point(838, 3);
            this.BtnIngresar.Name = "BtnIngresar";
            this.BtnIngresar.Size = new System.Drawing.Size(86, 23);
            this.BtnIngresar.TabIndex = 121;
            this.BtnIngresar.Text = "Ingresar";
            this.BtnIngresar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnIngresar.UseVisualStyleBackColor = true;
            this.BtnIngresar.Click += new System.EventHandler(this.BtnIngresar_Click);
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.Image = ((System.Drawing.Image)(resources.GetObject("BtnActualizar.Image")));
            this.BtnActualizar.Location = new System.Drawing.Point(98, 3);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(86, 23);
            this.BtnActualizar.TabIndex = 120;
            this.BtnActualizar.Text = "Actualizar";
            this.BtnActualizar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // BtnMostrar
            // 
            this.BtnMostrar.Image = ((System.Drawing.Image)(resources.GetObject("BtnMostrar.Image")));
            this.BtnMostrar.Location = new System.Drawing.Point(930, 3);
            this.BtnMostrar.Name = "BtnMostrar";
            this.BtnMostrar.Size = new System.Drawing.Size(86, 23);
            this.BtnMostrar.TabIndex = 119;
            this.BtnMostrar.Text = "Mostrar";
            this.BtnMostrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnMostrar.UseVisualStyleBackColor = true;
            this.BtnMostrar.Click += new System.EventHandler(this.BtnMostrar_Click);
            // 
            // TdgKardexValorizado
            // 
            this.TdgKardexValorizado.AlternatingRows = true;
            this.TdgKardexValorizado.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.TdgKardexValorizado.CaptionHeight = 17;
            this.TdgKardexValorizado.DirectionAfterEnter = C1.Win.C1TrueDBGrid.DirectionAfterEnterEnum.MoveLeft;
            this.TdgKardexValorizado.EmptyRows = true;
            this.TdgKardexValorizado.FilterBar = true;
            this.TdgKardexValorizado.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TdgKardexValorizado.GroupByCaption = "Drag a column header here to group by that column";
            this.TdgKardexValorizado.Images.Add(((System.Drawing.Image)(resources.GetObject("TdgKardexValorizado.Images"))));
            this.TdgKardexValorizado.LinesPerRow = 2;
            this.TdgKardexValorizado.Location = new System.Drawing.Point(3, 29);
            this.TdgKardexValorizado.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightCell;
            this.TdgKardexValorizado.Name = "TdgKardexValorizado";
            this.TdgKardexValorizado.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.TdgKardexValorizado.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.TdgKardexValorizado.PreviewInfo.ZoomFactor = 75D;
            this.TdgKardexValorizado.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("TdgKardexValorizado.PrintInfo.PageSettings")));
            this.TdgKardexValorizado.RowHeight = 15;
            this.TdgKardexValorizado.Size = new System.Drawing.Size(1308, 342);
            this.TdgKardexValorizado.TabIndex = 0;
            this.TdgKardexValorizado.Text = "c1TrueDBGrid1";
            this.TdgKardexValorizado.AfterColEdit += new C1.Win.C1TrueDBGrid.ColEventHandler(this.TdgKardexValorizado_AfterColEdit);
            this.TdgKardexValorizado.PropBag = resources.GetString("TdgKardexValorizado.PropBag");
            // 
            // Tp3
            // 
            this.Tp3.Controls.Add(this.TdgKardexValorizadoReal);
            this.Tp3.Location = new System.Drawing.Point(4, 22);
            this.Tp3.Name = "Tp3";
            this.Tp3.Padding = new System.Windows.Forms.Padding(3);
            this.Tp3.Size = new System.Drawing.Size(1336, 371);
            this.Tp3.TabIndex = 2;
            this.Tp3.Text = "Producto Real";
            this.Tp3.UseVisualStyleBackColor = true;
            // 
            // TdgKardexValorizadoReal
            // 
            this.TdgKardexValorizadoReal.AllowUpdate = false;
            this.TdgKardexValorizadoReal.AlternatingRows = true;
            this.TdgKardexValorizadoReal.CaptionHeight = 17;
            this.TdgKardexValorizadoReal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TdgKardexValorizadoReal.EmptyRows = true;
            this.TdgKardexValorizadoReal.FilterBar = true;
            this.TdgKardexValorizadoReal.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TdgKardexValorizadoReal.GroupByCaption = "Drag a column header here to group by that column";
            this.TdgKardexValorizadoReal.Images.Add(((System.Drawing.Image)(resources.GetObject("TdgKardexValorizadoReal.Images"))));
            this.TdgKardexValorizadoReal.LinesPerRow = 2;
            this.TdgKardexValorizadoReal.Location = new System.Drawing.Point(3, 3);
            this.TdgKardexValorizadoReal.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightCell;
            this.TdgKardexValorizadoReal.Name = "TdgKardexValorizadoReal";
            this.TdgKardexValorizadoReal.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.TdgKardexValorizadoReal.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.TdgKardexValorizadoReal.PreviewInfo.ZoomFactor = 75D;
            this.TdgKardexValorizadoReal.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("TdgKardexValorizadoReal.PrintInfo.PageSettings")));
            this.TdgKardexValorizadoReal.RowHeight = 15;
            this.TdgKardexValorizadoReal.Size = new System.Drawing.Size(1330, 365);
            this.TdgKardexValorizadoReal.TabIndex = 1;
            this.TdgKardexValorizadoReal.Text = "c1TrueDBGrid1";
            this.TdgKardexValorizadoReal.PropBag = resources.GetString("TdgKardexValorizadoReal.PropBag");
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.CrvKardex);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1336, 371);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Solo Ventas";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // CrvKardex
            // 
            this.CrvKardex.ActiveViewIndex = -1;
            this.CrvKardex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CrvKardex.Cursor = System.Windows.Forms.Cursors.Default;
            this.CrvKardex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CrvKardex.Location = new System.Drawing.Point(3, 3);
            this.CrvKardex.Name = "CrvKardex";
            this.CrvKardex.Size = new System.Drawing.Size(1330, 365);
            this.CrvKardex.TabIndex = 8;
            // 
            // Rep_Kardex
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.TcKardex);
            this.Controls.Add(this.panel2);
            this.Name = "Rep_Kardex";
            this.Size = new System.Drawing.Size(1372, 507);
            this.Load += new System.EventHandler(this.Rep_Kardex_Load);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.TcKardex, 0);
            this.panel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.PnlPeriodo.ResumeLayout(false);
            this.PnlPeriodo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CboAnno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboPeriodo)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CboSede)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1cboCia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbProducto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbMovimiento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUltMovimiento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtExistencia_actual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCodigo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tdbgKardex)).EndInit();
            this.TcKardex.ResumeLayout(false);
            this.TpKardex1.ResumeLayout(false);
            this.TpKardex1.PerformLayout();
            this.TpKardex2.ResumeLayout(false);
            this.TpKardex2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TddOperacionKardex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TddTipoDocumento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TddMovimiento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TdgKardexValorizado)).EndInit();
            this.Tp3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TdgKardexValorizadoReal)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private C1.Win.C1TrueDBGrid.C1TrueDBGrid tdbgKardex;
        private System.Windows.Forms.GroupBox groupBox1;
        private C1.Win.C1Input.C1Button btnConsultar;
        private System.Windows.Forms.DateTimePicker dtpFinal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpInicial;
        private System.Windows.Forms.Label label5;
        private C1.Win.C1Input.C1TextBox txtUltMovimiento;
        private System.Windows.Forms.Label label8;
        private C1.Win.C1Input.C1TextBox txtUM;
        private System.Windows.Forms.Label label3;
        private C1.Win.C1Input.C1TextBox txtExistencia_actual;
        private System.Windows.Forms.Label label2;
        private C1.Win.C1Input.C1TextBox txtCodigo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private C1.Win.C1List.C1Combo cbMovimiento;
        private System.Windows.Forms.CheckBox ckbMovimiento;
        private System.Windows.Forms.TabControl TcKardex;
        private System.Windows.Forms.TabPage TpKardex1;
        private System.Windows.Forms.TabPage TpKardex2;
        private C1.Win.C1List.C1Combo c1cboCia;
        private System.Windows.Forms.Label label14;
        private C1.Win.C1TrueDBGrid.C1TrueDBGrid TdgKardexValorizado;
        private C1.Win.C1Input.C1Button BtnMostrar;
        private C1.Win.C1Input.C1Button BtnActualizar;
        private C1.Win.C1Input.C1Button BtnIngresar;
        private C1.Win.C1List.C1Combo CboPeriodo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel PnlPeriodo;
        private System.Windows.Forms.RadioButton RbPeriodo;
        private System.Windows.Forms.RadioButton RbRAngo;
        private C1.Win.C1List.C1Combo CboAnno;
        private System.Windows.Forms.Label label11;
        private C1.Win.C1List.C1Combo cbProducto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton RbAgrupadoVentas;
        private System.Windows.Forms.RadioButton RbNormal;
        private System.Windows.Forms.Label label7;
        private C1.Win.C1List.C1Combo CboSede;
        private C1.Win.C1Input.C1Button BtnEliminar;
        private System.Windows.Forms.TabPage Tp3;
        private C1.Win.C1TrueDBGrid.C1TrueDBGrid TdgKardexValorizadoReal;
        private C1.Win.C1TrueDBGrid.C1TrueDBDropdown TddMovimiento;
        private C1.Win.C1TrueDBGrid.C1TrueDBDropdown TddTipoDocumento;
        private C1.Win.C1TrueDBGrid.C1TrueDBDropdown TddOperacionKardex;
        private System.Windows.Forms.TabPage tabPage1;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer CrvKardex;
        private System.Windows.Forms.Label label12;

    }
}
