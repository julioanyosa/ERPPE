﻿namespace Halley.Presentacion.Almacen
{
    partial class FrmGuiaRemision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGuiaRemision));
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.miniToolStrip = new System.Windows.Forms.ToolStrip();
            this.BtnImprimir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnVistaPrevia = new System.Windows.Forms.ToolStripButton();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.LstProducto = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LstUM = new System.Windows.Forms.ListBox();
            this.LstCantidad = new System.Windows.Forms.ListBox();
            this.LstPeso = new System.Windows.Forms.ListBox();
            this.LstCostoMinimo = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.LblEstado = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.TxtGuia = new System.Windows.Forms.ToolStripTextBox();
            this.BtnConsultar = new System.Windows.Forms.ToolStripButton();
            this.BtnAnular = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.CboTipoGuia = new System.Windows.Forms.ToolStripComboBox();
            this.TxtMarca = new C1.Win.C1Input.C1TextBox();
            this.TxtPlaca = new C1.Win.C1Input.C1TextBox();
            this.TxtNroConstInscripcion = new C1.Win.C1Input.C1TextBox();
            this.TxtNroLicTransaportista = new C1.Win.C1Input.C1TextBox();
            this.TxtDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtNroDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtIntDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtZonaDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDisDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtProvDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDepDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDestinatario = new C1.Win.C1Input.C1TextBox();
            this.TxtRUCDestinatario = new C1.Win.C1Input.C1TextBox();
            this.TxtDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtNroDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtIntDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtZonaDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtProvDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtDepDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtDisDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtNumGuiaRemision = new C1.Win.C1Input.C1TextBox();
            this.TxtNombreChofer = new C1.Win.C1Input.C1TextBox();
            this.TxtMotivo = new C1.Win.C1Input.C1TextBox();
            this.TxtFechaEmision = new C1.Win.C1Input.C1TextBox();
            this.TxtFechaInicioTraslado = new C1.Win.C1Input.C1TextBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape12 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape11 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape10 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape11 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape10 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape9 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape8 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape7 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape6 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape5 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape4 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape3 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.TxtConfVehicular = new C1.Win.C1Input.C1TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.LblEmpresa = new System.Windows.Forms.Label();
            this.LblRuc = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.TxtTipoComprobante = new C1.Win.C1Input.C1TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.TxtRucTransportista = new C1.Win.C1Input.C1TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.TxtTransportista2 = new C1.Win.C1Input.C1TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtDocIdentidad = new C1.Win.C1Input.C1TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.TxtNroFactura = new C1.Win.C1Input.C1TextBox();
            this.LblDireccion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMarca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPlaca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroConstInscripcion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroLicTransaportista)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumGuiaRemision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreChofer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMotivo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaEmision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaInicioTraslado)).BeginInit();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConfVehicular)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTipoComprobante)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRucTransportista)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTransportista2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDocIdentidad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroFactura)).BeginInit();
            this.SuspendLayout();
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.CanOverflow = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.miniToolStrip.Location = new System.Drawing.Point(428, 3);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(431, 25);
            this.miniToolStrip.TabIndex = 343;
            // 
            // BtnImprimir
            // 
            this.BtnImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnImprimir.Image = global::Halley.Presentacion.Properties.Resources.print_16x16;
            this.BtnImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnImprimir.Name = "BtnImprimir";
            this.BtnImprimir.Size = new System.Drawing.Size(23, 22);
            this.BtnImprimir.Text = "Imprimir";
            this.BtnImprimir.Click += new System.EventHandler(this.BtnImprimir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // BtnVistaPrevia
            // 
            this.BtnVistaPrevia.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnVistaPrevia.Image = global::Halley.Presentacion.Properties.Resources.printView_16x16;
            this.BtnVistaPrevia.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnVistaPrevia.Name = "BtnVistaPrevia";
            this.BtnVistaPrevia.Size = new System.Drawing.Size(23, 22);
            this.BtnVistaPrevia.Text = "Seleccionar impresora";
            this.BtnVistaPrevia.Click += new System.EventHandler(this.BtnVistaPrevia_Click);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.AutoScroll = true;
            this.ContentPanel.Size = new System.Drawing.Size(814, 611);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(436, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "GUIA DE REMISION -REMITENTE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(150, 317);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "DESCRIPCION";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(442, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "UNID. DE\r\nMED.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(497, 318);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "CANTIDAD";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(559, 319);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 12);
            this.label5.TabIndex = 5;
            this.label5.Text = "PESO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(618, 312);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "COSTO MINIMO\r\nDEL TRASLADO";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(114, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 12);
            this.label7.TabIndex = 7;
            this.label7.Text = "DOMICILIO DE PARTIDA";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(464, 132);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 12);
            this.label8.TabIndex = 8;
            this.label8.Text = "DOMICILIO DE LLEGADA";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(143, 227);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "DESTINATARIO";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(436, 227);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(182, 12);
            this.label10.TabIndex = 10;
            this.label10.Text = "UNIDAD DE TRANSPORTE / CONDUCTOR";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(30, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 12);
            this.label11.TabIndex = 11;
            this.label11.Text = "FECHA DE EMISIÓN:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(180, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 12);
            this.label12.TabIndex = 12;
            this.label12.Text = "FECHA INICIO TRASLADO:";
            // 
            // LstProducto
            // 
            this.LstProducto.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstProducto.FormattingEnabled = true;
            this.LstProducto.Location = new System.Drawing.Point(14, 336);
            this.LstProducto.Name = "LstProducto";
            this.LstProducto.Size = new System.Drawing.Size(421, 160);
            this.LstProducto.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Halley.Presentacion.Properties.Resources.HalleyLogo;
            this.pictureBox1.Location = new System.Drawing.Point(8, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // LstUM
            // 
            this.LstUM.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstUM.FormattingEnabled = true;
            this.LstUM.Location = new System.Drawing.Point(436, 336);
            this.LstUM.Name = "LstUM";
            this.LstUM.Size = new System.Drawing.Size(53, 160);
            this.LstUM.TabIndex = 15;
            // 
            // LstCantidad
            // 
            this.LstCantidad.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstCantidad.FormattingEnabled = true;
            this.LstCantidad.Location = new System.Drawing.Point(490, 336);
            this.LstCantidad.Name = "LstCantidad";
            this.LstCantidad.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstCantidad.Size = new System.Drawing.Size(59, 160);
            this.LstCantidad.TabIndex = 16;
            // 
            // LstPeso
            // 
            this.LstPeso.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstPeso.FormattingEnabled = true;
            this.LstPeso.Location = new System.Drawing.Point(552, 336);
            this.LstPeso.Name = "LstPeso";
            this.LstPeso.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstPeso.Size = new System.Drawing.Size(53, 160);
            this.LstPeso.TabIndex = 17;
            // 
            // LstCostoMinimo
            // 
            this.LstCostoMinimo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstCostoMinimo.FormattingEnabled = true;
            this.LstCostoMinimo.Location = new System.Drawing.Point(602, 336);
            this.LstCostoMinimo.Name = "LstCostoMinimo";
            this.LstCostoMinimo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstCostoMinimo.Size = new System.Drawing.Size(95, 160);
            this.LstCostoMinimo.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(577, 584);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 12);
            this.label13.TabIndex = 19;
            this.label13.Text = "Conformidad del cliente";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(564, 613);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 12);
            this.label14.TabIndex = 20;
            this.label14.Text = "Sr(a)(ta):";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(82, 503);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 21;
            this.label15.Text = "TRANSPORTISTA";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(352, 502);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 12);
            this.label16.TabIndex = 22;
            this.label16.Text = "MOTIVO DEL TRASLADO";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(363, 242);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(118, 12);
            this.label17.TabIndex = 68;
            this.label17.Text = "Vehiculo Marca y Placa N°:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(363, 259);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(130, 12);
            this.label21.TabIndex = 74;
            this.label21.Text = "Nro Constancia de inscripcion:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(363, 274);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(115, 12);
            this.label20.TabIndex = 75;
            this.label20.Text = "Nro Licencia Transportista:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(9, 168);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 12);
            this.label23.TabIndex = 303;
            this.label23.Text = "Nro:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(125, 168);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(37, 12);
            this.label24.TabIndex = 306;
            this.label24.Text = "Interior:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(243, 168);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 308;
            this.label25.Text = "Zona:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(10, 190);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(38, 12);
            this.label28.TabIndex = 310;
            this.label28.Text = "Distrito:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(134, 190);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 12);
            this.label27.TabIndex = 312;
            this.label27.Text = "Prov:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(248, 190);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(28, 12);
            this.label26.TabIndex = 314;
            this.label26.Text = "Dpto:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(20, 245);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(36, 12);
            this.label29.TabIndex = 316;
            this.label29.Text = "Sr.(es):";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(21, 267);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(35, 12);
            this.label30.TabIndex = 318;
            this.label30.Text = "R.U.C:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(356, 167);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(23, 12);
            this.label36.TabIndex = 320;
            this.label36.Text = "Nro:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(474, 167);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(37, 12);
            this.label35.TabIndex = 323;
            this.label35.Text = "Interior:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(589, 167);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 12);
            this.label34.TabIndex = 325;
            this.label34.Text = "Zona:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(355, 191);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(38, 12);
            this.label33.TabIndex = 327;
            this.label33.Text = "Distrito:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(483, 193);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(28, 12);
            this.label32.TabIndex = 328;
            this.label32.Text = "Prov:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(590, 191);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(28, 12);
            this.label31.TabIndex = 330;
            this.label31.Text = "Dpto:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(448, 19);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 25);
            this.label37.TabIndex = 332;
            this.label37.Text = "R.U.C.";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(364, 289);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(36, 12);
            this.label38.TabIndex = 336;
            this.label38.Text = "Chofer:";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LblEstado,
            this.toolStripSeparator2,
            this.toolStripLabel1,
            this.TxtGuia,
            this.BtnConsultar,
            this.BtnImprimir,
            this.toolStripSeparator1,
            this.BtnVistaPrevia,
            this.BtnAnular,
            this.toolStripSeparator3,
            this.toolStripLabel2,
            this.CboTipoGuia});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(667, 25);
            this.toolStrip1.TabIndex = 343;
            this.toolStrip1.Text = "TsImpresion";
            // 
            // LblEstado
            // 
            this.LblEstado.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEstado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblEstado.Name = "LblEstado";
            this.LblEstado.Size = new System.Drawing.Size(59, 22);
            this.LblEstado.Text = "LblEstado";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(151, 22);
            this.toolStripLabel1.Text = "Ingrese de guía a consultar:";
            // 
            // TxtGuia
            // 
            this.TxtGuia.Name = "TxtGuia";
            this.TxtGuia.Size = new System.Drawing.Size(100, 25);
            // 
            // BtnConsultar
            // 
            this.BtnConsultar.Image = global::Halley.Presentacion.Properties.Resources.Consultar_16x16;
            this.BtnConsultar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnConsultar.Name = "BtnConsultar";
            this.BtnConsultar.Size = new System.Drawing.Size(78, 22);
            this.BtnConsultar.Text = "Consultar";
            this.BtnConsultar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnConsultar.Click += new System.EventHandler(this.BtnConsultar_Click_1);
            // 
            // BtnAnular
            // 
            this.BtnAnular.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAnular.Image = global::Halley.Presentacion.Properties.Resources.Cancelar_16x16;
            this.BtnAnular.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAnular.Name = "BtnAnular";
            this.BtnAnular.Size = new System.Drawing.Size(23, 22);
            this.BtnAnular.Text = "Anular Guia";
            this.BtnAnular.Click += new System.EventHandler(this.BtnAnular_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(55, 22);
            this.toolStripLabel2.Text = "Formato:";
            // 
            // CboTipoGuia
            // 
            this.CboTipoGuia.Items.AddRange(new object[] {
            "Industria",
            "Comercial",
            "Granja"});
            this.CboTipoGuia.Name = "CboTipoGuia";
            this.CboTipoGuia.Size = new System.Drawing.Size(121, 25);
            // 
            // TxtMarca
            // 
            this.TxtMarca.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtMarca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMarca.Location = new System.Drawing.Point(486, 243);
            this.TxtMarca.MaxLength = 50;
            this.TxtMarca.Name = "TxtMarca";
            this.TxtMarca.Size = new System.Drawing.Size(88, 13);
            this.TxtMarca.TabIndex = 72;
            this.TxtMarca.Tag = null;
            this.TxtMarca.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtMarca.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtPlaca
            // 
            this.TxtPlaca.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtPlaca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPlaca.Location = new System.Drawing.Point(587, 243);
            this.TxtPlaca.MaxLength = 10;
            this.TxtPlaca.Name = "TxtPlaca";
            this.TxtPlaca.Size = new System.Drawing.Size(70, 13);
            this.TxtPlaca.TabIndex = 73;
            this.TxtPlaca.Tag = null;
            this.TxtPlaca.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtPlaca.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroConstInscripcion
            // 
            this.TxtNroConstInscripcion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtNroConstInscripcion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroConstInscripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroConstInscripcion.Location = new System.Drawing.Point(496, 260);
            this.TxtNroConstInscripcion.MaxLength = 15;
            this.TxtNroConstInscripcion.Name = "TxtNroConstInscripcion";
            this.TxtNroConstInscripcion.Size = new System.Drawing.Size(91, 13);
            this.TxtNroConstInscripcion.TabIndex = 76;
            this.TxtNroConstInscripcion.Tag = null;
            this.TxtNroConstInscripcion.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroConstInscripcion.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroLicTransaportista
            // 
            this.TxtNroLicTransaportista.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtNroLicTransaportista.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroLicTransaportista.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroLicTransaportista.Location = new System.Drawing.Point(480, 274);
            this.TxtNroLicTransaportista.MaxLength = 15;
            this.TxtNroLicTransaportista.Name = "TxtNroLicTransaportista";
            this.TxtNroLicTransaportista.Size = new System.Drawing.Size(102, 13);
            this.TxtNroLicTransaportista.TabIndex = 77;
            this.TxtNroLicTransaportista.Tag = null;
            this.TxtNroLicTransaportista.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroLicTransaportista.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDomicilioPartida
            // 
            this.TxtDomicilioPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDomicilioPartida.Location = new System.Drawing.Point(43, 152);
            this.TxtDomicilioPartida.MaxLength = 20;
            this.TxtDomicilioPartida.Name = "TxtDomicilioPartida";
            this.TxtDomicilioPartida.Size = new System.Drawing.Size(286, 13);
            this.TxtDomicilioPartida.TabIndex = 304;
            this.TxtDomicilioPartida.Tag = null;
            this.TxtDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroDomicilioPartida
            // 
            this.TxtNroDomicilioPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtNroDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroDomicilioPartida.Location = new System.Drawing.Point(43, 169);
            this.TxtNroDomicilioPartida.MaxLength = 50;
            this.TxtNroDomicilioPartida.Name = "TxtNroDomicilioPartida";
            this.TxtNroDomicilioPartida.Size = new System.Drawing.Size(68, 13);
            this.TxtNroDomicilioPartida.TabIndex = 305;
            this.TxtNroDomicilioPartida.Tag = null;
            this.TxtNroDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtIntDomicilioPartida
            // 
            this.TxtIntDomicilioPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtIntDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtIntDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIntDomicilioPartida.Location = new System.Drawing.Point(165, 169);
            this.TxtIntDomicilioPartida.MaxLength = 50;
            this.TxtIntDomicilioPartida.Name = "TxtIntDomicilioPartida";
            this.TxtIntDomicilioPartida.Size = new System.Drawing.Size(74, 13);
            this.TxtIntDomicilioPartida.TabIndex = 307;
            this.TxtIntDomicilioPartida.Tag = null;
            this.TxtIntDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtIntDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtZonaDomicilioPartida
            // 
            this.TxtZonaDomicilioPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtZonaDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtZonaDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtZonaDomicilioPartida.Location = new System.Drawing.Point(279, 169);
            this.TxtZonaDomicilioPartida.MaxLength = 50;
            this.TxtZonaDomicilioPartida.Name = "TxtZonaDomicilioPartida";
            this.TxtZonaDomicilioPartida.Size = new System.Drawing.Size(68, 13);
            this.TxtZonaDomicilioPartida.TabIndex = 309;
            this.TxtZonaDomicilioPartida.Tag = null;
            this.TxtZonaDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtZonaDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDisDomicilioPartida
            // 
            this.TxtDisDomicilioPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtDisDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDisDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDisDomicilioPartida.Location = new System.Drawing.Point(58, 191);
            this.TxtDisDomicilioPartida.MaxLength = 50;
            this.TxtDisDomicilioPartida.Name = "TxtDisDomicilioPartida";
            this.TxtDisDomicilioPartida.Size = new System.Drawing.Size(70, 13);
            this.TxtDisDomicilioPartida.TabIndex = 311;
            this.TxtDisDomicilioPartida.Tag = null;
            this.TxtDisDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDisDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtProvDomicilioPartida
            // 
            this.TxtProvDomicilioPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtProvDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtProvDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProvDomicilioPartida.Location = new System.Drawing.Point(162, 191);
            this.TxtProvDomicilioPartida.MaxLength = 50;
            this.TxtProvDomicilioPartida.Name = "TxtProvDomicilioPartida";
            this.TxtProvDomicilioPartida.Size = new System.Drawing.Size(79, 13);
            this.TxtProvDomicilioPartida.TabIndex = 313;
            this.TxtProvDomicilioPartida.Tag = null;
            this.TxtProvDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtProvDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDepDomicilioPartida
            // 
            this.TxtDepDomicilioPartida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtDepDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDepDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDepDomicilioPartida.Location = new System.Drawing.Point(283, 189);
            this.TxtDepDomicilioPartida.MaxLength = 50;
            this.TxtDepDomicilioPartida.Name = "TxtDepDomicilioPartida";
            this.TxtDepDomicilioPartida.Size = new System.Drawing.Size(64, 13);
            this.TxtDepDomicilioPartida.TabIndex = 315;
            this.TxtDepDomicilioPartida.Tag = null;
            this.TxtDepDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDepDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDestinatario
            // 
            this.TxtDestinatario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDestinatario.Location = new System.Drawing.Point(67, 246);
            this.TxtDestinatario.MaxLength = 50;
            this.TxtDestinatario.Name = "TxtDestinatario";
            this.TxtDestinatario.Size = new System.Drawing.Size(280, 13);
            this.TxtDestinatario.TabIndex = 317;
            this.TxtDestinatario.Tag = null;
            this.TxtDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRUCDestinatario
            // 
            this.TxtRUCDestinatario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtRUCDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRUCDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRUCDestinatario.Location = new System.Drawing.Point(67, 268);
            this.TxtRUCDestinatario.MaxLength = 50;
            this.TxtRUCDestinatario.Name = "TxtRUCDestinatario";
            this.TxtRUCDestinatario.Size = new System.Drawing.Size(154, 13);
            this.TxtRUCDestinatario.TabIndex = 319;
            this.TxtRUCDestinatario.Tag = null;
            this.TxtRUCDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRUCDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDomicilioLlegada
            // 
            this.TxtDomicilioLlegada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDomicilioLlegada.Location = new System.Drawing.Point(383, 151);
            this.TxtDomicilioLlegada.MaxLength = 20;
            this.TxtDomicilioLlegada.Name = "TxtDomicilioLlegada";
            this.TxtDomicilioLlegada.Size = new System.Drawing.Size(291, 13);
            this.TxtDomicilioLlegada.TabIndex = 321;
            this.TxtDomicilioLlegada.Tag = null;
            this.TxtDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroDomicilioLlegada
            // 
            this.TxtNroDomicilioLlegada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtNroDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroDomicilioLlegada.Location = new System.Drawing.Point(382, 168);
            this.TxtNroDomicilioLlegada.MaxLength = 50;
            this.TxtNroDomicilioLlegada.Name = "TxtNroDomicilioLlegada";
            this.TxtNroDomicilioLlegada.Size = new System.Drawing.Size(79, 13);
            this.TxtNroDomicilioLlegada.TabIndex = 322;
            this.TxtNroDomicilioLlegada.Tag = null;
            this.TxtNroDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtIntDomicilioLlegada
            // 
            this.TxtIntDomicilioLlegada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtIntDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtIntDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIntDomicilioLlegada.Location = new System.Drawing.Point(514, 168);
            this.TxtIntDomicilioLlegada.MaxLength = 50;
            this.TxtIntDomicilioLlegada.Name = "TxtIntDomicilioLlegada";
            this.TxtIntDomicilioLlegada.Size = new System.Drawing.Size(68, 13);
            this.TxtIntDomicilioLlegada.TabIndex = 324;
            this.TxtIntDomicilioLlegada.Tag = null;
            this.TxtIntDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtIntDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtZonaDomicilioLlegada
            // 
            this.TxtZonaDomicilioLlegada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtZonaDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtZonaDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtZonaDomicilioLlegada.Location = new System.Drawing.Point(624, 168);
            this.TxtZonaDomicilioLlegada.MaxLength = 50;
            this.TxtZonaDomicilioLlegada.Name = "TxtZonaDomicilioLlegada";
            this.TxtZonaDomicilioLlegada.Size = new System.Drawing.Size(61, 13);
            this.TxtZonaDomicilioLlegada.TabIndex = 326;
            this.TxtZonaDomicilioLlegada.Tag = null;
            this.TxtZonaDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtZonaDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtProvDomicilioLlegada
            // 
            this.TxtProvDomicilioLlegada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtProvDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtProvDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProvDomicilioLlegada.Location = new System.Drawing.Point(514, 191);
            this.TxtProvDomicilioLlegada.MaxLength = 50;
            this.TxtProvDomicilioLlegada.Name = "TxtProvDomicilioLlegada";
            this.TxtProvDomicilioLlegada.Size = new System.Drawing.Size(71, 13);
            this.TxtProvDomicilioLlegada.TabIndex = 329;
            this.TxtProvDomicilioLlegada.Tag = null;
            this.TxtProvDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtProvDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDepDomicilioLlegada
            // 
            this.TxtDepDomicilioLlegada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtDepDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDepDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDepDomicilioLlegada.Location = new System.Drawing.Point(625, 191);
            this.TxtDepDomicilioLlegada.MaxLength = 50;
            this.TxtDepDomicilioLlegada.Name = "TxtDepDomicilioLlegada";
            this.TxtDepDomicilioLlegada.Size = new System.Drawing.Size(69, 13);
            this.TxtDepDomicilioLlegada.TabIndex = 331;
            this.TxtDepDomicilioLlegada.Tag = null;
            this.TxtDepDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDepDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDisDomicilioLlegada
            // 
            this.TxtDisDomicilioLlegada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtDisDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtDisDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDisDomicilioLlegada.Location = new System.Drawing.Point(395, 191);
            this.TxtDisDomicilioLlegada.MaxLength = 50;
            this.TxtDisDomicilioLlegada.Name = "TxtDisDomicilioLlegada";
            this.TxtDisDomicilioLlegada.Size = new System.Drawing.Size(74, 13);
            this.TxtDisDomicilioLlegada.TabIndex = 334;
            this.TxtDisDomicilioLlegada.Tag = null;
            this.TxtDisDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDisDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNumGuiaRemision
            // 
            this.TxtNumGuiaRemision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtNumGuiaRemision.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNumGuiaRemision.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumGuiaRemision.Location = new System.Drawing.Point(495, 99);
            this.TxtNumGuiaRemision.MaxLength = 50;
            this.TxtNumGuiaRemision.Name = "TxtNumGuiaRemision";
            this.TxtNumGuiaRemision.Size = new System.Drawing.Size(141, 16);
            this.TxtNumGuiaRemision.TabIndex = 335;
            this.TxtNumGuiaRemision.Tag = null;
            this.TxtNumGuiaRemision.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumGuiaRemision.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNombreChofer
            // 
            this.TxtNombreChofer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtNombreChofer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNombreChofer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNombreChofer.Location = new System.Drawing.Point(446, 289);
            this.TxtNombreChofer.MaxLength = 15;
            this.TxtNombreChofer.Name = "TxtNombreChofer";
            this.TxtNombreChofer.Size = new System.Drawing.Size(234, 13);
            this.TxtNombreChofer.TabIndex = 337;
            this.TxtNombreChofer.Tag = null;
            this.TxtNombreChofer.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNombreChofer.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtMotivo
            // 
            this.TxtMotivo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtMotivo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtMotivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMotivo.Location = new System.Drawing.Point(437, 615);
            this.TxtMotivo.MaxLength = 15;
            this.TxtMotivo.Multiline = true;
            this.TxtMotivo.Name = "TxtMotivo";
            this.TxtMotivo.Size = new System.Drawing.Size(77, 19);
            this.TxtMotivo.TabIndex = 338;
            this.TxtMotivo.Tag = null;
            this.TxtMotivo.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtFechaEmision
            // 
            this.TxtFechaEmision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtFechaEmision.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtFechaEmision.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFechaEmision.Location = new System.Drawing.Point(28, 113);
            this.TxtFechaEmision.MaxLength = 50;
            this.TxtFechaEmision.Name = "TxtFechaEmision";
            this.TxtFechaEmision.Size = new System.Drawing.Size(96, 13);
            this.TxtFechaEmision.TabIndex = 339;
            this.TxtFechaEmision.Tag = null;
            this.TxtFechaEmision.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtFechaEmision.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFechaEmision.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtFechaInicioTraslado
            // 
            this.TxtFechaInicioTraslado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtFechaInicioTraslado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtFechaInicioTraslado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFechaInicioTraslado.Location = new System.Drawing.Point(191, 112);
            this.TxtFechaInicioTraslado.MaxLength = 50;
            this.TxtFechaInicioTraslado.Name = "TxtFechaInicioTraslado";
            this.TxtFechaInicioTraslado.Size = new System.Drawing.Size(96, 13);
            this.TxtFechaInicioTraslado.TabIndex = 340;
            this.TxtFechaInicioTraslado.Tag = null;
            this.TxtFechaInicioTraslado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtFechaInicioTraslado.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFechaInicioTraslado.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape12,
            this.lineShape11,
            this.lineShape10,
            this.lineShape9,
            this.lineShape8,
            this.lineShape7,
            this.rectangleShape11,
            this.rectangleShape10,
            this.rectangleShape9,
            this.rectangleShape8,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.rectangleShape7,
            this.rectangleShape6,
            this.rectangleShape5,
            this.rectangleShape4,
            this.rectangleShape3,
            this.rectangleShape1,
            this.lineShape6,
            this.lineShape5,
            this.rectangleShape2});
            this.shapeContainer1.Size = new System.Drawing.Size(712, 660);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape12
            // 
            this.lineShape12.Name = "lineShape12";
            this.lineShape12.X1 = 584;
            this.lineShape12.X2 = 693;
            this.lineShape12.Y1 = 628;
            this.lineShape12.Y2 = 628;
            // 
            // lineShape11
            // 
            this.lineShape11.Name = "lineShape11";
            this.lineShape11.X1 = 575;
            this.lineShape11.X2 = 684;
            this.lineShape11.Y1 = 579;
            this.lineShape11.Y2 = 579;
            // 
            // lineShape10
            // 
            this.lineShape10.Name = "lineShape10";
            this.lineShape10.X1 = 557;
            this.lineShape10.X2 = 557;
            this.lineShape10.Y1 = 516;
            this.lineShape10.Y2 = 652;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 235;
            this.lineShape9.X2 = 695;
            this.lineShape9.Y1 = 515;
            this.lineShape9.Y2 = 515;
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 7;
            this.lineShape8.X2 = 222;
            this.lineShape8.Y1 = 595;
            this.lineShape8.Y2 = 595;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 8;
            this.lineShape7.X2 = 223;
            this.lineShape7.Y1 = 515;
            this.lineShape7.Y2 = 515;
            // 
            // rectangleShape11
            // 
            this.rectangleShape11.CornerRadius = 3;
            this.rectangleShape11.Location = new System.Drawing.Point(235, 500);
            this.rectangleShape11.Name = "rectangleShape11";
            this.rectangleShape11.Size = new System.Drawing.Size(463, 151);
            // 
            // rectangleShape10
            // 
            this.rectangleShape10.CornerRadius = 3;
            this.rectangleShape10.Location = new System.Drawing.Point(7, 576);
            this.rectangleShape10.Name = "rectangleShape10";
            this.rectangleShape10.Size = new System.Drawing.Size(214, 74);
            // 
            // rectangleShape9
            // 
            this.rectangleShape9.CornerRadius = 3;
            this.rectangleShape9.Location = new System.Drawing.Point(7, 502);
            this.rectangleShape9.Name = "rectangleShape9";
            this.rectangleShape9.Size = new System.Drawing.Size(215, 67);
            // 
            // rectangleShape8
            // 
            this.rectangleShape8.CornerRadius = 3;
            this.rectangleShape8.Location = new System.Drawing.Point(9, 311);
            this.rectangleShape8.Name = "rectangleShape8";
            this.rectangleShape8.Size = new System.Drawing.Size(689, 187);
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 355;
            this.lineShape4.X2 = 697;
            this.lineShape4.Y1 = 239;
            this.lineShape4.Y2 = 239;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 8;
            this.lineShape3.X2 = 350;
            this.lineShape3.Y1 = 240;
            this.lineShape3.Y2 = 240;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 355;
            this.lineShape2.X2 = 697;
            this.lineShape2.Y1 = 145;
            this.lineShape2.Y2 = 145;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 8;
            this.lineShape1.X2 = 350;
            this.lineShape1.Y1 = 145;
            this.lineShape1.Y2 = 145;
            // 
            // rectangleShape7
            // 
            this.rectangleShape7.CornerRadius = 3;
            this.rectangleShape7.Location = new System.Drawing.Point(355, 220);
            this.rectangleShape7.Name = "rectangleShape7";
            this.rectangleShape7.Size = new System.Drawing.Size(342, 86);
            // 
            // rectangleShape6
            // 
            this.rectangleShape6.CornerRadius = 3;
            this.rectangleShape6.Location = new System.Drawing.Point(8, 221);
            this.rectangleShape6.Name = "rectangleShape6";
            this.rectangleShape6.Size = new System.Drawing.Size(342, 86);
            // 
            // rectangleShape5
            // 
            this.rectangleShape5.CornerRadius = 3;
            this.rectangleShape5.Location = new System.Drawing.Point(354, 130);
            this.rectangleShape5.Name = "rectangleShape5";
            this.rectangleShape5.Size = new System.Drawing.Size(342, 86);
            // 
            // rectangleShape4
            // 
            this.rectangleShape4.CornerRadius = 3;
            this.rectangleShape4.Location = new System.Drawing.Point(7, 129);
            this.rectangleShape4.Name = "rectangleShape4";
            this.rectangleShape4.Size = new System.Drawing.Size(342, 86);
            // 
            // rectangleShape3
            // 
            this.rectangleShape3.CornerRadius = 3;
            this.rectangleShape3.Location = new System.Drawing.Point(175, 98);
            this.rectangleShape3.Name = "rectangleShape3";
            this.rectangleShape3.Size = new System.Drawing.Size(135, 28);
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.CornerRadius = 3;
            this.rectangleShape1.Location = new System.Drawing.Point(8, 98);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(135, 28);
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 429;
            this.lineShape6.X2 = 695;
            this.lineShape6.Y1 = 87;
            this.lineShape6.Y2 = 87;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 428;
            this.lineShape5.X2 = 695;
            this.lineShape5.Y1 = 55;
            this.lineShape5.Y2 = 55;
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.CornerRadius = 10;
            this.rectangleShape2.Location = new System.Drawing.Point(429, 3);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(265, 122);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.AutoScroll = true;
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtConfVehicular);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label56);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LblEmpresa);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LblRuc);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label55);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label54);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label53);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label52);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label51);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label50);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label49);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label48);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label47);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label46);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label45);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label44);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label43);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label42);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtTipoComprobante);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label41);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtRucTransportista);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label39);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtTransportista2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label22);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label19);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label18);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.txtDocIdentidad);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label40);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroFactura);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LblDireccion);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtFechaInicioTraslado);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtFechaEmision);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtMotivo);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNombreChofer);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label38);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNumGuiaRemision);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDisDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label37);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDepDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label31);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtProvDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label32);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label33);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtZonaDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label34);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtIntDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label35);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label36);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtRUCDestinatario);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label30);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDestinatario);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label29);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDepDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label26);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtProvDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label27);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDisDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label28);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtZonaDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label25);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtIntDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label24);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label23);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroLicTransaportista);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroConstInscripcion);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label20);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label21);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtPlaca);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtMarca);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label17);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label16);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label15);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label14);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label13);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstCostoMinimo);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstPeso);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstCantidad);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstUM);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.pictureBox1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstProducto);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label12);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label11);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label10);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label9);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label8);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label7);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label6);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label5);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label4);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label3);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.shapeContainer1);
            this.toolStripContainer1.ContentPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(712, 660);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(712, 685);
            this.toolStripContainer1.TabIndex = 344;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // TxtConfVehicular
            // 
            this.TxtConfVehicular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtConfVehicular.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtConfVehicular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtConfVehicular.Location = new System.Drawing.Point(637, 262);
            this.TxtConfVehicular.MaxLength = 50;
            this.TxtConfVehicular.Name = "TxtConfVehicular";
            this.TxtConfVehicular.Size = new System.Drawing.Size(58, 13);
            this.TxtConfVehicular.TabIndex = 379;
            this.TxtConfVehicular.Tag = null;
            this.TxtConfVehicular.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtConfVehicular.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(592, 263);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(49, 12);
            this.label56.TabIndex = 378;
            this.label56.Text = "Conf Vehi:";
            // 
            // LblEmpresa
            // 
            this.LblEmpresa.AutoSize = true;
            this.LblEmpresa.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEmpresa.Location = new System.Drawing.Point(12, 50);
            this.LblEmpresa.Name = "LblEmpresa";
            this.LblEmpresa.Size = new System.Drawing.Size(179, 25);
            this.LblEmpresa.TabIndex = 377;
            this.LblEmpresa.Text = "Aqui va la empresa";
            // 
            // LblRuc
            // 
            this.LblRuc.AutoSize = true;
            this.LblRuc.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblRuc.Location = new System.Drawing.Point(516, 19);
            this.LblRuc.Name = "LblRuc";
            this.LblRuc.Size = new System.Drawing.Size(65, 25);
            this.LblRuc.TabIndex = 376;
            this.LblRuc.Text = "R.U.C.";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(437, 579);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(77, 36);
            this.label55.TabIndex = 373;
            this.label55.Text = "14.- Otros\r\n(A) Exibición\r\n(B) Demostración";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(437, 555);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(98, 24);
            this.label54.TabIndex = 369;
            this.label54.Text = "13.- Venta con entrega\r\n        a terceros.";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(437, 543);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(72, 12);
            this.label53.TabIndex = 369;
            this.label53.Text = "12.- Exportación";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(437, 531);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(72, 12);
            this.label52.TabIndex = 369;
            this.label52.Text = "11.- Importación";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(437, 519);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(116, 12);
            this.label51.TabIndex = 372;
            this.label51.Text = "10.- Traslado Zona primaria";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(242, 625);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(152, 24);
            this.label50.TabIndex = 371;
            this.label50.Text = "9.- Traslado por Emisor Itinerante de\r\n       comprobantes de pago.";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(242, 613);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(150, 12);
            this.label49.TabIndex = 369;
            this.label49.Text = "8.- Recojo de bienes trasnformados";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(242, 601);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(178, 12);
            this.label48.TabIndex = 369;
            this.label48.Text = "7.- Traslado de bienes para transformación";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(242, 577);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(148, 24);
            this.label47.TabIndex = 370;
            this.label47.Text = "6.-Traslado en tre establecimientos\r\n     de la misma empresa";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(242, 565);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(63, 12);
            this.label46.TabIndex = 369;
            this.label46.Text = "5.-Devolución";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(242, 553);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(74, 12);
            this.label45.TabIndex = 369;
            this.label45.Text = "4.- Consignación";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(242, 541);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(51, 12);
            this.label44.TabIndex = 368;
            this.label44.Text = "3.- Compra";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(242, 529);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(192, 12);
            this.label43.TabIndex = 367;
            this.label43.Text = "2.- Venta sujeta a confirmación del comprador";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(242, 517);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(43, 12);
            this.label42.TabIndex = 350;
            this.label42.Text = "1.- Venta";
            // 
            // TxtTipoComprobante
            // 
            this.TxtTipoComprobante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtTipoComprobante.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtTipoComprobante.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTipoComprobante.Location = new System.Drawing.Point(67, 604);
            this.TxtTipoComprobante.MaxLength = 50;
            this.TxtTipoComprobante.Name = "TxtTipoComprobante";
            this.TxtTipoComprobante.Size = new System.Drawing.Size(96, 13);
            this.TxtTipoComprobante.TabIndex = 352;
            this.TxtTipoComprobante.Tag = null;
            this.TxtTipoComprobante.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtTipoComprobante.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(23, 545);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(35, 12);
            this.label41.TabIndex = 351;
            this.label41.Text = "R.U.C.";
            // 
            // TxtRucTransportista
            // 
            this.TxtRucTransportista.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtRucTransportista.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRucTransportista.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRucTransportista.Location = new System.Drawing.Point(68, 546);
            this.TxtRucTransportista.MaxLength = 50;
            this.TxtRucTransportista.Name = "TxtRucTransportista";
            this.TxtRucTransportista.Size = new System.Drawing.Size(96, 13);
            this.TxtRucTransportista.TabIndex = 350;
            this.TxtRucTransportista.Tag = null;
            this.TxtRucTransportista.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRucTransportista.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(19, 518);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 12);
            this.label39.TabIndex = 349;
            this.label39.Text = "Nombre:";
            // 
            // TxtTransportista2
            // 
            this.TxtTransportista2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtTransportista2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtTransportista2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTransportista2.Location = new System.Drawing.Point(68, 520);
            this.TxtTransportista2.MaxLength = 50;
            this.TxtTransportista2.Multiline = true;
            this.TxtTransportista2.Name = "TxtTransportista2";
            this.TxtTransportista2.Size = new System.Drawing.Size(139, 21);
            this.TxtTransportista2.TabIndex = 348;
            this.TxtTransportista2.Tag = null;
            this.TxtTransportista2.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(25, 605);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 348;
            this.label22.Text = "TIPO:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(25, 625);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 12);
            this.label19.TabIndex = 347;
            this.label19.Text = "N°:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(55, 580);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(116, 12);
            this.label18.TabIndex = 345;
            this.label18.Text = "COMPROBANTE DE PAGO";
            // 
            // txtDocIdentidad
            // 
            this.txtDocIdentidad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtDocIdentidad.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDocIdentidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocIdentidad.Location = new System.Drawing.Point(196, 290);
            this.txtDocIdentidad.MaxLength = 50;
            this.txtDocIdentidad.Name = "txtDocIdentidad";
            this.txtDocIdentidad.Size = new System.Drawing.Size(151, 13);
            this.txtDocIdentidad.TabIndex = 346;
            this.txtDocIdentidad.Tag = null;
            this.txtDocIdentidad.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.txtDocIdentidad.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(26, 289);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(159, 12);
            this.label40.TabIndex = 345;
            this.label40.Text = "Tipo y N° de Documento de Identidad:";
            // 
            // TxtNroFactura
            // 
            this.TxtNroFactura.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TxtNroFactura.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNroFactura.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroFactura.Location = new System.Drawing.Point(63, 624);
            this.TxtNroFactura.MaxLength = 50;
            this.TxtNroFactura.Name = "TxtNroFactura";
            this.TxtNroFactura.Size = new System.Drawing.Size(96, 13);
            this.TxtNroFactura.TabIndex = 344;
            this.TxtNroFactura.Tag = null;
            this.TxtNroFactura.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroFactura.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // LblDireccion
            // 
            this.LblDireccion.AutoSize = true;
            this.LblDireccion.Location = new System.Drawing.Point(179, 31);
            this.LblDireccion.Name = "LblDireccion";
            this.LblDireccion.Size = new System.Drawing.Size(100, 13);
            this.LblDireccion.TabIndex = 342;
            this.LblDireccion.Text = "Aqui va la direccion";
            // 
            // FrmGuiaRemision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(712, 685);
            this.Controls.Add(this.toolStripContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmGuiaRemision";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Guia Remision";
            this.Load += new System.EventHandler(this.FrmGuiaRemision_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMarca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPlaca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroConstInscripcion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroLicTransaportista)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumGuiaRemision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreChofer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMotivo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaEmision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaInicioTraslado)).EndInit();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConfVehicular)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTipoComprobante)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRucTransportista)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTransportista2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDocIdentidad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroFactura)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.ToolStrip miniToolStrip;
        private System.Windows.Forms.ToolStripButton BtnImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton BtnVistaPrevia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox LstProducto;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListBox LstUM;
        private System.Windows.Forms.ListBox LstCantidad;
        private System.Windows.Forms.ListBox LstPeso;
        private System.Windows.Forms.ListBox LstCostoMinimo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private C1.Win.C1Input.C1TextBox TxtFechaInicioTraslado;
        private C1.Win.C1Input.C1TextBox TxtFechaEmision;
        private C1.Win.C1Input.C1TextBox TxtMotivo;
        private C1.Win.C1Input.C1TextBox TxtNombreChofer;
        private C1.Win.C1Input.C1TextBox TxtNumGuiaRemision;
        private C1.Win.C1Input.C1TextBox TxtDisDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtDepDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtProvDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtZonaDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtIntDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtNroDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtRUCDestinatario;
        private C1.Win.C1Input.C1TextBox TxtDestinatario;
        private C1.Win.C1Input.C1TextBox TxtDepDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtProvDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtDisDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtZonaDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtIntDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtNroDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtNroLicTransaportista;
        private C1.Win.C1Input.C1TextBox TxtNroConstInscripcion;
        private C1.Win.C1Input.C1TextBox TxtPlaca;
        private C1.Win.C1Input.C1TextBox TxtMarca;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox TxtGuia;
        private System.Windows.Forms.ToolStripButton BtnConsultar;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStripButton BtnAnular;
        private System.Windows.Forms.ToolStripLabel LblEstado;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private C1.Win.C1Input.C1TextBox TxtNroFactura;
        private C1.Win.C1Input.C1TextBox txtDocIdentidad;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label41;
        private C1.Win.C1Input.C1TextBox TxtRucTransportista;
        private System.Windows.Forms.Label label39;
        private C1.Win.C1Input.C1TextBox TxtTransportista2;
        private C1.Win.C1Input.C1TextBox TxtTipoComprobante;
        private System.Windows.Forms.Label LblDireccion;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label LblEmpresa;
        private System.Windows.Forms.Label LblRuc;
        private System.Windows.Forms.ToolStripComboBox CboTipoGuia;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape7;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape6;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape3;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape12;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape11;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape11;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape10;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape9;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private C1.Win.C1Input.C1TextBox TxtConfVehicular;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;


    }
}