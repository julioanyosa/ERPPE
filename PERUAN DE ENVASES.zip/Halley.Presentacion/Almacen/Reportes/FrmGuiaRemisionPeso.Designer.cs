﻿namespace Halley.Presentacion.Almacen
{
    partial class FrmGuiaRemisionPeso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGuiaRemisionPeso));
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.miniToolStrip = new System.Windows.Forms.ToolStrip();
            this.BtnImprimir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnVistaPrevia = new System.Windows.Forms.ToolStripButton();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.LstTara1 = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.LblDireccion = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.LblEstado = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.TxtGuia = new System.Windows.Forms.ToolStripTextBox();
            this.BtnConsultar = new System.Windows.Forms.ToolStripButton();
            this.BtnAnular = new System.Windows.Forms.ToolStripButton();
            this.TxtConfVehicular = new C1.Win.C1Input.C1TextBox();
            this.TxtMarca = new C1.Win.C1Input.C1TextBox();
            this.TxtPlaca = new C1.Win.C1Input.C1TextBox();
            this.TxtNroConstInscripcion = new C1.Win.C1Input.C1TextBox();
            this.TxtNroLicTransaportista = new C1.Win.C1Input.C1TextBox();
            this.TxtDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtNroDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtIntDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtZonaDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDisDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtProvDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDepDomicilioPartida = new C1.Win.C1Input.C1TextBox();
            this.TxtDestinatario = new C1.Win.C1Input.C1TextBox();
            this.TxtRUCDestinatario = new C1.Win.C1Input.C1TextBox();
            this.TxtDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtNroDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtIntDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtZonaDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtProvDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtDepDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtRuc = new C1.Win.C1Input.C1TextBox();
            this.TxtDisDomicilioLlegada = new C1.Win.C1Input.C1TextBox();
            this.TxtNumGuiaRemision = new C1.Win.C1Input.C1TextBox();
            this.TxtFechaEmision = new C1.Win.C1Input.C1TextBox();
            this.TxtFechaInicioTraslado = new C1.Win.C1Input.C1TextBox();
            this.TxtEmpresa = new C1.Win.C1Input.C1TextBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape17 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape13 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape11 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape16 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape14 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape6 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.label58 = new System.Windows.Forms.Label();
            this.TxtPesoTotal = new C1.Win.C1Input.C1TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.TxtFecha = new C1.Win.C1Input.C1TextBox();
            this.TxtRUCTransporte = new C1.Win.C1Input.C1TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.TxtEmpresaTransporte = new C1.Win.C1Input.C1TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LstBruto6 = new System.Windows.Forms.ListBox();
            this.LstBruto5 = new System.Windows.Forms.ListBox();
            this.LstBruto4 = new System.Windows.Forms.ListBox();
            this.LstBruto3 = new System.Windows.Forms.ListBox();
            this.LstBruto2 = new System.Windows.Forms.ListBox();
            this.LstBruto1 = new System.Windows.Forms.ListBox();
            this.LstTara4 = new System.Windows.Forms.ListBox();
            this.LstTara3 = new System.Windows.Forms.ListBox();
            this.LstTara2 = new System.Windows.Forms.ListBox();
            this.TxtCodigoDespacho = new C1.Win.C1Input.C1TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.TxtProducto = new C1.Win.C1Input.C1TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.TxtBruto = new C1.Win.C1Input.C1TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.TxtTara = new C1.Win.C1Input.C1TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.TxtNeto = new C1.Win.C1Input.C1TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.TxtPrecioUnitario = new C1.Win.C1Input.C1TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.TxtTotalImporte = new C1.Win.C1Input.C1TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.TxtHoraLlegada = new C1.Win.C1Input.C1TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.TxtHoraSalida = new C1.Win.C1Input.C1TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.TxtHoraEntrada = new C1.Win.C1Input.C1TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.TxtPesoPromedio = new C1.Win.C1Input.C1TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.TxtAves = new C1.Win.C1Input.C1TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.TxtNroJabas = new C1.Win.C1Input.C1TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.TxtHembra = new C1.Win.C1Input.C1TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtMacho = new C1.Win.C1Input.C1TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtGalpon = new C1.Win.C1Input.C1TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtOrden = new C1.Win.C1Input.C1TextBox();
            this.TxtCostoMinimo = new C1.Win.C1Input.C1TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.TxtRecFactNro = new C1.Win.C1Input.C1TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.TxtGalponero = new C1.Win.C1Input.C1TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.TxtPesador = new C1.Win.C1Input.C1TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.TxtNombreChofer = new C1.Win.C1Input.C1TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape3 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape5 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape7 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape8 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape9 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape4 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape10 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape12 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConfVehicular)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMarca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPlaca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroConstInscripcion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroLicTransaportista)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioPartida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCDestinatario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRuc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumGuiaRemision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaEmision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaInicioTraslado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmpresa)).BeginInit();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPesoTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFecha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCTransporte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmpresaTransporte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCodigoDespacho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProducto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtBruto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNeto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPrecioUnitario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTotalImporte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHoraLlegada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHoraSalida)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHoraEntrada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPesoPromedio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAves)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroJabas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHembra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMacho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtGalpon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtOrden)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCostoMinimo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRecFactNro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtGalponero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPesador)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreChofer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.CanOverflow = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.miniToolStrip.Location = new System.Drawing.Point(428, 3);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(431, 25);
            this.miniToolStrip.TabIndex = 343;
            // 
            // BtnImprimir
            // 
            this.BtnImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnImprimir.Image = global::Halley.Presentacion.Properties.Resources.print_16x16;
            this.BtnImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnImprimir.Name = "BtnImprimir";
            this.BtnImprimir.Size = new System.Drawing.Size(23, 22);
            this.BtnImprimir.Text = "Imprimir";
            this.BtnImprimir.Click += new System.EventHandler(this.BtnImprimir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // BtnVistaPrevia
            // 
            this.BtnVistaPrevia.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnVistaPrevia.Image = global::Halley.Presentacion.Properties.Resources.printView_16x16;
            this.BtnVistaPrevia.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnVistaPrevia.Name = "BtnVistaPrevia";
            this.BtnVistaPrevia.Size = new System.Drawing.Size(23, 22);
            this.BtnVistaPrevia.Text = "Seleccionar Impresora";
            this.BtnVistaPrevia.Click += new System.EventHandler(this.BtnVistaPrevia_Click);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.AutoScroll = true;
            this.ContentPanel.Size = new System.Drawing.Size(814, 611);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(479, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(301, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "GUIA DE REMISION -REMITENTE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(142, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "TARA";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(251, 211);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(190, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "Nombre o Razon Social del DESTINATARIO:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(45, 270);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(182, 12);
            this.label10.TabIndex = 10;
            this.label10.Text = "UNIDAD DE TRANSPORTE / CONDUCTOR";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(80, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 12);
            this.label11.TabIndex = 11;
            this.label11.Text = "FECHA DE EMISIÓN:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(52, 215);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 12);
            this.label12.TabIndex = 12;
            this.label12.Text = "FECHA INICIO TRASLADO:";
            // 
            // LstTara1
            // 
            this.LstTara1.ColumnWidth = 100;
            this.LstTara1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstTara1.FormatString = "N2";
            this.LstTara1.FormattingEnabled = true;
            this.LstTara1.Location = new System.Drawing.Point(22, 377);
            this.LstTara1.Name = "LstTara1";
            this.LstTara1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstTara1.Size = new System.Drawing.Size(75, 108);
            this.LstTara1.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(700, 583);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 12);
            this.label13.TabIndex = 19;
            this.label13.Text = "Chofer";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(602, 630);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 12);
            this.label14.TabIndex = 20;
            this.label14.Text = "Galponero";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(92, 573);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 12);
            this.label16.TabIndex = 22;
            this.label16.Text = "MOTIVO DEL TRASLADO";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(38, 335);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 12);
            this.label17.TabIndex = 68;
            this.label17.Text = "Configuración Vehicular:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(45, 285);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 12);
            this.label19.TabIndex = 70;
            this.label19.Text = "Marca y Nro de Placa::";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(14, 302);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(130, 12);
            this.label21.TabIndex = 74;
            this.label21.Text = "Nro Constancia de inscripcion:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(29, 319);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(115, 12);
            this.label20.TabIndex = 75;
            this.label20.Text = "Nro Licencia Transportista:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(23, 165);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 12);
            this.label23.TabIndex = 303;
            this.label23.Text = "Nro:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(138, 167);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(37, 12);
            this.label24.TabIndex = 306;
            this.label24.Text = "Interior:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(272, 168);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 308;
            this.label25.Text = "Zona:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(16, 186);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(30, 12);
            this.label28.TabIndex = 310;
            this.label28.Text = "Distri:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(147, 189);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 12);
            this.label27.TabIndex = 312;
            this.label27.Text = "Prov:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(273, 191);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(28, 12);
            this.label26.TabIndex = 314;
            this.label26.Text = "Dpto:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(251, 243);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(35, 12);
            this.label30.TabIndex = 318;
            this.label30.Text = "R.U.C:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(414, 167);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(23, 12);
            this.label36.TabIndex = 320;
            this.label36.Text = "Nro:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(526, 169);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(37, 12);
            this.label35.TabIndex = 323;
            this.label35.Text = "Interior:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(662, 167);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 12);
            this.label34.TabIndex = 325;
            this.label34.Text = "Zona:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(407, 187);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(30, 12);
            this.label33.TabIndex = 327;
            this.label33.Text = "Distri:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(535, 189);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(28, 12);
            this.label32.TabIndex = 328;
            this.label32.Text = "Prov:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(663, 187);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(28, 12);
            this.label31.TabIndex = 330;
            this.label31.Text = "Dpto:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(502, 17);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 25);
            this.label37.TabIndex = 332;
            this.label37.Text = "R.U.C.";
            // 
            // LblDireccion
            // 
            this.LblDireccion.AutoSize = true;
            this.LblDireccion.Location = new System.Drawing.Point(24, 56);
            this.LblDireccion.Name = "LblDireccion";
            this.LblDireccion.Size = new System.Drawing.Size(41, 13);
            this.LblDireccion.TabIndex = 342;
            this.LblDireccion.Text = "label39";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LblEstado,
            this.toolStripSeparator2,
            this.toolStripLabel1,
            this.TxtGuia,
            this.BtnConsultar,
            this.BtnImprimir,
            this.toolStripSeparator1,
            this.BtnVistaPrevia,
            this.BtnAnular});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(530, 25);
            this.toolStrip1.TabIndex = 343;
            this.toolStrip1.Text = "TsImpresion";
            // 
            // LblEstado
            // 
            this.LblEstado.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEstado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LblEstado.Name = "LblEstado";
            this.LblEstado.Size = new System.Drawing.Size(59, 22);
            this.LblEstado.Text = "LblEstado";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(198, 22);
            this.toolStripLabel1.Text = "Ingrese Numero de guía a consultar:";
            // 
            // TxtGuia
            // 
            this.TxtGuia.Name = "TxtGuia";
            this.TxtGuia.Size = new System.Drawing.Size(100, 25);
            // 
            // BtnConsultar
            // 
            this.BtnConsultar.Image = global::Halley.Presentacion.Properties.Resources.Consultar_16x16;
            this.BtnConsultar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnConsultar.Name = "BtnConsultar";
            this.BtnConsultar.Size = new System.Drawing.Size(78, 22);
            this.BtnConsultar.Text = "Consultar";
            this.BtnConsultar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnConsultar.Click += new System.EventHandler(this.BtnConsultar_Click_1);
            // 
            // BtnAnular
            // 
            this.BtnAnular.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAnular.Image = global::Halley.Presentacion.Properties.Resources.Cancelar_16x16;
            this.BtnAnular.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAnular.Name = "BtnAnular";
            this.BtnAnular.Size = new System.Drawing.Size(23, 22);
            this.BtnAnular.Text = "Cancelar";
            this.BtnAnular.Click += new System.EventHandler(this.BtnAnular_Click);
            // 
            // TxtConfVehicular
            // 
            this.TxtConfVehicular.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtConfVehicular.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtConfVehicular.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtConfVehicular.Location = new System.Drawing.Point(145, 335);
            this.TxtConfVehicular.MaxLength = 20;
            this.TxtConfVehicular.Name = "TxtConfVehicular";
            this.TxtConfVehicular.Size = new System.Drawing.Size(155, 16);
            this.TxtConfVehicular.TabIndex = 69;
            this.TxtConfVehicular.Tag = null;
            this.TxtConfVehicular.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtConfVehicular.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtMarca
            // 
            this.TxtMarca.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtMarca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMarca.Location = new System.Drawing.Point(145, 283);
            this.TxtMarca.MaxLength = 50;
            this.TxtMarca.Name = "TxtMarca";
            this.TxtMarca.Size = new System.Drawing.Size(79, 16);
            this.TxtMarca.TabIndex = 72;
            this.TxtMarca.Tag = null;
            this.TxtMarca.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtMarca.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtPlaca
            // 
            this.TxtPlaca.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtPlaca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPlaca.Location = new System.Drawing.Point(226, 283);
            this.TxtPlaca.MaxLength = 10;
            this.TxtPlaca.Name = "TxtPlaca";
            this.TxtPlaca.Size = new System.Drawing.Size(74, 16);
            this.TxtPlaca.TabIndex = 73;
            this.TxtPlaca.Tag = null;
            this.TxtPlaca.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtPlaca.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroConstInscripcion
            // 
            this.TxtNroConstInscripcion.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNroConstInscripcion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNroConstInscripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroConstInscripcion.Location = new System.Drawing.Point(145, 300);
            this.TxtNroConstInscripcion.MaxLength = 15;
            this.TxtNroConstInscripcion.Name = "TxtNroConstInscripcion";
            this.TxtNroConstInscripcion.Size = new System.Drawing.Size(155, 16);
            this.TxtNroConstInscripcion.TabIndex = 76;
            this.TxtNroConstInscripcion.Tag = null;
            this.TxtNroConstInscripcion.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroConstInscripcion.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroLicTransaportista
            // 
            this.TxtNroLicTransaportista.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNroLicTransaportista.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNroLicTransaportista.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroLicTransaportista.Location = new System.Drawing.Point(145, 318);
            this.TxtNroLicTransaportista.MaxLength = 15;
            this.TxtNroLicTransaportista.Name = "TxtNroLicTransaportista";
            this.TxtNroLicTransaportista.Size = new System.Drawing.Size(155, 16);
            this.TxtNroLicTransaportista.TabIndex = 77;
            this.TxtNroLicTransaportista.Tag = null;
            this.TxtNroLicTransaportista.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroLicTransaportista.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDomicilioPartida
            // 
            this.TxtDomicilioPartida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDomicilioPartida.Location = new System.Drawing.Point(109, 143);
            this.TxtDomicilioPartida.MaxLength = 20;
            this.TxtDomicilioPartida.Name = "TxtDomicilioPartida";
            this.TxtDomicilioPartida.Size = new System.Drawing.Size(290, 16);
            this.TxtDomicilioPartida.TabIndex = 304;
            this.TxtDomicilioPartida.Tag = null;
            this.TxtDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroDomicilioPartida
            // 
            this.TxtNroDomicilioPartida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNroDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNroDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroDomicilioPartida.Location = new System.Drawing.Point(48, 165);
            this.TxtNroDomicilioPartida.MaxLength = 50;
            this.TxtNroDomicilioPartida.Name = "TxtNroDomicilioPartida";
            this.TxtNroDomicilioPartida.Size = new System.Drawing.Size(85, 16);
            this.TxtNroDomicilioPartida.TabIndex = 305;
            this.TxtNroDomicilioPartida.Tag = null;
            this.TxtNroDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtIntDomicilioPartida
            // 
            this.TxtIntDomicilioPartida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtIntDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtIntDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIntDomicilioPartida.Location = new System.Drawing.Point(176, 165);
            this.TxtIntDomicilioPartida.MaxLength = 50;
            this.TxtIntDomicilioPartida.Name = "TxtIntDomicilioPartida";
            this.TxtIntDomicilioPartida.Size = new System.Drawing.Size(96, 16);
            this.TxtIntDomicilioPartida.TabIndex = 307;
            this.TxtIntDomicilioPartida.Tag = null;
            this.TxtIntDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtIntDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtZonaDomicilioPartida
            // 
            this.TxtZonaDomicilioPartida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtZonaDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtZonaDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtZonaDomicilioPartida.Location = new System.Drawing.Point(303, 165);
            this.TxtZonaDomicilioPartida.MaxLength = 50;
            this.TxtZonaDomicilioPartida.Name = "TxtZonaDomicilioPartida";
            this.TxtZonaDomicilioPartida.Size = new System.Drawing.Size(96, 16);
            this.TxtZonaDomicilioPartida.TabIndex = 309;
            this.TxtZonaDomicilioPartida.Tag = null;
            this.TxtZonaDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtZonaDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDisDomicilioPartida
            // 
            this.TxtDisDomicilioPartida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtDisDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDisDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDisDomicilioPartida.Location = new System.Drawing.Point(48, 187);
            this.TxtDisDomicilioPartida.MaxLength = 50;
            this.TxtDisDomicilioPartida.Name = "TxtDisDomicilioPartida";
            this.TxtDisDomicilioPartida.Size = new System.Drawing.Size(85, 16);
            this.TxtDisDomicilioPartida.TabIndex = 311;
            this.TxtDisDomicilioPartida.Tag = null;
            this.TxtDisDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDisDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtProvDomicilioPartida
            // 
            this.TxtProvDomicilioPartida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtProvDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtProvDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProvDomicilioPartida.Location = new System.Drawing.Point(176, 187);
            this.TxtProvDomicilioPartida.MaxLength = 50;
            this.TxtProvDomicilioPartida.Name = "TxtProvDomicilioPartida";
            this.TxtProvDomicilioPartida.Size = new System.Drawing.Size(96, 16);
            this.TxtProvDomicilioPartida.TabIndex = 313;
            this.TxtProvDomicilioPartida.Tag = null;
            this.TxtProvDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtProvDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDepDomicilioPartida
            // 
            this.TxtDepDomicilioPartida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtDepDomicilioPartida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDepDomicilioPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDepDomicilioPartida.Location = new System.Drawing.Point(303, 187);
            this.TxtDepDomicilioPartida.MaxLength = 50;
            this.TxtDepDomicilioPartida.Name = "TxtDepDomicilioPartida";
            this.TxtDepDomicilioPartida.Size = new System.Drawing.Size(97, 16);
            this.TxtDepDomicilioPartida.TabIndex = 315;
            this.TxtDepDomicilioPartida.Tag = null;
            this.TxtDepDomicilioPartida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDepDomicilioPartida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDestinatario
            // 
            this.TxtDestinatario.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDestinatario.Location = new System.Drawing.Point(253, 226);
            this.TxtDestinatario.MaxLength = 50;
            this.TxtDestinatario.Name = "TxtDestinatario";
            this.TxtDestinatario.Size = new System.Drawing.Size(533, 16);
            this.TxtDestinatario.TabIndex = 317;
            this.TxtDestinatario.Tag = null;
            this.TxtDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRUCDestinatario
            // 
            this.TxtRUCDestinatario.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtRUCDestinatario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtRUCDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRUCDestinatario.Location = new System.Drawing.Point(285, 243);
            this.TxtRUCDestinatario.MaxLength = 50;
            this.TxtRUCDestinatario.Name = "TxtRUCDestinatario";
            this.TxtRUCDestinatario.Size = new System.Drawing.Size(154, 16);
            this.TxtRUCDestinatario.TabIndex = 319;
            this.TxtRUCDestinatario.Tag = null;
            this.TxtRUCDestinatario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRUCDestinatario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDomicilioLlegada
            // 
            this.TxtDomicilioLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDomicilioLlegada.Location = new System.Drawing.Point(503, 145);
            this.TxtDomicilioLlegada.MaxLength = 20;
            this.TxtDomicilioLlegada.Name = "TxtDomicilioLlegada";
            this.TxtDomicilioLlegada.Size = new System.Drawing.Size(285, 16);
            this.TxtDomicilioLlegada.TabIndex = 321;
            this.TxtDomicilioLlegada.Tag = null;
            this.TxtDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNroDomicilioLlegada
            // 
            this.TxtNroDomicilioLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNroDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNroDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroDomicilioLlegada.Location = new System.Drawing.Point(438, 167);
            this.TxtNroDomicilioLlegada.MaxLength = 50;
            this.TxtNroDomicilioLlegada.Name = "TxtNroDomicilioLlegada";
            this.TxtNroDomicilioLlegada.Size = new System.Drawing.Size(85, 16);
            this.TxtNroDomicilioLlegada.TabIndex = 322;
            this.TxtNroDomicilioLlegada.Tag = null;
            this.TxtNroDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtIntDomicilioLlegada
            // 
            this.TxtIntDomicilioLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtIntDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtIntDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIntDomicilioLlegada.Location = new System.Drawing.Point(563, 167);
            this.TxtIntDomicilioLlegada.MaxLength = 50;
            this.TxtIntDomicilioLlegada.Name = "TxtIntDomicilioLlegada";
            this.TxtIntDomicilioLlegada.Size = new System.Drawing.Size(96, 16);
            this.TxtIntDomicilioLlegada.TabIndex = 324;
            this.TxtIntDomicilioLlegada.Tag = null;
            this.TxtIntDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtIntDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtZonaDomicilioLlegada
            // 
            this.TxtZonaDomicilioLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtZonaDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtZonaDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtZonaDomicilioLlegada.Location = new System.Drawing.Point(690, 167);
            this.TxtZonaDomicilioLlegada.MaxLength = 50;
            this.TxtZonaDomicilioLlegada.Name = "TxtZonaDomicilioLlegada";
            this.TxtZonaDomicilioLlegada.Size = new System.Drawing.Size(97, 16);
            this.TxtZonaDomicilioLlegada.TabIndex = 326;
            this.TxtZonaDomicilioLlegada.Tag = null;
            this.TxtZonaDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtZonaDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtProvDomicilioLlegada
            // 
            this.TxtProvDomicilioLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtProvDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtProvDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProvDomicilioLlegada.Location = new System.Drawing.Point(563, 187);
            this.TxtProvDomicilioLlegada.MaxLength = 50;
            this.TxtProvDomicilioLlegada.Name = "TxtProvDomicilioLlegada";
            this.TxtProvDomicilioLlegada.Size = new System.Drawing.Size(96, 16);
            this.TxtProvDomicilioLlegada.TabIndex = 329;
            this.TxtProvDomicilioLlegada.Tag = null;
            this.TxtProvDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtProvDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDepDomicilioLlegada
            // 
            this.TxtDepDomicilioLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtDepDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDepDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDepDomicilioLlegada.Location = new System.Drawing.Point(690, 187);
            this.TxtDepDomicilioLlegada.MaxLength = 50;
            this.TxtDepDomicilioLlegada.Name = "TxtDepDomicilioLlegada";
            this.TxtDepDomicilioLlegada.Size = new System.Drawing.Size(97, 16);
            this.TxtDepDomicilioLlegada.TabIndex = 331;
            this.TxtDepDomicilioLlegada.Tag = null;
            this.TxtDepDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDepDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRuc
            // 
            this.TxtRuc.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtRuc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtRuc.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRuc.Location = new System.Drawing.Point(578, 14);
            this.TxtRuc.MaxLength = 50;
            this.TxtRuc.Name = "TxtRuc";
            this.TxtRuc.Size = new System.Drawing.Size(167, 26);
            this.TxtRuc.TabIndex = 333;
            this.TxtRuc.Tag = null;
            this.TxtRuc.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRuc.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDisDomicilioLlegada
            // 
            this.TxtDisDomicilioLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtDisDomicilioLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDisDomicilioLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDisDomicilioLlegada.Location = new System.Drawing.Point(438, 187);
            this.TxtDisDomicilioLlegada.MaxLength = 50;
            this.TxtDisDomicilioLlegada.Name = "TxtDisDomicilioLlegada";
            this.TxtDisDomicilioLlegada.Size = new System.Drawing.Size(85, 16);
            this.TxtDisDomicilioLlegada.TabIndex = 334;
            this.TxtDisDomicilioLlegada.Tag = null;
            this.TxtDisDomicilioLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDisDomicilioLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNumGuiaRemision
            // 
            this.TxtNumGuiaRemision.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNumGuiaRemision.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNumGuiaRemision.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumGuiaRemision.Location = new System.Drawing.Point(555, 91);
            this.TxtNumGuiaRemision.MaxLength = 50;
            this.TxtNumGuiaRemision.Name = "TxtNumGuiaRemision";
            this.TxtNumGuiaRemision.Size = new System.Drawing.Size(141, 26);
            this.TxtNumGuiaRemision.TabIndex = 335;
            this.TxtNumGuiaRemision.Tag = null;
            this.TxtNumGuiaRemision.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumGuiaRemision.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtFechaEmision
            // 
            this.TxtFechaEmision.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtFechaEmision.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtFechaEmision.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFechaEmision.Location = new System.Drawing.Point(78, 109);
            this.TxtFechaEmision.MaxLength = 50;
            this.TxtFechaEmision.Name = "TxtFechaEmision";
            this.TxtFechaEmision.Size = new System.Drawing.Size(96, 16);
            this.TxtFechaEmision.TabIndex = 339;
            this.TxtFechaEmision.Tag = null;
            this.TxtFechaEmision.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFechaEmision.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtFechaInicioTraslado
            // 
            this.TxtFechaInicioTraslado.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtFechaInicioTraslado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtFechaInicioTraslado.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFechaInicioTraslado.Location = new System.Drawing.Point(64, 234);
            this.TxtFechaInicioTraslado.MaxLength = 50;
            this.TxtFechaInicioTraslado.Name = "TxtFechaInicioTraslado";
            this.TxtFechaInicioTraslado.Size = new System.Drawing.Size(96, 16);
            this.TxtFechaInicioTraslado.TabIndex = 340;
            this.TxtFechaInicioTraslado.Tag = null;
            this.TxtFechaInicioTraslado.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFechaInicioTraslado.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtEmpresa
            // 
            this.TxtEmpresa.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtEmpresa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtEmpresa.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEmpresa.Location = new System.Drawing.Point(176, 24);
            this.TxtEmpresa.MaxLength = 50;
            this.TxtEmpresa.Name = "TxtEmpresa";
            this.TxtEmpresa.Size = new System.Drawing.Size(257, 26);
            this.TxtEmpresa.TabIndex = 341;
            this.TxtEmpresa.Tag = null;
            this.TxtEmpresa.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtEmpresa.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleShape12,
            this.lineShape1,
            this.rectangleShape10,
            this.rectangleShape4,
            this.rectangleShape9,
            this.rectangleShape8,
            this.rectangleShape7,
            this.rectangleShape5,
            this.rectangleShape3,
            this.lineShape17,
            this.lineShape13,
            this.rectangleShape11,
            this.lineShape16,
            this.lineShape14,
            this.lineShape6,
            this.lineShape5,
            this.rectangleShape6,
            this.rectangleShape2,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(812, 690);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape17
            // 
            this.lineShape17.Name = "lineShape17";
            this.lineShape17.X1 = 560;
            this.lineShape17.X2 = 688;
            this.lineShape17.Y1 = 625;
            this.lineShape17.Y2 = 625;
            // 
            // lineShape13
            // 
            this.lineShape13.Name = "lineShape13";
            this.lineShape13.X1 = 458;
            this.lineShape13.X2 = 586;
            this.lineShape13.Y1 = 578;
            this.lineShape13.Y2 = 578;
            // 
            // rectangleShape11
            // 
            this.rectangleShape11.CornerRadius = 10;
            this.rectangleShape11.Location = new System.Drawing.Point(268, 78);
            this.rectangleShape11.Name = "rectangleShape11";
            this.rectangleShape11.Size = new System.Drawing.Size(62, 55);
            // 
            // lineShape16
            // 
            this.lineShape16.Name = "lineShape16";
            this.lineShape16.X1 = 10;
            this.lineShape16.X2 = 270;
            this.lineShape16.Y1 = 587;
            this.lineShape16.Y2 = 587;
            // 
            // lineShape14
            // 
            this.lineShape14.Name = "lineShape14";
            this.lineShape14.X1 = 656;
            this.lineShape14.X2 = 784;
            this.lineShape14.Y1 = 569;
            this.lineShape14.Y2 = 569;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 475;
            this.lineShape6.X2 = 792;
            this.lineShape6.Y1 = 86;
            this.lineShape6.Y2 = 86;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 474;
            this.lineShape5.X2 = 794;
            this.lineShape5.Y1 = 49;
            this.lineShape5.Y2 = 49;
            // 
            // rectangleShape6
            // 
            this.rectangleShape6.CornerRadius = 10;
            this.rectangleShape6.Location = new System.Drawing.Point(9, 572);
            this.rectangleShape6.Name = "rectangleShape6";
            this.rectangleShape6.Size = new System.Drawing.Size(263, 66);
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.CornerRadius = 10;
            this.rectangleShape2.Location = new System.Drawing.Point(473, 7);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(321, 122);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.AutoScroll = true;
            this.toolStripContainer1.ContentPanel.BackColor = System.Drawing.Color.FloralWhite;
            this.toolStripContainer1.ContentPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label58);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtPesoTotal);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label29);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtFecha);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtRUCTransporte);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label22);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtEmpresaTransporte);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label18);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label8);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label7);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstBruto6);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstBruto5);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstBruto4);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstBruto3);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstBruto2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstBruto1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstTara4);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstTara3);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstTara2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtCodigoDespacho);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label57);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtProducto);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label56);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtBruto);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label55);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtTara);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label54);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNeto);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label53);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtPrecioUnitario);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label52);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtTotalImporte);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label51);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtHoraLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label50);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtHoraSalida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label49);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtHoraEntrada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label48);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtPesoPromedio);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label47);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtAves);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label45);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroJabas);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label44);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtHembra);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label6);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtMacho);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label5);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtGalpon);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label4);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label3);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtOrden);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtCostoMinimo);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label46);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtRecFactNro);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label43);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtGalponero);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label42);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label41);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtPesador);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label38);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label40);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label39);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LblDireccion);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtEmpresa);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtFechaInicioTraslado);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtFechaEmision);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNombreChofer);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNumGuiaRemision);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDisDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtRuc);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label37);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDepDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label31);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtProvDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label32);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label33);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtZonaDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label34);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtIntDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label35);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDomicilioLlegada);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label36);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtRUCDestinatario);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label30);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDestinatario);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDepDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label26);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtProvDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label27);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDisDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label28);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtZonaDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label25);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtIntDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label24);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtDomicilioPartida);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label23);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroLicTransaportista);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtNroConstInscripcion);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label20);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label21);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtPlaca);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtMarca);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label19);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.TxtConfVehicular);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label17);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label16);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label15);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label14);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label13);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.pictureBox1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.LstTara1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label12);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label11);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label10);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label9);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.shapeContainer1);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(814, 692);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(814, 717);
            this.toolStripContainer1.TabIndex = 344;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(276, 663);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(51, 12);
            this.label58.TabIndex = 406;
            this.label58.Text = "Peso Total:";
            // 
            // TxtPesoTotal
            // 
            this.TxtPesoTotal.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtPesoTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtPesoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPesoTotal.Location = new System.Drawing.Point(330, 661);
            this.TxtPesoTotal.MaxLength = 50;
            this.TxtPesoTotal.Name = "TxtPesoTotal";
            this.TxtPesoTotal.Size = new System.Drawing.Size(96, 16);
            this.TxtPesoTotal.TabIndex = 405;
            this.TxtPesoTotal.Tag = null;
            this.TxtPesoTotal.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtPesoTotal.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(226, 645);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 12);
            this.label29.TabIndex = 404;
            this.label29.Text = "Fecha:";
            // 
            // TxtFecha
            // 
            this.TxtFecha.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtFecha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFecha.Location = new System.Drawing.Point(264, 642);
            this.TxtFecha.MaxLength = 50;
            this.TxtFecha.Name = "TxtFecha";
            this.TxtFecha.Size = new System.Drawing.Size(96, 16);
            this.TxtFecha.TabIndex = 403;
            this.TxtFecha.Tag = null;
            this.TxtFecha.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFecha.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtRUCTransporte
            // 
            this.TxtRUCTransporte.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtRUCTransporte.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtRUCTransporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRUCTransporte.Location = new System.Drawing.Point(412, 329);
            this.TxtRUCTransporte.MaxLength = 50;
            this.TxtRUCTransporte.Name = "TxtRUCTransporte";
            this.TxtRUCTransporte.Size = new System.Drawing.Size(154, 16);
            this.TxtRUCTransporte.TabIndex = 402;
            this.TxtRUCTransporte.Tag = null;
            this.TxtRUCTransporte.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRUCTransporte.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(330, 331);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(76, 12);
            this.label22.TabIndex = 401;
            this.label22.Text = "Numero de RUC:";
            // 
            // TxtEmpresaTransporte
            // 
            this.TxtEmpresaTransporte.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtEmpresaTransporte.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtEmpresaTransporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEmpresaTransporte.Location = new System.Drawing.Point(329, 305);
            this.TxtEmpresaTransporte.MaxLength = 50;
            this.TxtEmpresaTransporte.Name = "TxtEmpresaTransporte";
            this.TxtEmpresaTransporte.Size = new System.Drawing.Size(457, 16);
            this.TxtEmpresaTransporte.TabIndex = 400;
            this.TxtEmpresaTransporte.Tag = null;
            this.TxtEmpresaTransporte.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtEmpresaTransporte.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(329, 288);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(107, 12);
            this.label18.TabIndex = 399;
            this.label18.Text = "Nombre o Razon Social:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(412, 146);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 12);
            this.label8.TabIndex = 398;
            this.label8.Text = "Punto de Llegada:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 12);
            this.label7.TabIndex = 397;
            this.label7.Text = "Punto de Partida:";
            // 
            // LstBruto6
            // 
            this.LstBruto6.ColumnWidth = 100;
            this.LstBruto6.FormatString = "N2";
            this.LstBruto6.FormattingEnabled = true;
            this.LstBruto6.Location = new System.Drawing.Point(715, 377);
            this.LstBruto6.Name = "LstBruto6";
            this.LstBruto6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstBruto6.Size = new System.Drawing.Size(75, 108);
            this.LstBruto6.TabIndex = 396;
            // 
            // LstBruto5
            // 
            this.LstBruto5.ColumnWidth = 100;
            this.LstBruto5.FormatString = "N2";
            this.LstBruto5.FormattingEnabled = true;
            this.LstBruto5.Location = new System.Drawing.Point(639, 377);
            this.LstBruto5.Name = "LstBruto5";
            this.LstBruto5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstBruto5.Size = new System.Drawing.Size(75, 108);
            this.LstBruto5.TabIndex = 395;
            // 
            // LstBruto4
            // 
            this.LstBruto4.ColumnWidth = 100;
            this.LstBruto4.FormatString = "N2";
            this.LstBruto4.FormattingEnabled = true;
            this.LstBruto4.Location = new System.Drawing.Point(561, 377);
            this.LstBruto4.Name = "LstBruto4";
            this.LstBruto4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstBruto4.Size = new System.Drawing.Size(75, 108);
            this.LstBruto4.TabIndex = 394;
            // 
            // LstBruto3
            // 
            this.LstBruto3.ColumnWidth = 100;
            this.LstBruto3.FormatString = "N2";
            this.LstBruto3.FormattingEnabled = true;
            this.LstBruto3.Location = new System.Drawing.Point(484, 377);
            this.LstBruto3.Name = "LstBruto3";
            this.LstBruto3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstBruto3.Size = new System.Drawing.Size(75, 108);
            this.LstBruto3.TabIndex = 393;
            // 
            // LstBruto2
            // 
            this.LstBruto2.ColumnWidth = 100;
            this.LstBruto2.FormatString = "N2";
            this.LstBruto2.FormattingEnabled = true;
            this.LstBruto2.Location = new System.Drawing.Point(407, 377);
            this.LstBruto2.Name = "LstBruto2";
            this.LstBruto2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstBruto2.Size = new System.Drawing.Size(75, 108);
            this.LstBruto2.TabIndex = 392;
            // 
            // LstBruto1
            // 
            this.LstBruto1.ColumnWidth = 100;
            this.LstBruto1.FormatString = "N2";
            this.LstBruto1.FormattingEnabled = true;
            this.LstBruto1.Location = new System.Drawing.Point(330, 377);
            this.LstBruto1.Name = "LstBruto1";
            this.LstBruto1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstBruto1.Size = new System.Drawing.Size(75, 108);
            this.LstBruto1.TabIndex = 391;
            // 
            // LstTara4
            // 
            this.LstTara4.ColumnWidth = 100;
            this.LstTara4.FormatString = "N2";
            this.LstTara4.FormattingEnabled = true;
            this.LstTara4.Location = new System.Drawing.Point(253, 377);
            this.LstTara4.Name = "LstTara4";
            this.LstTara4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstTara4.Size = new System.Drawing.Size(75, 108);
            this.LstTara4.TabIndex = 390;
            // 
            // LstTara3
            // 
            this.LstTara3.ColumnWidth = 100;
            this.LstTara3.FormatString = "N2";
            this.LstTara3.FormattingEnabled = true;
            this.LstTara3.Location = new System.Drawing.Point(176, 377);
            this.LstTara3.Name = "LstTara3";
            this.LstTara3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstTara3.Size = new System.Drawing.Size(75, 108);
            this.LstTara3.TabIndex = 345;
            // 
            // LstTara2
            // 
            this.LstTara2.ColumnWidth = 100;
            this.LstTara2.FormatString = "N2";
            this.LstTara2.FormattingEnabled = true;
            this.LstTara2.Location = new System.Drawing.Point(99, 377);
            this.LstTara2.Name = "LstTara2";
            this.LstTara2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LstTara2.Size = new System.Drawing.Size(75, 108);
            this.LstTara2.TabIndex = 345;
            // 
            // TxtCodigoDespacho
            // 
            this.TxtCodigoDespacho.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtCodigoDespacho.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtCodigoDespacho.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCodigoDespacho.Location = new System.Drawing.Point(714, 543);
            this.TxtCodigoDespacho.MaxLength = 50;
            this.TxtCodigoDespacho.Name = "TxtCodigoDespacho";
            this.TxtCodigoDespacho.Size = new System.Drawing.Size(55, 16);
            this.TxtCodigoDespacho.TabIndex = 389;
            this.TxtCodigoDespacho.Tag = null;
            this.TxtCodigoDespacho.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtCodigoDespacho.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(710, 530);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(76, 12);
            this.label57.TabIndex = 388;
            this.label57.Text = "COD DESPACHO";
            // 
            // TxtProducto
            // 
            this.TxtProducto.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtProducto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProducto.Location = new System.Drawing.Point(525, 665);
            this.TxtProducto.MaxLength = 15;
            this.TxtProducto.Name = "TxtProducto";
            this.TxtProducto.Size = new System.Drawing.Size(277, 16);
            this.TxtProducto.TabIndex = 387;
            this.TxtProducto.Tag = null;
            this.TxtProducto.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtProducto.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(464, 666);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(56, 12);
            this.label56.TabIndex = 386;
            this.label56.Text = "PRODUCTO";
            // 
            // TxtBruto
            // 
            this.TxtBruto.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtBruto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBruto.Location = new System.Drawing.Point(273, 543);
            this.TxtBruto.MaxLength = 50;
            this.TxtBruto.Name = "TxtBruto";
            this.TxtBruto.Size = new System.Drawing.Size(55, 16);
            this.TxtBruto.TabIndex = 385;
            this.TxtBruto.Tag = null;
            this.TxtBruto.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtBruto.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(273, 530);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(61, 12);
            this.label55.TabIndex = 384;
            this.label55.Text = "PESO BRUTO";
            // 
            // TxtTara
            // 
            this.TxtTara.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtTara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtTara.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTara.Location = new System.Drawing.Point(364, 543);
            this.TxtTara.MaxLength = 50;
            this.TxtTara.Name = "TxtTara";
            this.TxtTara.Size = new System.Drawing.Size(55, 16);
            this.TxtTara.TabIndex = 383;
            this.TxtTara.Tag = null;
            this.TxtTara.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtTara.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(364, 530);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(53, 12);
            this.label54.TabIndex = 382;
            this.label54.Text = "PESO TARA";
            // 
            // TxtNeto
            // 
            this.TxtNeto.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNeto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNeto.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNeto.Location = new System.Drawing.Point(446, 545);
            this.TxtNeto.MaxLength = 50;
            this.TxtNeto.Name = "TxtNeto";
            this.TxtNeto.Size = new System.Drawing.Size(55, 16);
            this.TxtNeto.TabIndex = 381;
            this.TxtNeto.Tag = null;
            this.TxtNeto.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNeto.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(446, 530);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(54, 12);
            this.label53.TabIndex = 380;
            this.label53.Text = "PESO NETO";
            // 
            // TxtPrecioUnitario
            // 
            this.TxtPrecioUnitario.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtPrecioUnitario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtPrecioUnitario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPrecioUnitario.Location = new System.Drawing.Point(538, 545);
            this.TxtPrecioUnitario.MaxLength = 50;
            this.TxtPrecioUnitario.Name = "TxtPrecioUnitario";
            this.TxtPrecioUnitario.Size = new System.Drawing.Size(55, 16);
            this.TxtPrecioUnitario.TabIndex = 379;
            this.TxtPrecioUnitario.Tag = null;
            this.TxtPrecioUnitario.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtPrecioUnitario.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(538, 530);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(62, 12);
            this.label52.TabIndex = 378;
            this.label52.Text = "PRECIO UNIT";
            // 
            // TxtTotalImporte
            // 
            this.TxtTotalImporte.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtTotalImporte.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtTotalImporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTotalImporte.Location = new System.Drawing.Point(627, 543);
            this.TxtTotalImporte.MaxLength = 50;
            this.TxtTotalImporte.Name = "TxtTotalImporte";
            this.TxtTotalImporte.Size = new System.Drawing.Size(55, 16);
            this.TxtTotalImporte.TabIndex = 377;
            this.TxtTotalImporte.Tag = null;
            this.TxtTotalImporte.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtTotalImporte.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(627, 530);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 12);
            this.label51.TabIndex = 376;
            this.label51.Text = "TOTAL IMP";
            // 
            // TxtHoraLlegada
            // 
            this.TxtHoraLlegada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtHoraLlegada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtHoraLlegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHoraLlegada.Location = new System.Drawing.Point(710, 514);
            this.TxtHoraLlegada.MaxLength = 50;
            this.TxtHoraLlegada.Name = "TxtHoraLlegada";
            this.TxtHoraLlegada.Size = new System.Drawing.Size(55, 16);
            this.TxtHoraLlegada.TabIndex = 375;
            this.TxtHoraLlegada.Tag = null;
            this.TxtHoraLlegada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtHoraLlegada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(710, 498);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(73, 12);
            this.label50.TabIndex = 374;
            this.label50.Text = "HORA LLEGADA";
            // 
            // TxtHoraSalida
            // 
            this.TxtHoraSalida.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtHoraSalida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtHoraSalida.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHoraSalida.Location = new System.Drawing.Point(627, 513);
            this.TxtHoraSalida.MaxLength = 50;
            this.TxtHoraSalida.Name = "TxtHoraSalida";
            this.TxtHoraSalida.Size = new System.Drawing.Size(55, 16);
            this.TxtHoraSalida.TabIndex = 373;
            this.TxtHoraSalida.Tag = null;
            this.TxtHoraSalida.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtHoraSalida.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(627, 497);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(65, 12);
            this.label49.TabIndex = 372;
            this.label49.Text = "HORA SALIDA";
            // 
            // TxtHoraEntrada
            // 
            this.TxtHoraEntrada.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtHoraEntrada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtHoraEntrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHoraEntrada.Location = new System.Drawing.Point(538, 514);
            this.TxtHoraEntrada.MaxLength = 50;
            this.TxtHoraEntrada.Name = "TxtHoraEntrada";
            this.TxtHoraEntrada.Size = new System.Drawing.Size(55, 16);
            this.TxtHoraEntrada.TabIndex = 365;
            this.TxtHoraEntrada.Tag = null;
            this.TxtHoraEntrada.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtHoraEntrada.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(538, 498);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(75, 12);
            this.label48.TabIndex = 364;
            this.label48.Text = "HORA ENTRADA";
            // 
            // TxtPesoPromedio
            // 
            this.TxtPesoPromedio.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtPesoPromedio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtPesoPromedio.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPesoPromedio.Location = new System.Drawing.Point(446, 513);
            this.TxtPesoPromedio.MaxLength = 50;
            this.TxtPesoPromedio.Name = "TxtPesoPromedio";
            this.TxtPesoPromedio.Size = new System.Drawing.Size(55, 16);
            this.TxtPesoPromedio.TabIndex = 371;
            this.TxtPesoPromedio.Tag = null;
            this.TxtPesoPromedio.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtPesoPromedio.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(446, 497);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(80, 12);
            this.label47.TabIndex = 370;
            this.label47.Text = "PESO PROMEDIO";
            // 
            // TxtAves
            // 
            this.TxtAves.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtAves.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtAves.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAves.Location = new System.Drawing.Point(364, 514);
            this.TxtAves.MaxLength = 50;
            this.TxtAves.Name = "TxtAves";
            this.TxtAves.Size = new System.Drawing.Size(55, 16);
            this.TxtAves.TabIndex = 369;
            this.TxtAves.Tag = null;
            this.TxtAves.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtAves.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(364, 498);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(27, 12);
            this.label45.TabIndex = 368;
            this.label45.Text = "AVES";
            // 
            // TxtNroJabas
            // 
            this.TxtNroJabas.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNroJabas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNroJabas.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNroJabas.Location = new System.Drawing.Point(273, 514);
            this.TxtNroJabas.MaxLength = 50;
            this.TxtNroJabas.Name = "TxtNroJabas";
            this.TxtNroJabas.Size = new System.Drawing.Size(55, 16);
            this.TxtNroJabas.TabIndex = 367;
            this.TxtNroJabas.Tag = null;
            this.TxtNroJabas.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroJabas.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(273, 498);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(54, 12);
            this.label44.TabIndex = 366;
            this.label44.Text = "NRO JABAS";
            // 
            // TxtHembra
            // 
            this.TxtHembra.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtHembra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtHembra.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHembra.Location = new System.Drawing.Point(192, 514);
            this.TxtHembra.MaxLength = 50;
            this.TxtHembra.Name = "TxtHembra";
            this.TxtHembra.Size = new System.Drawing.Size(55, 16);
            this.TxtHembra.TabIndex = 365;
            this.TxtHembra.Tag = null;
            this.TxtHembra.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtHembra.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(192, 498);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 12);
            this.label6.TabIndex = 364;
            this.label6.Text = "HEMBRA";
            // 
            // TxtMacho
            // 
            this.TxtMacho.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtMacho.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtMacho.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMacho.Location = new System.Drawing.Point(113, 514);
            this.TxtMacho.MaxLength = 50;
            this.TxtMacho.Name = "TxtMacho";
            this.TxtMacho.Size = new System.Drawing.Size(55, 16);
            this.TxtMacho.TabIndex = 363;
            this.TxtMacho.Tag = null;
            this.TxtMacho.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtMacho.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(113, 498);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 12);
            this.label5.TabIndex = 362;
            this.label5.Text = "MACHO";
            // 
            // TxtGalpon
            // 
            this.TxtGalpon.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtGalpon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtGalpon.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtGalpon.Location = new System.Drawing.Point(36, 512);
            this.TxtGalpon.MaxLength = 50;
            this.TxtGalpon.Name = "TxtGalpon";
            this.TxtGalpon.Size = new System.Drawing.Size(55, 16);
            this.TxtGalpon.TabIndex = 361;
            this.TxtGalpon.Tag = null;
            this.TxtGalpon.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtGalpon.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 496);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 12);
            this.label4.TabIndex = 360;
            this.label4.Text = "GALPON";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(507, 362);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 15);
            this.label3.TabIndex = 360;
            this.label3.Text = "PESO BRUTO";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TxtOrden
            // 
            this.TxtOrden.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtOrden.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtOrden.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtOrden.Location = new System.Drawing.Point(272, 109);
            this.TxtOrden.MaxLength = 50;
            this.TxtOrden.Name = "TxtOrden";
            this.TxtOrden.Size = new System.Drawing.Size(55, 16);
            this.TxtOrden.TabIndex = 359;
            this.TxtOrden.Tag = null;
            this.TxtOrden.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtOrden.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtCostoMinimo
            // 
            this.TxtCostoMinimo.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtCostoMinimo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtCostoMinimo.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCostoMinimo.Location = new System.Drawing.Point(176, 661);
            this.TxtCostoMinimo.MaxLength = 10;
            this.TxtCostoMinimo.Name = "TxtCostoMinimo";
            this.TxtCostoMinimo.Size = new System.Drawing.Size(91, 16);
            this.TxtCostoMinimo.TabIndex = 358;
            this.TxtCostoMinimo.Tag = null;
            this.TxtCostoMinimo.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtCostoMinimo.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(18, 660);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(153, 12);
            this.label46.TabIndex = 357;
            this.label46.Text = "COSTO MINIMO DEL TRASLADO:";
            // 
            // TxtRecFactNro
            // 
            this.TxtRecFactNro.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtRecFactNro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtRecFactNro.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRecFactNro.Location = new System.Drawing.Point(94, 643);
            this.TxtRecFactNro.MaxLength = 10;
            this.TxtRecFactNro.Name = "TxtRecFactNro";
            this.TxtRecFactNro.Size = new System.Drawing.Size(126, 16);
            this.TxtRecFactNro.TabIndex = 352;
            this.TxtRecFactNro.Tag = null;
            this.TxtRecFactNro.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRecFactNro.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(16, 645);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(70, 12);
            this.label43.TabIndex = 351;
            this.label43.Text = "REF. FACT N°:";
            // 
            // TxtGalponero
            // 
            this.TxtGalponero.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtGalponero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtGalponero.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtGalponero.Location = new System.Drawing.Point(569, 644);
            this.TxtGalponero.MaxLength = 10;
            this.TxtGalponero.Name = "TxtGalponero";
            this.TxtGalponero.Size = new System.Drawing.Size(149, 16);
            this.TxtGalponero.TabIndex = 350;
            this.TxtGalponero.Tag = null;
            this.TxtGalponero.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtGalponero.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(526, 646);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(41, 12);
            this.label42.TabIndex = 349;
            this.label42.Text = "Nombre:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(635, 601);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(41, 12);
            this.label41.TabIndex = 347;
            this.label41.Text = "Nombre:";
            // 
            // TxtPesador
            // 
            this.TxtPesador.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtPesador.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtPesador.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPesador.Location = new System.Drawing.Point(479, 597);
            this.TxtPesador.MaxLength = 10;
            this.TxtPesador.Name = "TxtPesador";
            this.TxtPesador.Size = new System.Drawing.Size(129, 16);
            this.TxtPesador.TabIndex = 346;
            this.TxtPesador.Tag = null;
            this.TxtPesador.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtPesador.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(437, 601);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(41, 12);
            this.label38.TabIndex = 345;
            this.label38.Text = "Nombre:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(507, 581);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 12);
            this.label40.TabIndex = 344;
            this.label40.Text = "Pesador";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(280, 86);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 12);
            this.label39.TabIndex = 343;
            this.label39.Text = "ORDEN";
            // 
            // TxtNombreChofer
            // 
            this.TxtNombreChofer.BackColor = System.Drawing.Color.FloralWhite;
            this.TxtNombreChofer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNombreChofer.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNombreChofer.Location = new System.Drawing.Point(677, 598);
            this.TxtNombreChofer.MaxLength = 15;
            this.TxtNombreChofer.Name = "TxtNombreChofer";
            this.TxtNombreChofer.Size = new System.Drawing.Size(122, 16);
            this.TxtNombreChofer.TabIndex = 337;
            this.TxtNombreChofer.Tag = null;
            this.TxtNombreChofer.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNombreChofer.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(475, 270);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 12);
            this.label15.TabIndex = 21;
            this.label15.Text = "EMPRESA DE TRANSPORTE";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Halley.Presentacion.Properties.Resources.HalleyLogo;
            this.pictureBox1.Location = new System.Drawing.Point(16, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(155, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.CornerRadius = 10;
            this.rectangleShape1.Location = new System.Drawing.Point(9, 137);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(394, 70);
            // 
            // rectangleShape3
            // 
            this.rectangleShape3.CornerRadius = 10;
            this.rectangleShape3.Location = new System.Drawing.Point(405, 136);
            this.rectangleShape3.Name = "rectangleShape3";
            this.rectangleShape3.Size = new System.Drawing.Size(390, 70);
            // 
            // rectangleShape5
            // 
            this.rectangleShape5.CornerRadius = 10;
            this.rectangleShape5.Location = new System.Drawing.Point(9, 209);
            this.rectangleShape5.Name = "rectangleShape5";
            this.rectangleShape5.Size = new System.Drawing.Size(207, 52);
            // 
            // rectangleShape7
            // 
            this.rectangleShape7.CornerRadius = 10;
            this.rectangleShape7.Location = new System.Drawing.Point(236, 210);
            this.rectangleShape7.Name = "rectangleShape7";
            this.rectangleShape7.Size = new System.Drawing.Size(561, 52);
            // 
            // rectangleShape8
            // 
            this.rectangleShape8.CornerRadius = 10;
            this.rectangleShape8.Location = new System.Drawing.Point(8, 266);
            this.rectangleShape8.Name = "rectangleShape8";
            this.rectangleShape8.Size = new System.Drawing.Size(300, 91);
            // 
            // rectangleShape9
            // 
            this.rectangleShape9.CornerRadius = 10;
            this.rectangleShape9.Location = new System.Drawing.Point(313, 268);
            this.rectangleShape9.Name = "rectangleShape9";
            this.rectangleShape9.Size = new System.Drawing.Size(485, 89);
            // 
            // rectangleShape4
            // 
            this.rectangleShape4.CornerRadius = 10;
            this.rectangleShape4.Location = new System.Drawing.Point(9, 361);
            this.rectangleShape4.Name = "rectangleShape4";
            this.rectangleShape4.Size = new System.Drawing.Size(786, 127);
            // 
            // rectangleShape10
            // 
            this.rectangleShape10.CornerRadius = 10;
            this.rectangleShape10.Location = new System.Drawing.Point(7, 493);
            this.rectangleShape10.Name = "rectangleShape10";
            this.rectangleShape10.Size = new System.Drawing.Size(790, 76);
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 656;
            this.lineShape1.X2 = 784;
            this.lineShape1.Y1 = 578;
            this.lineShape1.Y2 = 578;
            // 
            // rectangleShape12
            // 
            this.rectangleShape12.CornerRadius = 10;
            this.rectangleShape12.Location = new System.Drawing.Point(11, 77);
            this.rectangleShape12.Name = "rectangleShape12";
            this.rectangleShape12.Size = new System.Drawing.Size(254, 55);
            // 
            // FrmGuiaRemisionPeso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(814, 717);
            this.Controls.Add(this.toolStripContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmGuiaRemisionPeso";
            this.Text = "Guia Remision Peso";
            this.Load += new System.EventHandler(this.FrmGuiaRemisionPeso_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConfVehicular)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMarca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPlaca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroConstInscripcion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroLicTransaportista)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioPartida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCDestinatario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIntDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtZonaDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProvDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDepDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRuc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDisDomicilioLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumGuiaRemision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaEmision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFechaInicioTraslado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmpresa)).EndInit();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPesoTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFecha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRUCTransporte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmpresaTransporte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCodigoDespacho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtProducto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtBruto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNeto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPrecioUnitario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTotalImporte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHoraLlegada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHoraSalida)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHoraEntrada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPesoPromedio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAves)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroJabas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtHembra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMacho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtGalpon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtOrden)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCostoMinimo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRecFactNro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtGalponero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPesador)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreChofer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.ToolStrip miniToolStrip;
        private System.Windows.Forms.ToolStripButton BtnImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton BtnVistaPrevia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox LstTara1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label LblDireccion;
        private C1.Win.C1Input.C1TextBox TxtEmpresa;
        private C1.Win.C1Input.C1TextBox TxtFechaInicioTraslado;
        private C1.Win.C1Input.C1TextBox TxtFechaEmision;
        private C1.Win.C1Input.C1TextBox TxtNumGuiaRemision;
        private C1.Win.C1Input.C1TextBox TxtDisDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtRuc;
        private C1.Win.C1Input.C1TextBox TxtDepDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtProvDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtZonaDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtIntDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtNroDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtDomicilioLlegada;
        private C1.Win.C1Input.C1TextBox TxtRUCDestinatario;
        private C1.Win.C1Input.C1TextBox TxtDestinatario;
        private C1.Win.C1Input.C1TextBox TxtDepDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtProvDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtDisDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtZonaDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtIntDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtNroDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtDomicilioPartida;
        private C1.Win.C1Input.C1TextBox TxtNroLicTransaportista;
        private C1.Win.C1Input.C1TextBox TxtNroConstInscripcion;
        private C1.Win.C1Input.C1TextBox TxtPlaca;
        private C1.Win.C1Input.C1TextBox TxtMarca;
        private C1.Win.C1Input.C1TextBox TxtConfVehicular;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape16;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape14;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape6;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox TxtGuia;
        private System.Windows.Forms.ToolStripButton BtnConsultar;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape17;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape13;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape11;
        private C1.Win.C1Input.C1TextBox TxtCostoMinimo;
        private System.Windows.Forms.Label label46;
        private C1.Win.C1Input.C1TextBox TxtRecFactNro;
        private System.Windows.Forms.Label label43;
        private C1.Win.C1Input.C1TextBox TxtGalponero;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private C1.Win.C1Input.C1TextBox TxtPesador;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private C1.Win.C1Input.C1TextBox TxtOrden;
        private C1.Win.C1Input.C1TextBox TxtHoraLlegada;
        private System.Windows.Forms.Label label50;
        private C1.Win.C1Input.C1TextBox TxtHoraSalida;
        private System.Windows.Forms.Label label49;
        private C1.Win.C1Input.C1TextBox TxtHoraEntrada;
        private System.Windows.Forms.Label label48;
        private C1.Win.C1Input.C1TextBox TxtPesoPromedio;
        private System.Windows.Forms.Label label47;
        private C1.Win.C1Input.C1TextBox TxtAves;
        private System.Windows.Forms.Label label45;
        private C1.Win.C1Input.C1TextBox TxtNroJabas;
        private System.Windows.Forms.Label label44;
        private C1.Win.C1Input.C1TextBox TxtHembra;
        private System.Windows.Forms.Label label6;
        private C1.Win.C1Input.C1TextBox TxtMacho;
        private System.Windows.Forms.Label label5;
        private C1.Win.C1Input.C1TextBox TxtGalpon;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private C1.Win.C1Input.C1TextBox TxtBruto;
        private System.Windows.Forms.Label label55;
        private C1.Win.C1Input.C1TextBox TxtTara;
        private System.Windows.Forms.Label label54;
        private C1.Win.C1Input.C1TextBox TxtNeto;
        private System.Windows.Forms.Label label53;
        private C1.Win.C1Input.C1TextBox TxtPrecioUnitario;
        private System.Windows.Forms.Label label52;
        private C1.Win.C1Input.C1TextBox TxtTotalImporte;
        private System.Windows.Forms.Label label51;
        private C1.Win.C1Input.C1TextBox TxtProducto;
        private System.Windows.Forms.Label label56;
        private C1.Win.C1Input.C1TextBox TxtCodigoDespacho;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ListBox LstBruto6;
        private System.Windows.Forms.ListBox LstBruto5;
        private System.Windows.Forms.ListBox LstBruto4;
        private System.Windows.Forms.ListBox LstBruto3;
        private System.Windows.Forms.ListBox LstBruto2;
        private System.Windows.Forms.ListBox LstBruto1;
        private System.Windows.Forms.ListBox LstTara4;
        private System.Windows.Forms.ListBox LstTara3;
        private System.Windows.Forms.ListBox LstTara2;
        private System.Windows.Forms.ToolStripButton BtnAnular;
        private System.Windows.Forms.ToolStripLabel LblEstado;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private C1.Win.C1Input.C1TextBox TxtNombreChofer;
        private System.Windows.Forms.Label label15;
        private C1.Win.C1Input.C1TextBox TxtEmpresaTransporte;
        private System.Windows.Forms.Label label18;
        private C1.Win.C1Input.C1TextBox TxtRUCTransporte;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label29;
        private C1.Win.C1Input.C1TextBox TxtFecha;
        private System.Windows.Forms.Label label58;
        private C1.Win.C1Input.C1TextBox TxtPesoTotal;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape10;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape9;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape8;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape7;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape3;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape12;


    }
}