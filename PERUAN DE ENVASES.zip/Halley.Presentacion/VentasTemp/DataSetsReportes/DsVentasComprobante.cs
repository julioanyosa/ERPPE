﻿namespace Halley.Presentacion.VentasTemp.DataSetsReportes
{
    
    
    public partial class DsVentasComprobante {
        partial class usp_GetDetalleVentasComprobanteDataTable
        {
        }
    }
}

