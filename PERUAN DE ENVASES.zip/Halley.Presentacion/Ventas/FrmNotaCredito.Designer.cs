﻿namespace Halley.Presentacion.Ventas
{
    partial class FrmNotaCredito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmNotaCredito));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblCliente = new System.Windows.Forms.Label();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblDocumento = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtConcepto = new C1.Win.C1Input.C1TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.c1cboCia = new C1.Win.C1List.C1Combo();
            this.label9 = new System.Windows.Forms.Label();
            this.cbComprobante = new C1.Win.C1List.C1Combo();
            this.label27 = new System.Windows.Forms.Label();
            this.BtnBuscar = new C1.Win.C1Input.C1Button();
            this.label10 = new System.Windows.Forms.Label();
            this.TxtNumComprobante = new C1.Win.C1Input.C1TextBox();
            this.TxtPorPagar = new C1.Win.C1Input.C1TextBox();
            this.TxtTotalPagado = new C1.Win.C1Input.C1TextBox();
            this.TxtDeudaTotal = new C1.Win.C1Input.C1TextBox();
            this.TdgDetalleComprobante = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
            this.txtCliente = new C1.Win.C1Input.C1TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LblRUC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LblEmpresa = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnRegistrar = new C1.Win.C1Input.C1Button();
            this.label12 = new System.Windows.Forms.Label();
            this.LblAudCrea = new System.Windows.Forms.Label();
            this.LblVendedor = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LblTipoDocumento = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConcepto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1cboCia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbComprobante)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumComprobante)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPorPagar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTotalPagado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDeudaTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TdgDetalleComprobante)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCliente)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.LblTipoDocumento);
            this.groupBox2.Controls.Add(this.LblVendedor);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.LblAudCrea);
            this.groupBox2.Controls.Add(this.lblCliente);
            this.groupBox2.Controls.Add(this.lblDireccion);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.lblDocumento);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Location = new System.Drawing.Point(12, 104);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(855, 100);
            this.groupBox2.TabIndex = 413;
            this.groupBox2.TabStop = false;
            // 
            // lblCliente
            // 
            this.lblCliente.BackColor = System.Drawing.Color.White;
            this.lblCliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCliente.Location = new System.Drawing.Point(90, 16);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(341, 21);
            this.lblCliente.TabIndex = 122;
            this.lblCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDireccion
            // 
            this.lblDireccion.BackColor = System.Drawing.Color.White;
            this.lblDireccion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDireccion.Location = new System.Drawing.Point(90, 69);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(341, 21);
            this.lblDireccion.TabIndex = 129;
            this.lblDireccion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 121;
            this.label1.Text = "Cliente :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(49, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 13);
            this.label11.TabIndex = 123;
            this.label11.Text = "Nro :";
            // 
            // lblDocumento
            // 
            this.lblDocumento.BackColor = System.Drawing.Color.White;
            this.lblDocumento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDocumento.Location = new System.Drawing.Point(90, 42);
            this.lblDocumento.Name = "lblDocumento";
            this.lblDocumento.Size = new System.Drawing.Size(181, 21);
            this.lblDocumento.TabIndex = 124;
            this.lblDocumento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(20, 73);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 13);
            this.label13.TabIndex = 125;
            this.label13.Text = "Dirección :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 20);
            this.label7.TabIndex = 416;
            this.label7.Text = "Nota de Crédito";
            // 
            // TxtConcepto
            // 
            this.TxtConcepto.Location = new System.Drawing.Point(568, 208);
            this.TxtConcepto.Multiline = true;
            this.TxtConcepto.Name = "TxtConcepto";
            this.TxtConcepto.Size = new System.Drawing.Size(290, 56);
            this.TxtConcepto.TabIndex = 417;
            this.TxtConcepto.Tag = null;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(482, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 26);
            this.label8.TabIndex = 418;
            this.label8.Text = "Concepto de\r\ndevolución:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // c1cboCia
            // 
            this.c1cboCia.AddItemSeparator = ';';
            this.c1cboCia.AutoCompletion = true;
            this.c1cboCia.AutoDropDown = true;
            this.c1cboCia.Caption = "";
            this.c1cboCia.CaptionHeight = 17;
            this.c1cboCia.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.c1cboCia.ColumnCaptionHeight = 17;
            this.c1cboCia.ColumnFooterHeight = 17;
            this.c1cboCia.ColumnHeaders = false;
            this.c1cboCia.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.c1cboCia.ContentHeight = 17;
            this.c1cboCia.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.c1cboCia.DisplayMember = "NomEmpresa";
            this.c1cboCia.EditorBackColor = System.Drawing.SystemColors.Window;
            this.c1cboCia.EditorFont = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1cboCia.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.c1cboCia.EditorHeight = 17;
            this.c1cboCia.Images.Add(((System.Drawing.Image)(resources.GetObject("c1cboCia.Images"))));
            this.c1cboCia.ItemHeight = 15;
            this.c1cboCia.Location = new System.Drawing.Point(102, 36);
            this.c1cboCia.MatchEntryTimeout = ((long)(2000));
            this.c1cboCia.MaxDropDownItems = ((short)(10));
            this.c1cboCia.MaxLength = 32767;
            this.c1cboCia.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.c1cboCia.Name = "c1cboCia";
            this.c1cboCia.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.c1cboCia.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.c1cboCia.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.c1cboCia.Size = new System.Drawing.Size(208, 23);
            this.c1cboCia.TabIndex = 424;
            this.c1cboCia.ValueMember = "EmpresaID";
            this.c1cboCia.PropBag = resources.GetString("c1cboCia.PropBag");
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 425;
            this.label9.Text = "Empresa:";
            // 
            // cbComprobante
            // 
            this.cbComprobante.AddItemSeparator = ';';
            this.cbComprobante.Caption = "";
            this.cbComprobante.CaptionHeight = 17;
            this.cbComprobante.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.cbComprobante.ColumnCaptionHeight = 17;
            this.cbComprobante.ColumnFooterHeight = 17;
            this.cbComprobante.ColumnHeaders = false;
            this.cbComprobante.ColumnWidth = 100;
            this.cbComprobante.ComboStyle = C1.Win.C1List.ComboStyleEnum.DropdownList;
            this.cbComprobante.ContentHeight = 17;
            this.cbComprobante.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.cbComprobante.EditorBackColor = System.Drawing.SystemColors.Window;
            this.cbComprobante.EditorFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbComprobante.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.cbComprobante.EditorHeight = 17;
            this.cbComprobante.ExtendRightColumn = true;
            this.cbComprobante.Images.Add(((System.Drawing.Image)(resources.GetObject("cbComprobante.Images"))));
            this.cbComprobante.ItemHeight = 15;
            this.cbComprobante.Location = new System.Drawing.Point(102, 83);
            this.cbComprobante.MatchEntryTimeout = ((long)(2000));
            this.cbComprobante.MaxDropDownItems = ((short)(5));
            this.cbComprobante.MaxLength = 32767;
            this.cbComprobante.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.cbComprobante.Name = "cbComprobante";
            this.cbComprobante.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.cbComprobante.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.cbComprobante.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.cbComprobante.Size = new System.Drawing.Size(208, 23);
            this.cbComprobante.TabIndex = 422;
            this.cbComprobante.VisualStyle = C1.Win.C1List.VisualStyle.Office2007Blue;
            this.cbComprobante.PropBag = resources.GetString("cbComprobante.PropBag");
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(14, 88);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(84, 13);
            this.label27.TabIndex = 423;
            this.label27.Text = "Comprobante :";
            // 
            // BtnBuscar
            // 
            this.BtnBuscar.Image = global::Halley.Presentacion.Properties.Resources.Consultar_16x16;
            this.BtnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBuscar.Location = new System.Drawing.Point(316, 83);
            this.BtnBuscar.Name = "BtnBuscar";
            this.BtnBuscar.Size = new System.Drawing.Size(62, 23);
            this.BtnBuscar.TabIndex = 421;
            this.BtnBuscar.Text = "Buscar";
            this.BtnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnBuscar.UseVisualStyleBackColor = true;
            this.BtnBuscar.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 13);
            this.label10.TabIndex = 420;
            this.label10.Text = "Documento :";
            // 
            // TxtNumComprobante
            // 
            this.TxtNumComprobante.BackColor = System.Drawing.Color.White;
            this.TxtNumComprobante.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNumComprobante.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtNumComprobante.Location = new System.Drawing.Point(102, 61);
            this.TxtNumComprobante.MaxLength = 150;
            this.TxtNumComprobante.Name = "TxtNumComprobante";
            this.TxtNumComprobante.Size = new System.Drawing.Size(208, 20);
            this.TxtNumComprobante.TabIndex = 419;
            this.TxtNumComprobante.Tag = null;
            this.TxtNumComprobante.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNumComprobante.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtPorPagar
            // 
            this.TxtPorPagar.Location = new System.Drawing.Point(163, 78);
            this.TxtPorPagar.Name = "TxtPorPagar";
            this.TxtPorPagar.Size = new System.Drawing.Size(107, 20);
            this.TxtPorPagar.TabIndex = 399;
            this.TxtPorPagar.Tag = null;
            this.TxtPorPagar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtTotalPagado
            // 
            this.TxtTotalPagado.Location = new System.Drawing.Point(163, 46);
            this.TxtTotalPagado.Name = "TxtTotalPagado";
            this.TxtTotalPagado.Size = new System.Drawing.Size(107, 20);
            this.TxtTotalPagado.TabIndex = 397;
            this.TxtTotalPagado.Tag = null;
            this.TxtTotalPagado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtDeudaTotal
            // 
            this.TxtDeudaTotal.Location = new System.Drawing.Point(163, 16);
            this.TxtDeudaTotal.Name = "TxtDeudaTotal";
            this.TxtDeudaTotal.Size = new System.Drawing.Size(107, 20);
            this.TxtDeudaTotal.TabIndex = 395;
            this.TxtDeudaTotal.Tag = null;
            this.TxtDeudaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TdgDetalleComprobante
            // 
            this.TdgDetalleComprobante.CaptionHeight = 17;
            this.TdgDetalleComprobante.EmptyRows = true;
            this.TdgDetalleComprobante.GroupByCaption = "Drag a column header here to group by that column";
            this.TdgDetalleComprobante.Images.Add(((System.Drawing.Image)(resources.GetObject("TdgDetalleComprobante.Images"))));
            this.TdgDetalleComprobante.Location = new System.Drawing.Point(17, 303);
            this.TdgDetalleComprobante.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightRow;
            this.TdgDetalleComprobante.Name = "TdgDetalleComprobante";
            this.TdgDetalleComprobante.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.TdgDetalleComprobante.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.TdgDetalleComprobante.PreviewInfo.ZoomFactor = 75D;
            this.TdgDetalleComprobante.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("TdgReservas.PrintInfo.PageSettings")));
            this.TdgDetalleComprobante.RowHeight = 18;
            this.TdgDetalleComprobante.Size = new System.Drawing.Size(847, 217);
            this.TdgDetalleComprobante.TabIndex = 426;
            this.TdgDetalleComprobante.Text = "c1TrueDBGrid1";
            this.TdgDetalleComprobante.PropBag = resources.GetString("TdgDetalleComprobante.PropBag");
            // 
            // txtCliente
            // 
            this.txtCliente.BackColor = System.Drawing.Color.White;
            this.txtCliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCliente.Location = new System.Drawing.Point(650, 277);
            this.txtCliente.MaxLength = 150;
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.Size = new System.Drawing.Size(118, 20);
            this.txtCliente.TabIndex = 427;
            this.txtCliente.Tag = null;
            this.txtCliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCliente.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(518, 279);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 13);
            this.label2.TabIndex = 428;
            this.label2.Text = "Importe de devolución:";
            // 
            // LblRUC
            // 
            this.LblRUC.BackColor = System.Drawing.Color.White;
            this.LblRUC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblRUC.Location = new System.Drawing.Point(102, 239);
            this.LblRUC.Name = "LblRUC";
            this.LblRUC.Size = new System.Drawing.Size(110, 21);
            this.LblRUC.TabIndex = 432;
            this.LblRUC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 431;
            this.label3.Text = "RUC:";
            // 
            // LblEmpresa
            // 
            this.LblEmpresa.BackColor = System.Drawing.Color.White;
            this.LblEmpresa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblEmpresa.Location = new System.Drawing.Point(102, 207);
            this.LblEmpresa.Name = "LblEmpresa";
            this.LblEmpresa.Size = new System.Drawing.Size(341, 21);
            this.LblEmpresa.TabIndex = 430;
            this.LblEmpresa.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 429;
            this.label5.Text = "Empresa :";
            // 
            // BtnRegistrar
            // 
            this.BtnRegistrar.Image = global::Halley.Presentacion.Properties.Resources.save_16x16;
            this.BtnRegistrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnRegistrar.Location = new System.Drawing.Point(774, 274);
            this.BtnRegistrar.Name = "BtnRegistrar";
            this.BtnRegistrar.Size = new System.Drawing.Size(84, 23);
            this.BtnRegistrar.TabIndex = 433;
            this.BtnRegistrar.Text = "&Registrar";
            this.BtnRegistrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnRegistrar.UseVisualStyleBackColor = true;
            this.BtnRegistrar.Click += new System.EventHandler(this.BtnRegistrar_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(444, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 13);
            this.label12.TabIndex = 416;
            this.label12.Text = "Fecha de emisión:";
            // 
            // LblAudCrea
            // 
            this.LblAudCrea.BackColor = System.Drawing.Color.White;
            this.LblAudCrea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblAudCrea.Location = new System.Drawing.Point(559, 15);
            this.LblAudCrea.Name = "LblAudCrea";
            this.LblAudCrea.Size = new System.Drawing.Size(110, 21);
            this.LblAudCrea.TabIndex = 417;
            this.LblAudCrea.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblVendedor
            // 
            this.LblVendedor.BackColor = System.Drawing.Color.White;
            this.LblVendedor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblVendedor.Location = new System.Drawing.Point(559, 44);
            this.LblVendedor.Name = "LblVendedor";
            this.LblVendedor.Size = new System.Drawing.Size(287, 21);
            this.LblVendedor.TabIndex = 419;
            this.LblVendedor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(482, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 418;
            this.label6.Text = "Vendedor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(449, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 420;
            this.label4.Text = "Tipo documento:";
            // 
            // LblTipoDocumento
            // 
            this.LblTipoDocumento.BackColor = System.Drawing.Color.White;
            this.LblTipoDocumento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblTipoDocumento.Location = new System.Drawing.Point(559, 73);
            this.LblTipoDocumento.Name = "LblTipoDocumento";
            this.LblTipoDocumento.Size = new System.Drawing.Size(110, 21);
            this.LblTipoDocumento.TabIndex = 421;
            this.LblTipoDocumento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FrmNotaCredito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 532);
            this.Controls.Add(this.BtnRegistrar);
            this.Controls.Add(this.LblRUC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LblEmpresa);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCliente);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TdgDetalleComprobante);
            this.Controls.Add(this.c1cboCia);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cbComprobante);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.BtnBuscar);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.TxtNumComprobante);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TxtConcepto);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FrmNotaCredito";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Nota de crédito";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TxtConcepto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1cboCia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbComprobante)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNumComprobante)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPorPagar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTotalPagado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDeudaTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TdgDetalleComprobante)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblDocumento;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private C1.Win.C1Input.C1TextBox TxtConcepto;
        private System.Windows.Forms.Label label8;
        private C1.Win.C1List.C1Combo c1cboCia;
        private System.Windows.Forms.Label label9;
        private C1.Win.C1List.C1Combo cbComprobante;
        private System.Windows.Forms.Label label27;
        private C1.Win.C1Input.C1Button BtnBuscar;
        private System.Windows.Forms.Label label10;
        private C1.Win.C1Input.C1TextBox TxtNumComprobante;
        private C1.Win.C1Input.C1TextBox TxtPorPagar;
        private C1.Win.C1Input.C1TextBox TxtTotalPagado;
        private C1.Win.C1Input.C1TextBox TxtDeudaTotal;
        private C1.Win.C1TrueDBGrid.C1TrueDBGrid TdgDetalleComprobante;
        private C1.Win.C1Input.C1TextBox txtCliente;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LblRUC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LblEmpresa;
        private System.Windows.Forms.Label label5;
        private C1.Win.C1Input.C1Button BtnRegistrar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label LblAudCrea;
        private System.Windows.Forms.Label LblVendedor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label LblTipoDocumento;
    }
}