﻿namespace Halley.Presentacion.Mantenimiento
{
    partial class FrmCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCliente));
            this.TxtDireccionNumero = new C1.Win.C1Input.C1TextBox();
            this.TxtAlias = new C1.Win.C1Input.C1TextBox();
            this.TxtObservacion = new C1.Win.C1Input.C1TextBox();
            this.TxtApellido1 = new C1.Win.C1Input.C1TextBox();
            this.TxtNombre2 = new C1.Win.C1Input.C1TextBox();
            this.TxtDireccionInterior = new C1.Win.C1Input.C1TextBox();
            this.TxtDireccion = new C1.Win.C1Input.C1TextBox();
            this.TxtApellido2 = new C1.Win.C1Input.C1TextBox();
            this.TxtNombre1 = new C1.Win.C1Input.C1TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.LblDireccion = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.TxtRazonSocial = new C1.Win.C1Input.C1TextBox();
            this.BtnNuevo = new C1.Win.C1Input.C1Button();
            this.BtnGuardar = new C1.Win.C1Input.C1Button();
            this.BtnCancelar = new C1.Win.C1Input.C1Button();
            this.TxtNroDocumento = new C1.Win.C1Input.C1TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtEmail = new C1.Win.C1Input.C1TextBox();
            this.TxtFax = new C1.Win.C1Input.C1TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtTelefonoMovil = new C1.Win.C1Input.C1TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtTelefonoFijo = new C1.Win.C1Input.C1TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtContacto = new C1.Win.C1Input.C1TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.CboPais = new C1.Win.C1List.C1Combo();
            this.TxtNombreVia = new C1.Win.C1Input.C1TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CboVia = new C1.Win.C1List.C1Combo();
            this.CboDistrito = new C1.Win.C1List.C1Combo();
            this.CboProvincia = new C1.Win.C1List.C1Combo();
            this.CboDepartamento = new C1.Win.C1List.C1Combo();
            this.ErrProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.CboTipoCliente = new C1.Win.C1List.C1Combo();
            this.label7 = new System.Windows.Forms.Label();
            this.CboTipoDocumento = new C1.Win.C1List.C1Combo();
            this.label8 = new System.Windows.Forms.Label();
            this.BtnEditar = new C1.Win.C1Input.C1Button();
            this.BtnEliminar = new C1.Win.C1Input.C1Button();
            this.btnBuscar = new C1.Win.C1Input.C1Button();
            this.label9 = new System.Windows.Forms.Label();
            this.TxtDocumento2 = new C1.Win.C1Input.C1TextBox();
            this.lblEstado = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.TxtClienteID = new C1.Win.C1Input.C1TextBox();
            this.lbltc = new System.Windows.Forms.Label();
            this.lbltd = new System.Windows.Forms.Label();
            this.lblnd = new System.Windows.Forms.Label();
            this.lblrz = new System.Windows.Forms.Label();
            this.lbln = new System.Windows.Forms.Label();
            this.lbla = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionNumero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAlias)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtObservacion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtApellido1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombre2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionInterior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtApellido2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombre1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRazonSocial)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDocumento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTelefonoMovil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTelefonoFijo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtContacto)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CboPais)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreVia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboVia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboDistrito)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboProvincia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboDepartamento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboTipoCliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboTipoDocumento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDocumento2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtClienteID)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtDireccionNumero
            // 
            this.TxtDireccionNumero.BackColor = System.Drawing.Color.White;
            this.TxtDireccionNumero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDireccionNumero.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtDireccionNumero.Location = new System.Drawing.Point(111, 188);
            this.TxtDireccionNumero.MaxLength = 50;
            this.TxtDireccionNumero.Name = "TxtDireccionNumero";
            this.TxtDireccionNumero.ReadOnly = true;
            this.TxtDireccionNumero.Size = new System.Drawing.Size(118, 18);
            this.TxtDireccionNumero.TabIndex = 6;
            this.TxtDireccionNumero.Tag = null;
            this.TxtDireccionNumero.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDireccionNumero.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtAlias
            // 
            this.TxtAlias.BackColor = System.Drawing.Color.White;
            this.TxtAlias.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtAlias.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtAlias.Location = new System.Drawing.Point(144, 94);
            this.TxtAlias.MaxLength = 100;
            this.TxtAlias.Name = "TxtAlias";
            this.TxtAlias.ReadOnly = true;
            this.TxtAlias.Size = new System.Drawing.Size(269, 18);
            this.TxtAlias.TabIndex = 2;
            this.TxtAlias.Tag = null;
            this.TxtAlias.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtAlias.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtObservacion
            // 
            this.TxtObservacion.BackColor = System.Drawing.Color.White;
            this.TxtObservacion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtObservacion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtObservacion.Location = new System.Drawing.Point(537, 358);
            this.TxtObservacion.MaxLength = 250;
            this.TxtObservacion.Multiline = true;
            this.TxtObservacion.Name = "TxtObservacion";
            this.TxtObservacion.ReadOnly = true;
            this.TxtObservacion.Size = new System.Drawing.Size(297, 35);
            this.TxtObservacion.TabIndex = 14;
            this.TxtObservacion.Tag = null;
            this.TxtObservacion.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtObservacion.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtApellido1
            // 
            this.TxtApellido1.BackColor = System.Drawing.Color.White;
            this.TxtApellido1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtApellido1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtApellido1.Location = new System.Drawing.Point(144, 227);
            this.TxtApellido1.MaxLength = 50;
            this.TxtApellido1.Name = "TxtApellido1";
            this.TxtApellido1.ReadOnly = true;
            this.TxtApellido1.Size = new System.Drawing.Size(196, 18);
            this.TxtApellido1.TabIndex = 7;
            this.TxtApellido1.Tag = null;
            this.TxtApellido1.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtApellido1.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNombre2
            // 
            this.TxtNombre2.BackColor = System.Drawing.Color.White;
            this.TxtNombre2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNombre2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtNombre2.Location = new System.Drawing.Point(144, 201);
            this.TxtNombre2.MaxLength = 50;
            this.TxtNombre2.Name = "TxtNombre2";
            this.TxtNombre2.ReadOnly = true;
            this.TxtNombre2.Size = new System.Drawing.Size(196, 18);
            this.TxtNombre2.TabIndex = 6;
            this.TxtNombre2.Tag = null;
            this.TxtNombre2.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNombre2.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDireccionInterior
            // 
            this.TxtDireccionInterior.BackColor = System.Drawing.Color.White;
            this.TxtDireccionInterior.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDireccionInterior.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtDireccionInterior.Location = new System.Drawing.Point(111, 214);
            this.TxtDireccionInterior.MaxLength = 50;
            this.TxtDireccionInterior.Name = "TxtDireccionInterior";
            this.TxtDireccionInterior.ReadOnly = true;
            this.TxtDireccionInterior.Size = new System.Drawing.Size(118, 18);
            this.TxtDireccionInterior.TabIndex = 7;
            this.TxtDireccionInterior.Tag = null;
            this.TxtDireccionInterior.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDireccionInterior.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtDireccion
            // 
            this.TxtDireccion.BackColor = System.Drawing.Color.White;
            this.TxtDireccion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtDireccion.Location = new System.Drawing.Point(111, 236);
            this.TxtDireccion.MaxLength = 300;
            this.TxtDireccion.Multiline = true;
            this.TxtDireccion.Name = "TxtDireccion";
            this.TxtDireccion.ReadOnly = true;
            this.TxtDireccion.Size = new System.Drawing.Size(252, 49);
            this.TxtDireccion.TabIndex = 5;
            this.TxtDireccion.Tag = null;
            this.TxtDireccion.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDireccion.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtApellido2
            // 
            this.TxtApellido2.BackColor = System.Drawing.Color.White;
            this.TxtApellido2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtApellido2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtApellido2.Location = new System.Drawing.Point(144, 253);
            this.TxtApellido2.MaxLength = 50;
            this.TxtApellido2.Name = "TxtApellido2";
            this.TxtApellido2.ReadOnly = true;
            this.TxtApellido2.Size = new System.Drawing.Size(196, 18);
            this.TxtApellido2.TabIndex = 8;
            this.TxtApellido2.Tag = null;
            this.TxtApellido2.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtApellido2.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtNombre1
            // 
            this.TxtNombre1.BackColor = System.Drawing.Color.White;
            this.TxtNombre1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNombre1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtNombre1.Location = new System.Drawing.Point(144, 175);
            this.TxtNombre1.MaxLength = 50;
            this.TxtNombre1.Name = "TxtNombre1";
            this.TxtNombre1.ReadOnly = true;
            this.TxtNombre1.Size = new System.Drawing.Size(196, 18);
            this.TxtNombre1.TabIndex = 5;
            this.TxtNombre1.Tag = null;
            this.TxtNombre1.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNombre1.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(106, 99);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 13);
            this.label24.TabIndex = 287;
            this.label24.Text = "Alias:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(461, 360);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 13);
            this.label23.TabIndex = 286;
            this.label23.Text = "Observación:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(54, 229);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 13);
            this.label22.TabIndex = 285;
            this.label22.Text = "Apellido Paterno";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(82, 201);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 13);
            this.label21.TabIndex = 284;
            this.label21.Text = "Nombre 2:";
            // 
            // LblDireccion
            // 
            this.LblDireccion.AutoSize = true;
            this.LblDireccion.Location = new System.Drawing.Point(50, 239);
            this.LblDireccion.Name = "LblDireccion";
            this.LblDireccion.Size = new System.Drawing.Size(54, 26);
            this.LblDireccion.TabIndex = 283;
            this.LblDireccion.Text = "Dirección\r\nCompleta:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(63, 219);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 13);
            this.label19.TabIndex = 282;
            this.label19.Text = "Interior:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(58, 192);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 13);
            this.label18.TabIndex = 281;
            this.label18.Text = "Número:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(80, 143);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(25, 13);
            this.label17.TabIndex = 280;
            this.label17.Text = "Via:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(49, 255);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 13);
            this.label16.TabIndex = 279;
            this.label16.Text = "Apellido Materno:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(82, 175);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 13);
            this.label15.TabIndex = 278;
            this.label15.Text = "Nombre 1:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(28, 62);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 13);
            this.label14.TabIndex = 277;
            this.label14.Text = "Departamento:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(51, 89);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 276;
            this.label13.Text = "Provincia:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(63, 116);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 13);
            this.label12.TabIndex = 275;
            this.label12.Text = "Distrito:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(50, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 26);
            this.label11.TabIndex = 274;
            this.label11.Text = "Nombre Cliente o\r\nRazon Social:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(38, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 13);
            this.label10.TabIndex = 273;
            this.label10.Text = "Nro de Documento:";
            // 
            // TxtRazonSocial
            // 
            this.TxtRazonSocial.BackColor = System.Drawing.Color.White;
            this.TxtRazonSocial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtRazonSocial.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtRazonSocial.Location = new System.Drawing.Point(144, 68);
            this.TxtRazonSocial.MaxLength = 200;
            this.TxtRazonSocial.Name = "TxtRazonSocial";
            this.TxtRazonSocial.ReadOnly = true;
            this.TxtRazonSocial.Size = new System.Drawing.Size(269, 18);
            this.TxtRazonSocial.TabIndex = 1;
            this.TxtRazonSocial.Tag = null;
            this.TxtRazonSocial.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtRazonSocial.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // BtnNuevo
            // 
            this.BtnNuevo.Image = global::Halley.Presentacion.Properties.Resources.newdocument_16x16;
            this.BtnNuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnNuevo.Location = new System.Drawing.Point(859, 87);
            this.BtnNuevo.Name = "BtnNuevo";
            this.BtnNuevo.Size = new System.Drawing.Size(82, 23);
            this.BtnNuevo.TabIndex = 15;
            this.BtnNuevo.Text = "Nuevo";
            this.BtnNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnNuevo.UseVisualStyleBackColor = true;
            this.BtnNuevo.Click += new System.EventHandler(this.BtnNuevo_Click);
            // 
            // BtnGuardar
            // 
            this.BtnGuardar.Image = global::Halley.Presentacion.Properties.Resources.save_16x16;
            this.BtnGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnGuardar.Location = new System.Drawing.Point(859, 180);
            this.BtnGuardar.Name = "BtnGuardar";
            this.BtnGuardar.Size = new System.Drawing.Size(82, 23);
            this.BtnGuardar.TabIndex = 18;
            this.BtnGuardar.Text = "Guardar";
            this.BtnGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnGuardar.UseVisualStyleBackColor = true;
            this.BtnGuardar.Click += new System.EventHandler(this.BtnGuardar_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Image = global::Halley.Presentacion.Properties.Resources.cancel_16x16;
            this.BtnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCancelar.Location = new System.Drawing.Point(859, 118);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(82, 23);
            this.BtnCancelar.TabIndex = 16;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // TxtNroDocumento
            // 
            this.TxtNroDocumento.BackColor = System.Drawing.Color.White;
            this.TxtNroDocumento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNroDocumento.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtNroDocumento.Location = new System.Drawing.Point(144, 149);
            this.TxtNroDocumento.MaxLength = 50;
            this.TxtNroDocumento.Name = "TxtNroDocumento";
            this.TxtNroDocumento.ReadOnly = true;
            this.TxtNroDocumento.Size = new System.Drawing.Size(134, 18);
            this.TxtNroDocumento.TabIndex = 4;
            this.TxtNroDocumento.Tag = null;
            this.TxtNroDocumento.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNroDocumento.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            this.TxtNroDocumento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtNroDocumento_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(103, 385);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 297;
            this.label5.Text = "Email:";
            // 
            // TxtEmail
            // 
            this.TxtEmail.BackColor = System.Drawing.Color.White;
            this.TxtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtEmail.Location = new System.Drawing.Point(144, 383);
            this.TxtEmail.MaxLength = 50;
            this.TxtEmail.Name = "TxtEmail";
            this.TxtEmail.ReadOnly = true;
            this.TxtEmail.Size = new System.Drawing.Size(269, 18);
            this.TxtEmail.TabIndex = 13;
            this.TxtEmail.Tag = null;
            this.TxtEmail.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtEmail.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // TxtFax
            // 
            this.TxtFax.BackColor = System.Drawing.Color.White;
            this.TxtFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtFax.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtFax.Location = new System.Drawing.Point(144, 357);
            this.TxtFax.MaxLength = 50;
            this.TxtFax.Name = "TxtFax";
            this.TxtFax.ReadOnly = true;
            this.TxtFax.Size = new System.Drawing.Size(161, 18);
            this.TxtFax.TabIndex = 12;
            this.TxtFax.Tag = null;
            this.TxtFax.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtFax.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(111, 362);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 295;
            this.label4.Text = "Fax:";
            // 
            // TxtTelefonoMovil
            // 
            this.TxtTelefonoMovil.BackColor = System.Drawing.Color.White;
            this.TxtTelefonoMovil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtTelefonoMovil.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtTelefonoMovil.Location = new System.Drawing.Point(144, 331);
            this.TxtTelefonoMovil.MaxLength = 20;
            this.TxtTelefonoMovil.Name = "TxtTelefonoMovil";
            this.TxtTelefonoMovil.ReadOnly = true;
            this.TxtTelefonoMovil.Size = new System.Drawing.Size(161, 18);
            this.TxtTelefonoMovil.TabIndex = 11;
            this.TxtTelefonoMovil.Tag = null;
            this.TxtTelefonoMovil.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtTelefonoMovil.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 333);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 293;
            this.label3.Text = "Teléfono Movil:";
            // 
            // TxtTelefonoFijo
            // 
            this.TxtTelefonoFijo.BackColor = System.Drawing.Color.White;
            this.TxtTelefonoFijo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtTelefonoFijo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtTelefonoFijo.Location = new System.Drawing.Point(144, 305);
            this.TxtTelefonoFijo.MaxLength = 20;
            this.TxtTelefonoFijo.Name = "TxtTelefonoFijo";
            this.TxtTelefonoFijo.ReadOnly = true;
            this.TxtTelefonoFijo.Size = new System.Drawing.Size(161, 18);
            this.TxtTelefonoFijo.TabIndex = 10;
            this.TxtTelefonoFijo.Tag = null;
            this.TxtTelefonoFijo.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtTelefonoFijo.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 310);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 291;
            this.label2.Text = "Teléfono fijo:";
            // 
            // TxtContacto
            // 
            this.TxtContacto.BackColor = System.Drawing.Color.White;
            this.TxtContacto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtContacto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtContacto.Location = new System.Drawing.Point(144, 279);
            this.TxtContacto.MaxLength = 150;
            this.TxtContacto.Name = "TxtContacto";
            this.TxtContacto.ReadOnly = true;
            this.TxtContacto.Size = new System.Drawing.Size(269, 18);
            this.TxtContacto.TabIndex = 9;
            this.TxtContacto.Tag = null;
            this.TxtContacto.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtContacto.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 286);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 289;
            this.label1.Text = "Nombre Contacto:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.CboPais);
            this.groupBox3.Controls.Add(this.TxtNombreVia);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.CboVia);
            this.groupBox3.Controls.Add(this.CboDistrito);
            this.groupBox3.Controls.Add(this.CboProvincia);
            this.groupBox3.Controls.Add(this.CboDepartamento);
            this.groupBox3.Controls.Add(this.TxtDireccionNumero);
            this.groupBox3.Controls.Add(this.TxtDireccionInterior);
            this.groupBox3.Controls.Add(this.TxtDireccion);
            this.groupBox3.Controls.Add(this.LblDireccion);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Location = new System.Drawing.Point(471, 52);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(370, 294);
            this.groupBox3.TabIndex = 304;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ubicación";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(24, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(80, 13);
            this.label20.TabIndex = 320;
            this.label20.Text = "Nombre de Via:";
            // 
            // CboPais
            // 
            this.CboPais.AddItemSeparator = ';';
            this.CboPais.Caption = "";
            this.CboPais.CaptionHeight = 17;
            this.CboPais.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboPais.ColumnCaptionHeight = 17;
            this.CboPais.ColumnFooterHeight = 17;
            this.CboPais.ContentHeight = 15;
            this.CboPais.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboPais.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboPais.EditorFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboPais.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboPais.EditorHeight = 15;
            this.CboPais.Images.Add(((System.Drawing.Image)(resources.GetObject("CboPais.Images"))));
            this.CboPais.ItemHeight = 15;
            this.CboPais.Location = new System.Drawing.Point(111, 19);
            this.CboPais.MatchEntryTimeout = ((long)(2000));
            this.CboPais.MaxDropDownItems = ((short)(5));
            this.CboPais.MaxLength = 32767;
            this.CboPais.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboPais.Name = "CboPais";
            this.CboPais.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboPais.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboPais.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboPais.Size = new System.Drawing.Size(204, 21);
            this.CboPais.TabIndex = 0;
            this.CboPais.PropBag = resources.GetString("CboPais.PropBag");
            // 
            // TxtNombreVia
            // 
            this.TxtNombreVia.BackColor = System.Drawing.Color.White;
            this.TxtNombreVia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtNombreVia.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtNombreVia.Location = new System.Drawing.Point(111, 164);
            this.TxtNombreVia.MaxLength = 50;
            this.TxtNombreVia.Name = "TxtNombreVia";
            this.TxtNombreVia.ReadOnly = true;
            this.TxtNombreVia.Size = new System.Drawing.Size(252, 18);
            this.TxtNombreVia.TabIndex = 319;
            this.TxtNombreVia.Tag = null;
            this.TxtNombreVia.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtNombreVia.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(73, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 291;
            this.label6.Text = "País:";
            // 
            // CboVia
            // 
            this.CboVia.AddItemSeparator = ';';
            this.CboVia.Caption = "";
            this.CboVia.CaptionHeight = 17;
            this.CboVia.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboVia.ColumnCaptionHeight = 17;
            this.CboVia.ColumnFooterHeight = 17;
            this.CboVia.ContentHeight = 15;
            this.CboVia.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboVia.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboVia.EditorFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboVia.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboVia.EditorHeight = 15;
            this.CboVia.Images.Add(((System.Drawing.Image)(resources.GetObject("CboVia.Images"))));
            this.CboVia.ItemHeight = 15;
            this.CboVia.Location = new System.Drawing.Point(111, 138);
            this.CboVia.MatchEntryTimeout = ((long)(2000));
            this.CboVia.MaxDropDownItems = ((short)(5));
            this.CboVia.MaxLength = 32767;
            this.CboVia.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboVia.Name = "CboVia";
            this.CboVia.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboVia.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboVia.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboVia.Size = new System.Drawing.Size(204, 21);
            this.CboVia.TabIndex = 4;
            this.CboVia.PropBag = resources.GetString("CboVia.PropBag");
            // 
            // CboDistrito
            // 
            this.CboDistrito.AddItemSeparator = ';';
            this.CboDistrito.Caption = "";
            this.CboDistrito.CaptionHeight = 17;
            this.CboDistrito.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboDistrito.ColumnCaptionHeight = 17;
            this.CboDistrito.ColumnFooterHeight = 17;
            this.CboDistrito.ContentHeight = 15;
            this.CboDistrito.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboDistrito.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboDistrito.EditorFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboDistrito.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboDistrito.EditorHeight = 15;
            this.CboDistrito.Images.Add(((System.Drawing.Image)(resources.GetObject("CboDistrito.Images"))));
            this.CboDistrito.ItemHeight = 15;
            this.CboDistrito.Location = new System.Drawing.Point(111, 109);
            this.CboDistrito.MatchEntryTimeout = ((long)(2000));
            this.CboDistrito.MaxDropDownItems = ((short)(5));
            this.CboDistrito.MaxLength = 32767;
            this.CboDistrito.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboDistrito.Name = "CboDistrito";
            this.CboDistrito.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboDistrito.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboDistrito.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboDistrito.Size = new System.Drawing.Size(204, 21);
            this.CboDistrito.TabIndex = 3;
            this.CboDistrito.PropBag = resources.GetString("CboDistrito.PropBag");
            // 
            // CboProvincia
            // 
            this.CboProvincia.AddItemSeparator = ';';
            this.CboProvincia.Caption = "";
            this.CboProvincia.CaptionHeight = 17;
            this.CboProvincia.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboProvincia.ColumnCaptionHeight = 17;
            this.CboProvincia.ColumnFooterHeight = 17;
            this.CboProvincia.ContentHeight = 15;
            this.CboProvincia.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboProvincia.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboProvincia.EditorFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboProvincia.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboProvincia.EditorHeight = 15;
            this.CboProvincia.Images.Add(((System.Drawing.Image)(resources.GetObject("CboProvincia.Images"))));
            this.CboProvincia.ItemHeight = 15;
            this.CboProvincia.Location = new System.Drawing.Point(111, 80);
            this.CboProvincia.MatchEntryTimeout = ((long)(2000));
            this.CboProvincia.MaxDropDownItems = ((short)(5));
            this.CboProvincia.MaxLength = 32767;
            this.CboProvincia.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboProvincia.Name = "CboProvincia";
            this.CboProvincia.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboProvincia.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboProvincia.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboProvincia.Size = new System.Drawing.Size(204, 21);
            this.CboProvincia.TabIndex = 2;
            this.CboProvincia.SelectedValueChanged += new System.EventHandler(this.CboProvincia_SelectedValueChanged);
            this.CboProvincia.PropBag = resources.GetString("CboProvincia.PropBag");
            // 
            // CboDepartamento
            // 
            this.CboDepartamento.AddItemSeparator = ';';
            this.CboDepartamento.Caption = "";
            this.CboDepartamento.CaptionHeight = 17;
            this.CboDepartamento.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboDepartamento.ColumnCaptionHeight = 17;
            this.CboDepartamento.ColumnFooterHeight = 17;
            this.CboDepartamento.ContentHeight = 15;
            this.CboDepartamento.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboDepartamento.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboDepartamento.EditorFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboDepartamento.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboDepartamento.EditorHeight = 15;
            this.CboDepartamento.Images.Add(((System.Drawing.Image)(resources.GetObject("CboDepartamento.Images"))));
            this.CboDepartamento.ItemHeight = 15;
            this.CboDepartamento.Location = new System.Drawing.Point(111, 51);
            this.CboDepartamento.MatchEntryTimeout = ((long)(2000));
            this.CboDepartamento.MaxDropDownItems = ((short)(5));
            this.CboDepartamento.MaxLength = 32767;
            this.CboDepartamento.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboDepartamento.Name = "CboDepartamento";
            this.CboDepartamento.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboDepartamento.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboDepartamento.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboDepartamento.Size = new System.Drawing.Size(204, 21);
            this.CboDepartamento.TabIndex = 1;
            this.CboDepartamento.SelectedValueChanged += new System.EventHandler(this.CboDepartamento_SelectedValueChanged);
            this.CboDepartamento.PropBag = resources.GetString("CboDepartamento.PropBag");
            // 
            // ErrProvider
            // 
            this.ErrProvider.ContainerControl = this;
            this.ErrProvider.Icon = ((System.Drawing.Icon)(resources.GetObject("ErrProvider.Icon")));
            // 
            // CboTipoCliente
            // 
            this.CboTipoCliente.AddItemSeparator = ';';
            this.CboTipoCliente.Caption = "";
            this.CboTipoCliente.CaptionHeight = 17;
            this.CboTipoCliente.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboTipoCliente.ColumnCaptionHeight = 17;
            this.CboTipoCliente.ColumnFooterHeight = 17;
            this.CboTipoCliente.ContentHeight = 15;
            this.CboTipoCliente.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboTipoCliente.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboTipoCliente.EditorFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboTipoCliente.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboTipoCliente.EditorHeight = 15;
            this.CboTipoCliente.Images.Add(((System.Drawing.Image)(resources.GetObject("CboTipoCliente.Images"))));
            this.CboTipoCliente.ItemHeight = 15;
            this.CboTipoCliente.Location = new System.Drawing.Point(144, 39);
            this.CboTipoCliente.MatchEntryTimeout = ((long)(2000));
            this.CboTipoCliente.MaxDropDownItems = ((short)(5));
            this.CboTipoCliente.MaxLength = 32767;
            this.CboTipoCliente.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboTipoCliente.Name = "CboTipoCliente";
            this.CboTipoCliente.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboTipoCliente.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboTipoCliente.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboTipoCliente.Size = new System.Drawing.Size(204, 21);
            this.CboTipoCliente.TabIndex = 0;
            this.CboTipoCliente.SelectedValueChanged += new System.EventHandler(this.CboTipoCliente_SelectedValueChanged);
            this.CboTipoCliente.PropBag = resources.GetString("CboTipoCliente.PropBag");
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(72, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 307;
            this.label7.Text = "Tipo Cliente:";
            // 
            // CboTipoDocumento
            // 
            this.CboTipoDocumento.AddItemSeparator = ';';
            this.CboTipoDocumento.Caption = "";
            this.CboTipoDocumento.CaptionHeight = 17;
            this.CboTipoDocumento.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.CboTipoDocumento.ColumnCaptionHeight = 17;
            this.CboTipoDocumento.ColumnFooterHeight = 17;
            this.CboTipoDocumento.ContentHeight = 15;
            this.CboTipoDocumento.DeadAreaBackColor = System.Drawing.Color.Empty;
            this.CboTipoDocumento.EditorBackColor = System.Drawing.SystemColors.Window;
            this.CboTipoDocumento.EditorFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboTipoDocumento.EditorForeColor = System.Drawing.SystemColors.WindowText;
            this.CboTipoDocumento.EditorHeight = 15;
            this.CboTipoDocumento.Images.Add(((System.Drawing.Image)(resources.GetObject("CboTipoDocumento.Images"))));
            this.CboTipoDocumento.ItemHeight = 15;
            this.CboTipoDocumento.Location = new System.Drawing.Point(144, 120);
            this.CboTipoDocumento.MatchEntryTimeout = ((long)(2000));
            this.CboTipoDocumento.MaxDropDownItems = ((short)(5));
            this.CboTipoDocumento.MaxLength = 32767;
            this.CboTipoDocumento.MouseCursor = System.Windows.Forms.Cursors.Default;
            this.CboTipoDocumento.Name = "CboTipoDocumento";
            this.CboTipoDocumento.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.CboTipoDocumento.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None;
            this.CboTipoDocumento.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.CboTipoDocumento.Size = new System.Drawing.Size(204, 21);
            this.CboTipoDocumento.TabIndex = 3;
            this.CboTipoDocumento.PropBag = resources.GetString("CboTipoDocumento.PropBag");
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(49, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 13);
            this.label8.TabIndex = 309;
            this.label8.Text = "Tipo Documento:";
            // 
            // BtnEditar
            // 
            this.BtnEditar.Image = global::Halley.Presentacion.Properties.Resources.edit_16x16;
            this.BtnEditar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEditar.Location = new System.Drawing.Point(859, 149);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(82, 23);
            this.BtnEditar.TabIndex = 17;
            this.BtnEditar.Text = "Editar";
            this.BtnEditar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnEditar.UseVisualStyleBackColor = true;
            this.BtnEditar.Click += new System.EventHandler(this.BtnEditar_Click);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Image = global::Halley.Presentacion.Properties.Resources.delete_16x16;
            this.BtnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEliminar.Location = new System.Drawing.Point(859, 211);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(82, 23);
            this.BtnEliminar.TabIndex = 19;
            this.BtnEliminar.Text = "Eliminar";
            this.BtnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Image = global::Halley.Presentacion.Properties.Resources.Consultar_16x16;
            this.btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscar.Location = new System.Drawing.Point(858, 21);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(82, 23);
            this.btnBuscar.TabIndex = 311;
            this.btnBuscar.Text = "Consultar";
            this.btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(624, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 13);
            this.label9.TabIndex = 315;
            this.label9.Text = "Ingrese Nro Documento:";
            // 
            // TxtDocumento2
            // 
            this.TxtDocumento2.BackColor = System.Drawing.Color.White;
            this.TxtDocumento2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtDocumento2.Location = new System.Drawing.Point(755, 25);
            this.TxtDocumento2.MaxLength = 50;
            this.TxtDocumento2.Name = "TxtDocumento2";
            this.TxtDocumento2.Size = new System.Drawing.Size(100, 18);
            this.TxtDocumento2.TabIndex = 314;
            this.TxtDocumento2.Tag = null;
            this.TxtDocumento2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtDocumento2.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtDocumento2.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            this.TxtDocumento2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtDocumento2_KeyPress);
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblEstado.Location = new System.Drawing.Point(482, 409);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(11, 13);
            this.lblEstado.TabIndex = 316;
            this.lblEstado.Text = "*";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(117, 15);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(21, 13);
            this.label25.TabIndex = 318;
            this.label25.Text = "ID:";
            // 
            // TxtClienteID
            // 
            this.TxtClienteID.BackColor = System.Drawing.Color.White;
            this.TxtClienteID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtClienteID.Location = new System.Drawing.Point(144, 12);
            this.TxtClienteID.MaxLength = 50;
            this.TxtClienteID.Name = "TxtClienteID";
            this.TxtClienteID.ReadOnly = true;
            this.TxtClienteID.Size = new System.Drawing.Size(70, 18);
            this.TxtClienteID.TabIndex = 317;
            this.TxtClienteID.Tag = null;
            this.TxtClienteID.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle;
            this.TxtClienteID.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue;
            // 
            // lbltc
            // 
            this.lbltc.AutoSize = true;
            this.lbltc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltc.ForeColor = System.Drawing.Color.Blue;
            this.lbltc.Location = new System.Drawing.Point(351, 41);
            this.lbltc.Name = "lbltc";
            this.lbltc.Size = new System.Drawing.Size(14, 17);
            this.lbltc.TabIndex = 319;
            this.lbltc.Text = "*";
            // 
            // lbltd
            // 
            this.lbltd.AutoSize = true;
            this.lbltd.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltd.ForeColor = System.Drawing.Color.Blue;
            this.lbltd.Location = new System.Drawing.Point(351, 124);
            this.lbltd.Name = "lbltd";
            this.lbltd.Size = new System.Drawing.Size(14, 17);
            this.lbltd.TabIndex = 320;
            this.lbltd.Text = "*";
            // 
            // lblnd
            // 
            this.lblnd.AutoSize = true;
            this.lblnd.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnd.ForeColor = System.Drawing.Color.Blue;
            this.lblnd.Location = new System.Drawing.Point(284, 151);
            this.lblnd.Name = "lblnd";
            this.lblnd.Size = new System.Drawing.Size(14, 17);
            this.lblnd.TabIndex = 321;
            this.lblnd.Text = "*";
            // 
            // lblrz
            // 
            this.lblrz.AutoSize = true;
            this.lblrz.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrz.ForeColor = System.Drawing.Color.Blue;
            this.lblrz.Location = new System.Drawing.Point(419, 73);
            this.lblrz.Name = "lblrz";
            this.lblrz.Size = new System.Drawing.Size(14, 17);
            this.lblrz.TabIndex = 322;
            this.lblrz.Text = "*";
            // 
            // lbln
            // 
            this.lbln.AutoSize = true;
            this.lbln.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbln.ForeColor = System.Drawing.Color.Blue;
            this.lbln.Location = new System.Drawing.Point(351, 176);
            this.lbln.Name = "lbln";
            this.lbln.Size = new System.Drawing.Size(14, 17);
            this.lbln.TabIndex = 323;
            this.lbln.Text = "*";
            // 
            // lbla
            // 
            this.lbla.AutoSize = true;
            this.lbla.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbla.ForeColor = System.Drawing.Color.Blue;
            this.lbla.Location = new System.Drawing.Point(351, 229);
            this.lbla.Name = "lbla";
            this.lbla.Size = new System.Drawing.Size(14, 17);
            this.lbla.TabIndex = 324;
            this.lbla.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(27, 425);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(160, 17);
            this.label26.TabIndex = 325;
            this.label26.Text = "(*) Campos obligatorios.";
            // 
            // FrmCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 464);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.lbla);
            this.Controls.Add(this.lbln);
            this.Controls.Add(this.lblrz);
            this.Controls.Add(this.lblnd);
            this.Controls.Add(this.lbltd);
            this.Controls.Add(this.lbltc);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.TxtClienteID);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TxtDocumento2);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.CboTipoDocumento);
            this.Controls.Add(this.TxtEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TxtFax);
            this.Controls.Add(this.CboTipoCliente);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TxtTelefonoMovil);
            this.Controls.Add(this.TxtRazonSocial);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.TxtTelefonoFijo);
            this.Controls.Add(this.TxtNombre2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TxtContacto);
            this.Controls.Add(this.TxtApellido1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.TxtAlias);
            this.Controls.Add(this.BtnNuevo);
            this.Controls.Add(this.TxtObservacion);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.BtnGuardar);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.TxtApellido2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.TxtNroDocumento);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.TxtNombre1);
            this.Controls.Add(this.label22);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FrmCliente";
            this.Text = "Agregar Clientes";
            this.Load += new System.EventHandler(this.FrmCliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionNumero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAlias)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtObservacion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtApellido1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombre2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccionInterior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDireccion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtApellido2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombre1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtRazonSocial)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNroDocumento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTelefonoMovil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTelefonoFijo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtContacto)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CboPais)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtNombreVia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboVia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboDistrito)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboProvincia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboDepartamento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboTipoCliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CboTipoDocumento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtDocumento2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtClienteID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private C1.Win.C1Input.C1TextBox TxtDireccionNumero;
        private C1.Win.C1Input.C1TextBox TxtAlias;
        private C1.Win.C1Input.C1TextBox TxtObservacion;
        private C1.Win.C1Input.C1TextBox TxtApellido1;
        private C1.Win.C1Input.C1TextBox TxtNombre2;
        private C1.Win.C1Input.C1TextBox TxtDireccionInterior;
        private C1.Win.C1Input.C1TextBox TxtDireccion;
        private C1.Win.C1Input.C1TextBox TxtApellido2;
        private C1.Win.C1Input.C1TextBox TxtNombre1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label LblDireccion;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private C1.Win.C1Input.C1TextBox TxtRazonSocial;
        private C1.Win.C1Input.C1Button BtnNuevo;
        private C1.Win.C1Input.C1Button BtnGuardar;
        private C1.Win.C1Input.C1Button BtnCancelar;
        private C1.Win.C1Input.C1TextBox TxtNroDocumento;
        private System.Windows.Forms.GroupBox groupBox3;
        private C1.Win.C1List.C1Combo CboVia;
        private C1.Win.C1List.C1Combo CboDistrito;
        private C1.Win.C1List.C1Combo CboProvincia;
        private C1.Win.C1List.C1Combo CboDepartamento;
        private System.Windows.Forms.ErrorProvider ErrProvider;
        private System.Windows.Forms.Label label5;
        private C1.Win.C1Input.C1TextBox TxtEmail;
        private C1.Win.C1Input.C1TextBox TxtFax;
        private System.Windows.Forms.Label label4;
        private C1.Win.C1Input.C1TextBox TxtTelefonoMovil;
        private System.Windows.Forms.Label label3;
        private C1.Win.C1Input.C1TextBox TxtTelefonoFijo;
        private System.Windows.Forms.Label label2;
        private C1.Win.C1Input.C1TextBox TxtContacto;
        private System.Windows.Forms.Label label1;
        private C1.Win.C1List.C1Combo CboPais;
        private System.Windows.Forms.Label label6;
        private C1.Win.C1List.C1Combo CboTipoDocumento;
        private System.Windows.Forms.Label label8;
        private C1.Win.C1List.C1Combo CboTipoCliente;
        private System.Windows.Forms.Label label7;
        private C1.Win.C1Input.C1Button BtnEditar;
        private C1.Win.C1Input.C1Button BtnEliminar;
        private C1.Win.C1Input.C1Button btnBuscar;
        private System.Windows.Forms.Label label9;
        private C1.Win.C1Input.C1TextBox TxtDocumento2;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Label label25;
        private C1.Win.C1Input.C1TextBox TxtClienteID;
        private System.Windows.Forms.Label label20;
        private C1.Win.C1Input.C1TextBox TxtNombreVia;
        private System.Windows.Forms.Label lbla;
        private System.Windows.Forms.Label lbln;
        private System.Windows.Forms.Label lblrz;
        private System.Windows.Forms.Label lblnd;
        private System.Windows.Forms.Label lbltd;
        private System.Windows.Forms.Label lbltc;
        private System.Windows.Forms.Label label26;
    }
}